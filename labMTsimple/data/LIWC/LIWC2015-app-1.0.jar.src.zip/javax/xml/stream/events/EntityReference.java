package javax.xml.stream.events;

public abstract interface EntityReference
  extends XMLEvent
{
  public abstract EntityDeclaration getDeclaration();
  
  public abstract String getName();
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/javax/xml/stream/events/EntityReference.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */