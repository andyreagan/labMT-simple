/*    */ package com.liwc.LIWC2015.controller;
/*    */ 
/*    */ import com.liwc.LIWC2015.App;
/*    */ import com.liwc.LIWC2015.Utils;
/*    */ import javafx.fxml.FXMLLoader;
/*    */ import javafx.stage.Stage;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public abstract class ModalDialogController extends ModelessWindowController
/*    */ {
/* 12 */   protected static final Logger logger = LoggerFactory.getLogger(ModalDialogController.class);
/*    */   
/*    */   public static <T> T run(App app, String resourcePath, Object... args) {
/*    */     try {
/* 16 */       FXMLLoader loader = new FXMLLoader(ModalDialogController.class.getResource(resourcePath));
/* 17 */       loader.load();
/* 18 */       ModalDialogController controller = (ModalDialogController)loader.getController();
/* 19 */       controller.app = app;
/* 20 */       Stage stage = controller.initStage(app, args);
/* 21 */       controller.stage = stage;
/* 22 */       app.setModalIsOpen(true);
/* 23 */       stage.showAndWait();
/* 24 */       app.setModalIsOpen(false);
/* 25 */       return controller;
/*    */     } catch (Exception e) {
/* 27 */       logger.error(e.getLocalizedMessage(), e);
/* 28 */       Utils.showException(app, e); }
/* 29 */     return null;
/*    */   }
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/ModalDialogController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */