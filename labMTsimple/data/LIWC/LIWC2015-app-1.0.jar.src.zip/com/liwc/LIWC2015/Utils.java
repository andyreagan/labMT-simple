/*     */ package com.liwc.LIWC2015;
/*     */ 
/*     */ import com.liwc.LIWC2015.customview.ExceptionDialog;
/*     */ import com.liwc.LIWC2015.customview.LIWCAlert;
/*     */ import com.liwc.core.SegmentationOptions;
/*     */ import com.liwc.core.TextProcessor;
/*     */ import com.sun.javafx.scene.control.skin.TableHeaderRow;
/*     */ import java.awt.Desktop;
/*     */ import java.io.File;
/*     */ import java.util.Optional;
/*     */ import java.util.regex.Pattern;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.event.Event;
/*     */ import javafx.scene.control.Alert.AlertType;
/*     */ import javafx.scene.control.ButtonType;
/*     */ import javafx.scene.control.TableView;
/*     */ import javafx.stage.DirectoryChooser;
/*     */ import javafx.stage.FileChooser;
/*     */ import javafx.stage.Stage;
/*     */ import javafx.stage.WindowEvent;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class Utils
/*     */ {
/*  29 */   private static Logger logger = LoggerFactory.getLogger(Utils.class);
/*     */   
/*  31 */   private static final Pattern oneCarriageReturn = Pattern.compile("\r{1}");
/*  32 */   private static final Pattern oneOrMoreCarriageReturns = Pattern.compile("\r{1,}");
/*  33 */   private static final Pattern twoOrMoreCarriageReturns = Pattern.compile("\r{2,}");
/*  34 */   private static final Pattern threeOrMoreCarriageReturns = Pattern.compile("\r{3,}");
/*     */   
/*     */   public static boolean isMac() {
/*  37 */     String osName = System.getProperty("os.name");
/*  38 */     return (osName != null) && (osName.toLowerCase().startsWith("mac"));
/*     */   }
/*     */   
/*     */   public static String getPreferencesPath() {
/*  42 */     return getAppSettingsFolder() + File.separator + "LIWC2015.prf";
/*     */   }
/*     */   
/*     */   public static String getAppSettingsFolder() {
/*  46 */     return System.getProperty("user.home") + File.separator + "LIWC2015";
/*     */   }
/*     */   
/*     */   public static void closeStage(Stage stage) {
/*  50 */     WindowEvent event = new WindowEvent(stage, WindowEvent.WINDOW_CLOSE_REQUEST);
/*  51 */     Event.fireEvent(stage, event);
/*  52 */     if (!event.isConsumed()) {
/*  53 */       stage.close();
/*     */     }
/*     */   }
/*     */   
/*     */   public static void disableColumnReordering(TableView tableView) {
/*  58 */     tableView.widthProperty().addListener(new ChangeListener()
/*     */     {
/*     */       public void changed(ObservableValue<? extends Number> source, Number oldWidth, Number newWidth)
/*     */       {
/*  62 */         final TableHeaderRow header = (TableHeaderRow)this.val$tableView.lookup("TableHeaderRow");
/*  63 */         header.reorderingProperty().addListener(new ChangeListener()
/*     */         {
/*     */           public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
/*  66 */             header.setReordering(false);
/*     */           }
/*     */         });
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public static TextProcessor getTextProcessor(App app, boolean handleSegments)
/*     */   {
/*  75 */     SegmentationOptions segmentationOptions = SegmentationOptions.noSegmentation();
/*  76 */     if (handleSegments) {
/*  77 */       LiwcPreferences.SegmentOptions so = app.getLiwcPreferences().getSegmentOptions();
/*  78 */       switch (so.getType()) {
/*     */       case 1: 
/*  80 */         segmentationOptions = SegmentationOptions.segmentationByNumber(so.getNumberOfSegments().intValue());
/*  81 */         break;
/*     */       case 2: 
/*  83 */         segmentationOptions = SegmentationOptions.segmentationByWords(so.getWordsPerSegment().intValue());
/*  84 */         break;
/*     */       case 3: 
/*  86 */         String specialChars = so.getSpecialCharacters();
/*  87 */         if (specialChars.startsWith("custom."))
/*  88 */           specialChars = specialChars.replaceAll("custom.", "");
/*  89 */         if (specialChars.length() == 0)
/*  90 */           specialChars = "¶";
/*  91 */         if ("¶".equals(specialChars)) {
/*  92 */           segmentationOptions = SegmentationOptions.segmentationByCustomPattern(oneCarriageReturn);
/*     */         } else {
/*  94 */           segmentationOptions = SegmentationOptions.segmentationByCustomDelimiter(specialChars);
/*     */         }
/*  96 */         break;
/*     */       case 4: 
/*  98 */         switch (so.getNumberOfCarriageReturns().intValue()) {
/*     */         case 2: 
/* 100 */           segmentationOptions = SegmentationOptions.segmentationByCustomPattern(twoOrMoreCarriageReturns);
/* 101 */           break;
/*     */         case 3: 
/* 103 */           segmentationOptions = SegmentationOptions.segmentationByCustomPattern(threeOrMoreCarriageReturns);
/* 104 */           break;
/*     */         default: 
/* 106 */           segmentationOptions = SegmentationOptions.segmentationByCustomPattern(oneOrMoreCarriageReturns); }
/* 107 */         break;
/*     */       
/*     */ 
/*     */       default: 
/* 111 */         segmentationOptions = SegmentationOptions.noSegmentation();
/*     */       }
/*     */       
/*     */     }
/* 115 */     TextProcessor textProcessor = new TextProcessor(app.getActiveDictionary(), segmentationOptions);
/* 116 */     return textProcessor;
/*     */   }
/*     */   
/*     */   public static void showException(App app, Exception e) {
/* 120 */     app.setModalIsOpen(true);
/* 121 */     new ExceptionDialog(app, e).showAndWait();
/* 122 */     app.setModalIsOpen(false);
/*     */   }
/*     */   
/*     */   public static void showAlert(App app, Alert.AlertType alertType, String title, String headerText, String contentText) {
/* 126 */     app.setModalIsOpen(true);
/* 127 */     new LIWCAlert(app, alertType, title, headerText, contentText).showAndWait();
/* 128 */     app.setModalIsOpen(false);
/*     */   }
/*     */   
/*     */   public static Optional<ButtonType> showAlert(App app, Alert.AlertType alertType, String title, String headerText, String contentText, ButtonType... buttons) {
/* 132 */     app.setModalIsOpen(true);
/* 133 */     LIWCAlert alert = new LIWCAlert(app, alertType, title, headerText, contentText);
/* 134 */     if (buttons != null)
/* 135 */       alert.getButtonTypes().setAll(buttons);
/* 136 */     Optional<ButtonType> btn = alert.showAndWait();
/* 137 */     app.setModalIsOpen(false);
/* 138 */     return btn;
/*     */   }
/*     */   
/*     */   public static void setInitialFolder(Object fileOrDirectoryChooser, String initialFolder) {
/* 142 */     File f = new File(initialFolder);
/* 143 */     if (f.exists()) {
/* 144 */       if ((fileOrDirectoryChooser instanceof FileChooser)) {
/* 145 */         ((FileChooser)fileOrDirectoryChooser).setInitialDirectory(f);
/* 146 */       } else if ((fileOrDirectoryChooser instanceof DirectoryChooser))
/* 147 */         ((DirectoryChooser)fileOrDirectoryChooser).setInitialDirectory(f);
/*     */     }
/*     */   }
/*     */   
/*     */   public static String getFilenameWithoutExtension(File file) {
/* 152 */     String fname = file.getName();
/* 153 */     return fname.substring(0, fname.lastIndexOf('.'));
/*     */   }
/*     */   
/*     */   public static void openFile(App app, File file) throws java.io.IOException {
/* 157 */     if (isMac()) {
/* 158 */       Runtime.getRuntime().exec(new String[] { "/usr/bin/open", file.getAbsolutePath() });
/*     */     } else
/* 160 */       Desktop.getDesktop().open(file);
/*     */   }
/*     */   
/*     */   public static char getCsvDelimiter(LiwcPreferences prefs) {
/* 164 */     char delimiter = ',';
/* 165 */     switch (prefs.getCsvDelimiter()) {
/*     */     case 1: 
/* 167 */       delimiter = '\t';
/* 168 */       break;
/*     */     case 2: 
/* 170 */       delimiter = ';';
/* 171 */       break;
/*     */     case 3: 
/* 173 */       delimiter = '|';
/* 174 */       break;
/*     */     case 4: 
/* 176 */       delimiter = '^';
/* 177 */       break;
/*     */     }
/*     */     
/*     */     
/* 181 */     return delimiter;
/*     */   }
/*     */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/Utils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */