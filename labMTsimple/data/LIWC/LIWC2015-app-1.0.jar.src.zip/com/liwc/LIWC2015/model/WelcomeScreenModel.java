/*    */ package com.liwc.LIWC2015.model;
/*    */ 
/*    */ import javafx.beans.property.SimpleStringProperty;
/*    */ import javafx.beans.property.StringProperty;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WelcomeScreenModel
/*    */ {
/* 11 */   private StringProperty activeDictionaryName = new SimpleStringProperty();
/* 12 */   private StringProperty segmentOptions = new SimpleStringProperty();
/* 13 */   private StringProperty allCategoriesOn = new SimpleStringProperty();
/*    */   
/*    */   public String getActiveDictionaryName() {
/* 16 */     return (String)this.activeDictionaryName.get();
/*    */   }
/*    */   
/*    */   public StringProperty activeDictionaryNameProperty() {
/* 20 */     return this.activeDictionaryName;
/*    */   }
/*    */   
/*    */   public void setActiveDictionaryName(String activeDictionaryName) {
/* 24 */     this.activeDictionaryName.set(activeDictionaryName);
/*    */   }
/*    */   
/*    */   public String getSegmentOptions() {
/* 28 */     return (String)this.segmentOptions.get();
/*    */   }
/*    */   
/*    */   public StringProperty segmentOptionsProperty() {
/* 32 */     return this.segmentOptions;
/*    */   }
/*    */   
/*    */   public void setSegmentOptions(String segmentOptions) {
/* 36 */     this.segmentOptions.set(segmentOptions);
/*    */   }
/*    */   
/*    */   public String getAllCategoriesOn() {
/* 40 */     return (String)this.allCategoriesOn.get();
/*    */   }
/*    */   
/*    */   public StringProperty allCategoriesOnProperty() {
/* 44 */     return this.allCategoriesOn;
/*    */   }
/*    */   
/*    */   public void setAllCategoriesOn(String allCategoriesOn) {
/* 48 */     this.allCategoriesOn.set(allCategoriesOn);
/*    */   }
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/model/WelcomeScreenModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */