/*    */ package com.liwc.LIWC2015.customview;
/*    */ 
/*    */ import com.liwc.LIWC2015.Utils;
/*    */ import java.io.File;
/*    */ import javafx.stage.DirectoryChooser;
/*    */ import javafx.stage.Modality;
/*    */ import javafx.stage.Stage;
/*    */ import javafx.stage.StageStyle;
/*    */ 
/*    */ public class DirectoryChooserWrapper
/*    */   extends Stage
/*    */ {
/*    */   private DirectoryChooser directoryChooser;
/*    */   
/*    */   public DirectoryChooserWrapper()
/*    */   {
/* 17 */     this.directoryChooser = new DirectoryChooser();
/*    */   }
/*    */   
/*    */   public DirectoryChooser getDirectoryChooser() {
/* 21 */     return this.directoryChooser;
/*    */   }
/*    */   
/*    */   public File showDialog() {
/* 25 */     initStyle(Utils.isMac() ? StageStyle.TRANSPARENT : StageStyle.UTILITY);
/* 26 */     initModality(Modality.APPLICATION_MODAL);
/* 27 */     setWidth(1.0D);
/* 28 */     setHeight(1.0D);
/* 29 */     setX(-100.0D);
/* 30 */     setY(-100.0D);
/* 31 */     show();
/* 32 */     File file = this.directoryChooser.showDialog(this);
/* 33 */     close();
/* 34 */     return file;
/*    */   }
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/customview/DirectoryChooserWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */