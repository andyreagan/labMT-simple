/*    */ package com.liwc.LIWC2015.customview;
/*    */ 
/*    */ import javafx.event.Event;
/*    */ import javafx.scene.control.TabPane;
/*    */ 
/*    */ public class CloseableTab extends javafx.scene.control.Tab implements ICloseable
/*    */ {
/*    */   public void close()
/*    */   {
/* 10 */     Event event = new Event(this, this, javafx.scene.control.Tab.TAB_CLOSE_REQUEST_EVENT);
/* 11 */     Event.fireEvent(this, event);
/* 12 */     if ((!event.isConsumed()) && 
/* 13 */       (getTabPane().getTabs().contains(this))) {
/* 14 */       getTabPane().getTabs().remove(this);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/customview/CloseableTab.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */