package com.liwc.core.dictionary;

import java.util.LinkedHashMap;

final class c
  extends LinkedHashMap
{
  c()
  {
    putAll(IDictionary.getPunctuationMarksMap(".…", 2600));
    putAll(IDictionary.getPunctuationMarksMap(",", 2601));
    putAll(IDictionary.getPunctuationMarksMap(":", 2602));
    putAll(IDictionary.getPunctuationMarksMap(";", 2603));
    putAll(IDictionary.getPunctuationMarksMap("?¿", 2604));
    putAll(IDictionary.getPunctuationMarksMap("!¡", 2605));
    putAll(IDictionary.getPunctuationMarksMap("-", 2606));
    putAll(IDictionary.getPunctuationMarksMap("‘\"“”«»", 2607));
    putAll(IDictionary.getPunctuationMarksMap("'’", 2608));
    putAll(IDictionary.getPunctuationMarksMap("()", 2609));
    putAll(IDictionary.getPunctuationMarksMap("#$%&\\/*+<=>@[]^_`´{}|~•†‡°¦", 2610));
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/core/dictionary/c.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */