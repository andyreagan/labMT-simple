package com.liwc.jsell;

public final class ESellerateException
  extends Exception
{
  public static final int Unknown = 0;
  public static final int SerialNumberValidationFailed = 1;
  public static final int ActivationValidationFailed = 2;
  public static final int ActivationDateExpired = 3;
  public static final int SerialNumberIsNotActivated = 4;
  public static final int ActivationFailed = 5;
  public static final int DeactivationFailed = 6;
  public static final int CheckForUpdateFailed = 7;
  private int a = 0;
  
  ESellerateException(int paramInt, String paramString)
  {
    super(paramString);
    this.a = paramInt;
  }
  
  ESellerateException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
  
  public final int getReason()
  {
    return this.a;
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/jsell/ESellerateException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */