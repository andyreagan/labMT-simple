/*     */ package com.liwc.LIWC2015.customview;
/*     */ 
/*     */ import com.liwc.LIWC2015.App;
/*     */ import com.liwc.LIWC2015.Utils;
/*     */ import com.liwc.LIWC2015.controller.IPaneController;
/*     */ import com.liwc.LIWC2015.controller.SaveablePaneController;
/*     */ import java.util.Optional;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.event.Event;
/*     */ import javafx.scene.control.ButtonType;
/*     */ import javafx.scene.control.TableView;
/*     */ import javafx.scene.web.WebView;
/*     */ import javafx.stage.Stage;
/*     */ 
/*     */ public class ResultPane extends javafx.scene.layout.Pane
/*     */ {
/*  18 */   private String text = null;
/*     */   private App app;
/*     */   private ICloseable parent;
/*     */   private IPaneController controller;
/*  22 */   private TableView tableView = null;
/*     */   private WebView webView;
/*     */   
/*     */   public ResultPane(App app, ICloseable parent, String text)
/*     */   {
/*  27 */     this.app = app;
/*  28 */     this.parent = parent;
/*  29 */     this.text = text;
/*     */   }
/*     */   
/*     */   public void onClose(Event event) {
/*  33 */     if (((this.controller instanceof SaveablePaneController)) && (!((SaveablePaneController)this.controller).isSaved())) {
/*  34 */       LIWCAlert alert = new LIWCAlert(this.app, javafx.scene.control.Alert.AlertType.CONFIRMATION, "LIWC2015", null, String.format("Do you want to save %s?", new Object[] { this.text }));
/*  35 */       ButtonType saveBtn = new ButtonType("Save");
/*  36 */       ButtonType doNotSaveBtn = new ButtonType("Don't Save");
/*  37 */       ButtonType cancelBtn = new ButtonType("Cancel", javafx.scene.control.ButtonBar.ButtonData.CANCEL_CLOSE);
/*  38 */       alert.getButtonTypes().setAll(new ButtonType[] { saveBtn, doNotSaveBtn, cancelBtn });
/*  39 */       this.app.setModalIsOpen(true);
/*  40 */       Optional<ButtonType> result = alert.showAndWait();
/*  41 */       this.app.setModalIsOpen(false);
/*  42 */       if (result.get() == saveBtn) {
/*  43 */         boolean saved = ((SaveablePaneController)this.controller).save();
/*  44 */         this.app.updateMenu();
/*  45 */         if (!saved)
/*  46 */           event.consume();
/*  47 */       } else if (result.get() == doNotSaveBtn) {
/*  48 */         this.controller.close();
/*     */       } else {
/*  50 */         event.consume();
/*     */       }
/*     */     } else {
/*  53 */       this.controller.close();
/*     */     }
/*     */   }
/*     */   
/*     */   public void save() {
/*  58 */     if (((this.controller instanceof SaveablePaneController)) && (((SaveablePaneController)this.controller).save())) {
/*  59 */       this.app.updateMenu();
/*     */     }
/*     */   }
/*     */   
/*     */   public void close() {
/*  64 */     if (Utils.isMac()) {
/*  65 */       Utils.closeStage((Stage)this.parent);
/*     */     } else {
/*  67 */       this.parent.close();
/*     */     }
/*  69 */     this.app.updateMenu();
/*     */   }
/*     */   
/*     */   public IPaneController getController() {
/*  73 */     return this.controller;
/*     */   }
/*     */   
/*     */   public void setController(IPaneController controller) {
/*  77 */     this.controller = controller;
/*     */   }
/*     */   
/*     */   public TableView getTableView() {
/*  81 */     if (this.tableView == null) {
/*  82 */       this.tableView = new TableView();
/*  83 */       this.tableView.prefHeightProperty().bind(heightProperty());
/*  84 */       this.tableView.prefWidthProperty().bind(widthProperty());
/*  85 */       getChildren().addAll(new javafx.scene.Node[] { this.tableView });
/*     */     }
/*  87 */     Utils.disableColumnReordering(this.tableView);
/*  88 */     return this.tableView;
/*     */   }
/*     */   
/*     */   public WebView getWebView() {
/*  92 */     if (this.webView == null) {
/*  93 */       this.webView = new WebView();
/*  94 */       this.webView.setMaxWidth(10000.0D);
/*  95 */       this.webView.setMaxHeight(10000.0D);
/*  96 */       this.webView.prefHeightProperty().bind(heightProperty());
/*  97 */       this.webView.prefWidthProperty().bind(widthProperty());
/*  98 */       getChildren().addAll(new javafx.scene.Node[] { this.webView });
/*     */     }
/* 100 */     return this.webView;
/*     */   }
/*     */   
/*     */   public Stage getParentAsStage() {
/* 104 */     if (Utils.isMac()) {
/* 105 */       return (Stage)this.parent;
/*     */     }
/* 107 */     return null;
/*     */   }
/*     */   
/*     */   public String getText() {
/* 111 */     return this.text;
/*     */   }
/*     */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/customview/ResultPane.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */