package com.microsoft.schemas.office.x2006.encryption;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.SchemaTypeSystem;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.XmlUnsignedInt;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public abstract interface STKeyBits
  extends XmlUnsignedInt
{
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(STKeyBits.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0B482D0B338CC9641C1543C3510577FE").resolveHandle("stkeybitse527type");
  
  public static final class Factory
  {
    public static STKeyBits newValue(Object paramObject)
    {
      return (STKeyBits)STKeyBits.type.newValue(paramObject);
    }
    
    public static STKeyBits newInstance()
    {
      return (STKeyBits)XmlBeans.getContextTypeLoader().newInstance(STKeyBits.type, null);
    }
    
    public static STKeyBits newInstance(XmlOptions paramXmlOptions)
    {
      return (STKeyBits)XmlBeans.getContextTypeLoader().newInstance(STKeyBits.type, paramXmlOptions);
    }
    
    public static STKeyBits parse(String paramString)
      throws XmlException
    {
      return (STKeyBits)XmlBeans.getContextTypeLoader().parse(paramString, STKeyBits.type, null);
    }
    
    public static STKeyBits parse(String paramString, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (STKeyBits)XmlBeans.getContextTypeLoader().parse(paramString, STKeyBits.type, paramXmlOptions);
    }
    
    public static STKeyBits parse(File paramFile)
      throws XmlException, IOException
    {
      return (STKeyBits)XmlBeans.getContextTypeLoader().parse(paramFile, STKeyBits.type, null);
    }
    
    public static STKeyBits parse(File paramFile, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (STKeyBits)XmlBeans.getContextTypeLoader().parse(paramFile, STKeyBits.type, paramXmlOptions);
    }
    
    public static STKeyBits parse(URL paramURL)
      throws XmlException, IOException
    {
      return (STKeyBits)XmlBeans.getContextTypeLoader().parse(paramURL, STKeyBits.type, null);
    }
    
    public static STKeyBits parse(URL paramURL, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (STKeyBits)XmlBeans.getContextTypeLoader().parse(paramURL, STKeyBits.type, paramXmlOptions);
    }
    
    public static STKeyBits parse(InputStream paramInputStream)
      throws XmlException, IOException
    {
      return (STKeyBits)XmlBeans.getContextTypeLoader().parse(paramInputStream, STKeyBits.type, null);
    }
    
    public static STKeyBits parse(InputStream paramInputStream, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (STKeyBits)XmlBeans.getContextTypeLoader().parse(paramInputStream, STKeyBits.type, paramXmlOptions);
    }
    
    public static STKeyBits parse(Reader paramReader)
      throws XmlException, IOException
    {
      return (STKeyBits)XmlBeans.getContextTypeLoader().parse(paramReader, STKeyBits.type, null);
    }
    
    public static STKeyBits parse(Reader paramReader, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (STKeyBits)XmlBeans.getContextTypeLoader().parse(paramReader, STKeyBits.type, paramXmlOptions);
    }
    
    public static STKeyBits parse(XMLStreamReader paramXMLStreamReader)
      throws XmlException
    {
      return (STKeyBits)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, STKeyBits.type, null);
    }
    
    public static STKeyBits parse(XMLStreamReader paramXMLStreamReader, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (STKeyBits)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, STKeyBits.type, paramXmlOptions);
    }
    
    public static STKeyBits parse(Node paramNode)
      throws XmlException
    {
      return (STKeyBits)XmlBeans.getContextTypeLoader().parse(paramNode, STKeyBits.type, null);
    }
    
    public static STKeyBits parse(Node paramNode, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (STKeyBits)XmlBeans.getContextTypeLoader().parse(paramNode, STKeyBits.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static STKeyBits parse(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return (STKeyBits)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, STKeyBits.type, null);
    }
    
    /**
     * @deprecated
     */
    public static STKeyBits parse(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return (STKeyBits)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, STKeyBits.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, STKeyBits.type, null);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, STKeyBits.type, paramXmlOptions);
    }
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/encryption/STKeyBits.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */