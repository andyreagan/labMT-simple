package javax.xml.stream.events;

public abstract interface ProcessingInstruction
  extends XMLEvent
{
  public abstract String getTarget();
  
  public abstract String getData();
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/javax/xml/stream/events/ProcessingInstruction.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */