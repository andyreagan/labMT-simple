/*    */ package com.liwc.LIWC2015.controller;
/*    */ 
/*    */ import com.liwc.LIWC2015.App;
/*    */ import com.liwc.LIWC2015.customview.ResultPane;
/*    */ import java.io.File;
/*    */ import javafx.scene.web.WebView;
/*    */ 
/*    */ public class ColorCodeTextPaneController implements IPaneController
/*    */ {
/*    */   private ResultPane resultPane;
/*    */   private App app;
/*    */   
/*    */   public ColorCodeTextPaneController(App app)
/*    */   {
/* 15 */     this.app = app;
/*    */   }
/*    */   
/*    */   public void close()
/*    */   {
/* 20 */     this.resultPane = null;
/*    */   }
/*    */   
/*    */   public void build(String name, File file) throws Exception {
/* 24 */     this.resultPane = this.app.newResultPane(this, name);
/* 25 */     WebView webView = this.resultPane.getWebView();
/* 26 */     webView.getEngine().load(file.toURI().toURL().toString());
/*    */   }
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/ColorCodeTextPaneController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */