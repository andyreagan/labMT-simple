package com.liwc.core;

import com.liwc.core.dictionary.IDictionary;
import com.liwc.core.text.IText;
import com.liwc.core.text.RawText;
import com.liwc.core.text.TextParser;
import com.liwc.core.text.TextToken;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

public class TextProcessor
{
  private IDictionary a;
  private TextToken b = null;
  private SegmentationOptions c;
  private String d = null;
  
  public TextProcessor(IDictionary paramIDictionary)
  {
    this(paramIDictionary, SegmentationOptions.noSegmentation());
  }
  
  public TextProcessor(IDictionary paramIDictionary, SegmentationOptions paramSegmentationOptions)
  {
    this.a = paramIDictionary;
    this.c = paramSegmentationOptions;
    if (this.c.getType() == 3) {
      this.d = paramSegmentationOptions.getCustomDelimiter().replaceAll("[^\\p{L}\\d]", "\\\\$0");
    }
  }
  
  public List processText(IText paramIText, TextParser paramTextParser)
  {
    if ((this.c.getType() == 3) || (this.c.getType() == 4))
    {
      ArrayList localArrayList = new ArrayList();
      paramIText = (paramIText = a(paramIText)).iterator();
      while (paramIText.hasNext())
      {
        IText localIText = (IText)paramIText.next();
        localArrayList.addAll(a(localIText, paramTextParser));
        localIText.close();
      }
      return localArrayList;
    }
    return a(paramIText, paramTextParser);
  }
  
  public Map getWordsByCategories(IText paramIText, TextParser paramTextParser)
  {
    TextParser localTextParser = paramTextParser;
    paramTextParser = paramIText;
    paramIText = this;
    LinkedHashMap localLinkedHashMap = new LinkedHashMap();
    paramTextParser = paramTextParser.readText(localTextParser);
    for (int i = 0; i < paramTextParser.size(); i++)
    {
      TextToken localTextToken;
      Object localObject;
      if ((localTextToken = (TextToken)paramTextParser.get(i)).isNumber())
      {
        if ((localObject = paramIText.a.getNumbersCategory()) != null) {
          localLinkedHashMap.putIfAbsent(localTextToken.getTokenValue().toLowerCase(), new a(paramIText, (Integer)localObject));
        }
      }
      else if (localTextToken.isWord())
      {
        localObject = paramIText.a.findWord(localTextToken.getTokenValue());
        localLinkedHashMap.putIfAbsent(localTextToken.getTokenValue().toLowerCase(), localObject == null ? new ArrayList() : localObject);
      }
    }
    return localLinkedHashMap;
  }
  
  private List a(IText paramIText)
  {
    String str1 = null;
    switch (this.c.getType())
    {
    case 3: 
      str1 = this.d;
      break;
    case 4: 
      str1 = this.c.getCustomPattern().pattern();
    }
    if (str1 == null) {
      return null;
    }
    ArrayList localArrayList = new ArrayList();
    int i = (paramIText = paramIText.getText().split(str1)).length;
    for (int j = 0; j < i; j++)
    {
      String str2 = paramIText[j];
      localArrayList.add(new RawText(str2));
    }
    return localArrayList;
  }
  
  private List a(IText paramIText, TextParser paramTextParser)
  {
    ArrayList localArrayList = new ArrayList();
    paramTextParser = paramIText.readText(paramTextParser);
    int i = 0;
    if (this.c.getType() == 1) {
      i = (int)Math.ceil(paramIText.getWordsCount(true) / this.c.getNumberOfSegments());
    } else if (this.c.getType() == 2) {
      i = this.c.getWords();
    }
    paramIText = new Segment(this.a);
    for (int j = 0; j < paramTextParser.size(); j++)
    {
      TextToken localTextToken;
      Object localObject1;
      Object localObject2;
      if ((localTextToken = (TextToken)paramTextParser.get(j)).isNumber())
      {
        paramIText.incNumbersCount();
        if ((localObject1 = this.a.getNumbersCategory()) != null) {
          if ((localObject2 = (Integer)paramIText.getCategories().get(localObject1)) == null) {
            paramIText.getCategories().put(localObject1, Integer.valueOf(1));
          } else {
            paramIText.getCategories().put(localObject1, Integer.valueOf(((Integer)localObject2).intValue() + 1));
          }
        }
      }
      else if ((localTextToken.isWord()) || (localTextToken.isPunctuationMark()))
      {
        Object localObject3;
        Object localObject4;
        if (localTextToken.isWord())
        {
          paramIText.incWordsCount();
          if ((localObject1 = TextParser.extractPunctuationMarks(localTextToken.getTokenValue())) != null)
          {
            localObject2 = ((List)localObject1).iterator();
            while (((Iterator)localObject2).hasNext())
            {
              localObject3 = (String)((Iterator)localObject2).next();
              if ((localObject4 = this.a.findWord((String)localObject3)) != null)
              {
                paramIText.incPunctuationMarksCount();
                localObject3 = ((List)localObject4).iterator();
                while (((Iterator)localObject3).hasNext())
                {
                  localObject4 = (Integer)((Iterator)localObject3).next();
                  Integer localInteger;
                  if ((localInteger = (Integer)paramIText.getCategories().get(localObject4)) == null) {
                    paramIText.getCategories().put(localObject4, Integer.valueOf(1));
                  } else {
                    paramIText.getCategories().put(localObject4, Integer.valueOf(localInteger.intValue() + 1));
                  }
                }
              }
            }
          }
          int k = localObject1 == null ? 0 : ((List)localObject1).size();
          if (localTextToken.getTokenValue().length() - k > 6) {
            paramIText.incWordsLongerThan6LettersCount();
          }
        }
        if ((localObject1 = this.a.findWord(localTextToken.getTokenValue())) != null)
        {
          if (localTextToken.isPunctuationMark()) {
            paramIText.incPunctuationMarksCount();
          }
          if (localTextToken.isWord()) {
            paramIText.incDictionaryWordsCount();
          }
          Iterator localIterator = ((List)localObject1).iterator();
          while (localIterator.hasNext())
          {
            localObject3 = (Integer)localIterator.next();
            if ((localObject4 = (Integer)paramIText.getCategories().get(localObject3)) == null) {
              paramIText.getCategories().put(localObject3, Integer.valueOf(1));
            } else {
              paramIText.getCategories().put(localObject3, Integer.valueOf(((Integer)localObject4).intValue() + 1));
            }
          }
        }
      }
      if ((localTextToken.isWord()) || (localTextToken.isNumber()))
      {
        if ((i != 0) && (paramIText.getWordsCount() == i))
        {
          if (this.b != null) {
            paramIText.incSentencesCount();
          }
          localArrayList.add(paramIText);
          paramIText = new Segment(this.a);
        }
        this.b = localTextToken;
      }
      else if ((localTextToken.isPunctuationMark()) && (this.b != null) && (a(paramTextParser, j)))
      {
        this.b = null;
        paramIText.incSentencesCount();
      }
    }
    if (this.b != null) {
      paramIText.incSentencesCount();
    }
    if (paramIText.getWordsCount() > 0) {
      localArrayList.add(paramIText);
    }
    return localArrayList;
  }
  
  private static boolean a(List paramList, int paramInt)
  {
    int i = 0;
    while (paramInt != paramList.size())
    {
      TextToken localTextToken;
      if (((localTextToken = (TextToken)paramList.get(paramInt)).isPunctuationMark()) && (".?!".contains(localTextToken.getTokenValue()))) {
        i = 1;
      } else if ((i == 0) || (!localTextToken.isPunctuationMark()) || (!"'\"’“”[](){}".contains(localTextToken.getTokenValue()))) {
        return (i != 0) && (localTextToken.isDelimiter());
      }
      paramInt++;
    }
    return false;
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/core/TextProcessor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */