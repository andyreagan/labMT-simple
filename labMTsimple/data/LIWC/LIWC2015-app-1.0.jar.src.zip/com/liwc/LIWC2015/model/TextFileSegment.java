/*    */ package com.liwc.LIWC2015.model;
/*    */ 
/*    */ import com.liwc.core.Segment;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextFileSegment
/*    */   extends DataSegment
/*    */ {
/* 11 */   private String fileName = null;
/* 12 */   private Integer segmentIndex = null;
/* 13 */   private Exception exception = null;
/*    */   
/*    */   public TextFileSegment(String fileName, int segmentIndex, Segment segment) {
/* 16 */     super(segment);
/* 17 */     this.fileName = fileName;
/* 18 */     this.segmentIndex = Integer.valueOf(segmentIndex);
/*    */   }
/*    */   
/*    */   public TextFileSegment(String fileName, Exception exception) {
/* 22 */     super(null);
/* 23 */     this.fileName = fileName;
/*    */     
/* 25 */     this.exception = exception;
/*    */   }
/*    */   
/*    */   public String getFileName() {
/* 29 */     return this.fileName;
/*    */   }
/*    */   
/*    */   public void setFileName(String fileName) {
/* 33 */     this.fileName = fileName;
/*    */   }
/*    */   
/*    */   public Integer getSegmentIndex() {
/* 37 */     return this.segmentIndex;
/*    */   }
/*    */   
/*    */   public void setSegmentIndex(int segmentIndex) {
/* 41 */     this.segmentIndex = Integer.valueOf(segmentIndex);
/*    */   }
/*    */   
/*    */   public Exception getException() {
/* 45 */     return this.exception;
/*    */   }
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/model/TextFileSegment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */