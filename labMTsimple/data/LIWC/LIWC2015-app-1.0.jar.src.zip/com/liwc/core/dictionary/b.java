package com.liwc.core.dictionary;

import java.util.LinkedHashMap;

final class b
  extends LinkedHashMap
{
  b()
  {
    put(Integer.valueOf(2600), "Period");
    put(Integer.valueOf(2601), "Comma");
    put(Integer.valueOf(2602), "Colon");
    put(Integer.valueOf(2603), "SemiC");
    put(Integer.valueOf(2604), "QMark");
    put(Integer.valueOf(2605), "Exclam");
    put(Integer.valueOf(2606), "Dash");
    put(Integer.valueOf(2607), "Quote");
    put(Integer.valueOf(2608), "Apostro");
    put(Integer.valueOf(2609), "Parenth");
    put(Integer.valueOf(2610), "OtherP");
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/core/dictionary/b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */