package com.microsoft.schemas.office.x2006.encryption;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.SchemaTypeSystem;
import org.apache.xmlbeans.XmlBase64Binary;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public abstract interface CTDataIntegrity
  extends XmlObject
{
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CTDataIntegrity.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0B482D0B338CC9641C1543C3510577FE").resolveHandle("ctdataintegrity6eb5type");
  
  public abstract byte[] getEncryptedHmacKey();
  
  public abstract XmlBase64Binary xgetEncryptedHmacKey();
  
  public abstract void setEncryptedHmacKey(byte[] paramArrayOfByte);
  
  public abstract void xsetEncryptedHmacKey(XmlBase64Binary paramXmlBase64Binary);
  
  public abstract byte[] getEncryptedHmacValue();
  
  public abstract XmlBase64Binary xgetEncryptedHmacValue();
  
  public abstract void setEncryptedHmacValue(byte[] paramArrayOfByte);
  
  public abstract void xsetEncryptedHmacValue(XmlBase64Binary paramXmlBase64Binary);
  
  public static final class Factory
  {
    public static CTDataIntegrity newInstance()
    {
      return (CTDataIntegrity)XmlBeans.getContextTypeLoader().newInstance(CTDataIntegrity.type, null);
    }
    
    public static CTDataIntegrity newInstance(XmlOptions paramXmlOptions)
    {
      return (CTDataIntegrity)XmlBeans.getContextTypeLoader().newInstance(CTDataIntegrity.type, paramXmlOptions);
    }
    
    public static CTDataIntegrity parse(String paramString)
      throws XmlException
    {
      return (CTDataIntegrity)XmlBeans.getContextTypeLoader().parse(paramString, CTDataIntegrity.type, null);
    }
    
    public static CTDataIntegrity parse(String paramString, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (CTDataIntegrity)XmlBeans.getContextTypeLoader().parse(paramString, CTDataIntegrity.type, paramXmlOptions);
    }
    
    public static CTDataIntegrity parse(File paramFile)
      throws XmlException, IOException
    {
      return (CTDataIntegrity)XmlBeans.getContextTypeLoader().parse(paramFile, CTDataIntegrity.type, null);
    }
    
    public static CTDataIntegrity parse(File paramFile, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTDataIntegrity)XmlBeans.getContextTypeLoader().parse(paramFile, CTDataIntegrity.type, paramXmlOptions);
    }
    
    public static CTDataIntegrity parse(URL paramURL)
      throws XmlException, IOException
    {
      return (CTDataIntegrity)XmlBeans.getContextTypeLoader().parse(paramURL, CTDataIntegrity.type, null);
    }
    
    public static CTDataIntegrity parse(URL paramURL, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTDataIntegrity)XmlBeans.getContextTypeLoader().parse(paramURL, CTDataIntegrity.type, paramXmlOptions);
    }
    
    public static CTDataIntegrity parse(InputStream paramInputStream)
      throws XmlException, IOException
    {
      return (CTDataIntegrity)XmlBeans.getContextTypeLoader().parse(paramInputStream, CTDataIntegrity.type, null);
    }
    
    public static CTDataIntegrity parse(InputStream paramInputStream, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTDataIntegrity)XmlBeans.getContextTypeLoader().parse(paramInputStream, CTDataIntegrity.type, paramXmlOptions);
    }
    
    public static CTDataIntegrity parse(Reader paramReader)
      throws XmlException, IOException
    {
      return (CTDataIntegrity)XmlBeans.getContextTypeLoader().parse(paramReader, CTDataIntegrity.type, null);
    }
    
    public static CTDataIntegrity parse(Reader paramReader, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTDataIntegrity)XmlBeans.getContextTypeLoader().parse(paramReader, CTDataIntegrity.type, paramXmlOptions);
    }
    
    public static CTDataIntegrity parse(XMLStreamReader paramXMLStreamReader)
      throws XmlException
    {
      return (CTDataIntegrity)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, CTDataIntegrity.type, null);
    }
    
    public static CTDataIntegrity parse(XMLStreamReader paramXMLStreamReader, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (CTDataIntegrity)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, CTDataIntegrity.type, paramXmlOptions);
    }
    
    public static CTDataIntegrity parse(Node paramNode)
      throws XmlException
    {
      return (CTDataIntegrity)XmlBeans.getContextTypeLoader().parse(paramNode, CTDataIntegrity.type, null);
    }
    
    public static CTDataIntegrity parse(Node paramNode, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (CTDataIntegrity)XmlBeans.getContextTypeLoader().parse(paramNode, CTDataIntegrity.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static CTDataIntegrity parse(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return (CTDataIntegrity)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, CTDataIntegrity.type, null);
    }
    
    /**
     * @deprecated
     */
    public static CTDataIntegrity parse(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return (CTDataIntegrity)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, CTDataIntegrity.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, CTDataIntegrity.type, null);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, CTDataIntegrity.type, paramXmlOptions);
    }
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/encryption/CTDataIntegrity.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */