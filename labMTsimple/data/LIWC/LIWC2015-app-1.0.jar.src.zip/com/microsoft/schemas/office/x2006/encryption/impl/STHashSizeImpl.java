package com.microsoft.schemas.office.x2006.encryption.impl;

import com.microsoft.schemas.office.x2006.encryption.STHashSize;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaIntHolderEx;

public class STHashSizeImpl
  extends JavaIntHolderEx
  implements STHashSize
{
  public STHashSizeImpl(SchemaType paramSchemaType)
  {
    super(paramSchemaType, false);
  }
  
  protected STHashSizeImpl(SchemaType paramSchemaType, boolean paramBoolean)
  {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/encryption/impl/STHashSizeImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */