/*    */ package com.liwc.LIWC2015.model;
/*    */ 
/*    */ import com.liwc.core.Segment;
/*    */ 
/*    */ public class DataSegment
/*    */ {
/*    */   protected Segment segment;
/*    */   
/*    */   protected DataSegment(Segment segment)
/*    */   {
/* 11 */     this.segment = segment;
/*    */   }
/*    */   
/*    */   public Integer getWordsCount() {
/* 15 */     return this.segment == null ? null : Integer.valueOf(this.segment.getWordsCount());
/*    */   }
/*    */   
/*    */   public Float getWordsPerSentence() {
/* 19 */     return this.segment == null ? null : Float.valueOf(this.segment.getWordsPerSentence());
/*    */   }
/*    */   
/*    */   public Float getSixLettersWords() {
/* 23 */     if (this.segment == null)
/* 24 */       return null;
/* 25 */     return Float.valueOf(getWordsCount().intValue() == 0 ? 0.0F : 100.0F * this.segment.getWordsLongerThan6LettersCount() / getWordsCount().intValue());
/*    */   }
/*    */   
/*    */   public Float getDictWords() {
/* 29 */     if (this.segment == null)
/* 30 */       return null;
/* 31 */     return Float.valueOf(getWordsCount().intValue() == 0 ? 0.0F : 100.0F * this.segment.getDictionaryWordsCount() / getWordsCount().intValue());
/*    */   }
/*    */   
/*    */   public Float getAnalytic() {
/* 35 */     return this.segment == null ? null : Float.valueOf(this.segment.getAnalytic());
/*    */   }
/*    */   
/*    */   public Float getClout() {
/* 39 */     return this.segment == null ? null : Float.valueOf(this.segment.getClout());
/*    */   }
/*    */   
/*    */   public Float getAuthentic() {
/* 43 */     return this.segment == null ? null : Float.valueOf(this.segment.getAuthentic());
/*    */   }
/*    */   
/*    */   public Float getTone() {
/* 47 */     return this.segment == null ? null : Float.valueOf(this.segment.getTone());
/*    */   }
/*    */   
/*    */   public Float getPunctMarks() {
/* 51 */     if (this.segment == null)
/* 52 */       return null;
/* 53 */     return Float.valueOf(getWordsCount().intValue() == 0 ? 0.0F : 100.0F * this.segment.getPunctuationMarksCount() / getWordsCount().intValue());
/*    */   }
/*    */   
/*    */   public Float getCategoryValue(int category) {
/* 57 */     if (this.segment == null)
/* 58 */       return null;
/* 59 */     return Float.valueOf(getWordsCount().intValue() == 0 ? 0.0F : 100.0F * this.segment.getCategoryValue(category) / getWordsCount().intValue());
/*    */   }
/*    */   
/*    */   public Segment getSegment() {
/* 63 */     return this.segment;
/*    */   }
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/model/DataSegment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */