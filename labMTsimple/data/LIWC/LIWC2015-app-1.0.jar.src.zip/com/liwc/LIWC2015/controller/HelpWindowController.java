/*    */ package com.liwc.LIWC2015.controller;
/*    */ 
/*    */ import com.liwc.LIWC2015.App;
/*    */ import com.liwc.LIWC2015.Utils;
/*    */ import java.net.URL;
/*    */ import java.util.ResourceBundle;
/*    */ import javafx.beans.property.DoubleProperty;
/*    */ import javafx.beans.property.ReadOnlyBooleanProperty;
/*    */ import javafx.beans.value.ChangeListener;
/*    */ import javafx.beans.value.ObservableValue;
/*    */ import javafx.collections.ObservableList;
/*    */ import javafx.concurrent.Worker;
/*    */ import javafx.fxml.FXML;
/*    */ import javafx.scene.Node;
/*    */ import javafx.scene.Scene;
/*    */ import javafx.scene.control.Label;
/*    */ import javafx.scene.control.ProgressBar;
/*    */ import javafx.scene.control.Separator;
/*    */ import javafx.scene.layout.HBox;
/*    */ import javafx.scene.layout.VBox;
/*    */ import javafx.scene.web.WebEngine;
/*    */ import javafx.scene.web.WebView;
/*    */ import javafx.stage.Stage;
/*    */ 
/*    */ public class HelpWindowController extends ModelessWindowController implements javafx.fxml.Initializable
/*    */ {
/* 27 */   private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(HelpWindowController.class);
/*    */   
/*    */   @FXML
/*    */   private VBox vBox;
/*    */   
/*    */   @FXML
/*    */   private WebView webView;
/*    */   @FXML
/*    */   private Label message;
/*    */   @FXML
/*    */   private ProgressBar progressBar;
/*    */   @FXML
/*    */   private Separator separator;
/*    */   @FXML
/*    */   private HBox statusBar;
/*    */   
/*    */   public void initialize(URL location, ResourceBundle resources)
/*    */   {
/* 45 */     this.message.textProperty().bind(this.webView.getEngine().getLoadWorker().messageProperty());
/* 46 */     this.progressBar.progressProperty().bind(this.webView.getEngine().getLoadWorker().progressProperty());
/* 47 */     this.webView.prefHeightProperty().bind(this.vBox.heightProperty().subtract(this.separator.heightProperty()).subtract(this.statusBar.heightProperty()));
/* 48 */     this.webView.prefWidthProperty().bind(this.vBox.widthProperty());
/*    */     
/* 50 */     this.webView.getEngine().getLoadWorker().runningProperty().addListener(new ChangeListener()
/*    */     {
/*    */       public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
/* 53 */         if ((newValue.booleanValue()) && (!HelpWindowController.this.statusBar.getChildren().contains(HelpWindowController.this.progressBar)))
/* 54 */           HelpWindowController.this.statusBar.getChildren().add(HelpWindowController.this.progressBar);
/* 55 */         if ((!newValue.booleanValue()) && (HelpWindowController.this.statusBar.getChildren().contains(HelpWindowController.this.progressBar))) {
/* 56 */           HelpWindowController.this.statusBar.getChildren().remove(HelpWindowController.this.progressBar);
/*    */         }
/*    */       }
/*    */     });
/*    */   }
/*    */   
/*    */   public Stage initStage(final App app, Object... args) throws Exception {
/* 63 */     Scene newScene = new Scene(this.vBox);
/* 64 */     Stage stage = new Stage();
/* 65 */     stage.setScene(newScene);
/* 66 */     stage.setTitle("LIWC Help");
/* 67 */     if (!Utils.isMac())
/* 68 */       stage.initStyle(javafx.stage.StageStyle.UTILITY);
/* 69 */     stage.initOwner(Utils.isMac() ? null : app.getStage());
/*    */     
/* 71 */     if (Utils.isMac()) {
/* 72 */       stage.focusedProperty().addListener(new ChangeListener()
/*    */       {
/*    */         public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
/* 75 */           if (newValue.booleanValue()) {
/* 76 */             if (!HelpWindowController.this.vBox.getChildren().contains(app.getMenuBar())) {
/* 77 */               HelpWindowController.this.vBox.getChildren().addAll(new Node[] { app.getMenuBar() });
/*    */             }
/* 79 */           } else if (!app.getRoot().getChildren().contains(app.getMenuBar())) {
/* 80 */             app.getRoot().getChildren().addAll(new Node[] { app.getMenuBar() });
/*    */           }
/*    */         }
/*    */       });
/*    */     }
/*    */     
/* 86 */     this.webView.getEngine().load("http://liwc.net");
/*    */     
/* 88 */     return stage;
/*    */   }
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/HelpWindowController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */