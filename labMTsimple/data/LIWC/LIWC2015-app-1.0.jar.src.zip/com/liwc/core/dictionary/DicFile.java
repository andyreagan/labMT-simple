package com.liwc.core.dictionary;

import com.liwc.core.LanguageSettings;
import com.liwc.core.text.MSWordFile;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.io.ByteOrderMark;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.input.BOMInputStream;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.xmlbeans.XmlException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DicFile
  implements IDictionary
{
  private static final Pattern b = Pattern.compile("\\((\\d+)(\\|(\\d+))*\\)");
  private static final Pattern c = Pattern.compile("\\([^\\(\\)]+\\)");
  private List d = null;
  private Map e = null;
  private LinkedHashMap f = new LinkedHashMap();
  private LinkedHashMap g = new LinkedHashMap();
  private LinkedHashSet h = new LinkedHashSet();
  private List i = new ArrayList();
  private Charset j;
  private Integer k = null;
  protected Category a = new Category(0, "root");
  private Stack l = new a(this);
  private LanguageSettings m;
  private int n = -1;
  private Pattern o;
  private HashMap p = new HashMap();
  private Logger q = LoggerFactory.getLogger(DicFile.class);
  
  public DicFile(InputStream paramInputStream)
  {
    this(paramInputStream, new LanguageSettings());
  }
  
  public DicFile(InputStream paramInputStream, LanguageSettings paramLanguageSettings)
  {
    this(paramInputStream, paramLanguageSettings, Charset.defaultCharset());
  }
  
  public DicFile(InputStream paramInputStream, LanguageSettings paramLanguageSettings, Charset paramCharset)
  {
    this.j = paramCharset;
    this.m = paramLanguageSettings;
    this.o = Pattern.compile(paramLanguageSettings.getWordPattern(), 2);
    paramLanguageSettings = paramInputStream;
    paramInputStream = this;
    paramLanguageSettings = new BufferedInputStream(paramLanguageSettings);
    try
    {
      paramCharset = new MSWordFile(paramLanguageSettings);
      paramInputStream.b(paramCharset.getText());
      paramLanguageSettings.close();
    }
    catch (OpenXML4JException|XmlException localOpenXML4JException) {}
    if (paramInputStream.d == null)
    {
      paramLanguageSettings.mark(0);
      paramLanguageSettings.reset();
      Object localObject = (localObject = (paramCharset = new BOMInputStream(paramLanguageSettings, tmp223_217)).getBOM()) == null ? paramInputStream.j.name() : ((ByteOrderMark)localObject).getCharsetName();
      localObject = IOUtils.toString(paramCharset, (String)localObject);
      paramCharset.close();
      paramLanguageSettings.close();
      paramInputStream.b((String)localObject);
    }
  }
  
  public List findWord(String paramString)
  {
    return a(paramString);
  }
  
  public synchronized Map getCategoriesPlain()
  {
    if (this.e == null)
    {
      this.e = new LinkedHashMap();
      Iterator localIterator = this.d.iterator();
      while (localIterator.hasNext())
      {
        Category localCategory = (Category)localIterator.next();
        this.e.putAll(getCategoriesPlain(localCategory));
      }
    }
    return this.e;
  }
  
  public List getCategoriesTree()
  {
    return this.d;
  }
  
  public Map getCategoriesPlain(Category paramCategory)
  {
    LinkedHashMap localLinkedHashMap;
    (localLinkedHashMap = new LinkedHashMap()).put(Integer.valueOf(paramCategory.getId()), paramCategory.getName());
    if (paramCategory.getKids() != null)
    {
      paramCategory = paramCategory.getKids().iterator();
      while (paramCategory.hasNext())
      {
        Category localCategory = (Category)paramCategory.next();
        localLinkedHashMap.putAll(getCategoriesPlain(localCategory));
      }
    }
    return localLinkedHashMap;
  }
  
  public Map getPatterns()
  {
    return this.f;
  }
  
  public Integer getNumbersCategory()
  {
    if (this.k == null)
    {
      Iterator localIterator = getCategoriesPlain().entrySet().iterator();
      while (localIterator.hasNext())
      {
        Map.Entry localEntry;
        if (((String)(localEntry = (Map.Entry)localIterator.next()).getValue()).toLowerCase().contains("num"))
        {
          this.k = ((Integer)localEntry.getKey());
          break;
        }
      }
    }
    return this.k;
  }
  
  public List getSpecialWords()
  {
    return this.i;
  }
  
  private synchronized List a(String paramString)
  {
    paramString = paramString.toLowerCase();
    List localList;
    if ((localList = (List)IDictionary.PunctuationMarks.get(paramString)) != null) {
      return localList;
    }
    if ((localList = (List)this.g.get(paramString)) != null) {
      return localList;
    }
    if (this.h.contains(paramString)) {
      return null;
    }
    Iterator localIterator = this.p.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      if (a(paramString, (String)localEntry.getKey()))
      {
        this.g.put(paramString, localEntry.getValue());
        return (List)localEntry.getValue();
      }
    }
    if (localList == null) {
      this.h.add(paramString);
    }
    return localList;
  }
  
  private boolean a(String paramString1, String paramString2)
  {
    if (paramString1.equals(paramString2)) {
      return true;
    }
    String str3;
    if (paramString2.contains(" "))
    {
      String[] arrayOfString = paramString1.split(" ");
      paramString1 = paramString2.split(" ");
      if (arrayOfString.length != paramString1.length) {
        return false;
      }
      for (paramString2 = 0; paramString2 < paramString1.length; paramString2++)
      {
        str3 = paramString1[paramString2];
        String str5 = arrayOfString[paramString2];
        if (!a(str5, str3)) {
          return false;
        }
      }
      return true;
    }
    if (paramString2.contains("*"))
    {
      String str1 = paramString2.indexOf('*');
      if (paramString1.length() >= str1)
      {
        str3 = str1;
        paramString1 = 0;
        String str2 = paramString2;
        paramString2 = str1;
        paramString1 = 0;
        paramString1 = paramString1;
        if (paramString2 != str3) {
          return false;
        }
        for (String str4 = 0; str4 < paramString2; str4++) {
          if (paramString1.charAt(str4 + 0) != str2.charAt(str4 + 0)) {
            return false;
          }
        }
        return true;
      }
    }
    return false;
  }
  
  private void b(String paramString)
  {
    paramString = paramString.split("\r\n|\r|\n");
    int i1 = 0;
    Object localObject2;
    Object localObject3;
    for (int i2 = 0; i2 < paramString.length; i2++)
    {
      String str;
      if ((str = paramString[i2]) != null)
      {
        if (str.contains("##")) {
          str = str.substring(0, str.indexOf("##"));
        }
        if (str.startsWith("%"))
        {
          i1++;
        }
        else
        {
          int i3;
          if (i1 == 1)
          {
            localObject2 = null;
            try
            {
              localObject2 = d(str);
            }
            catch (Exception localException)
            {
              this.q.error(localException.getLocalizedMessage(), localException);
            }
            if (localObject2 != null)
            {
              str = str;
              for (int i4 = 0; str.charAt(i4) == '\t'; i4++) {}
              if (i4 += 2 > this.l.size())
              {
                ((Category)this.l.peek()).addKid((Category)localObject2);
                this.l.push(localObject2);
              }
              else if (i4 < this.l.size())
              {
                for (i3 = 0; i3 <= this.l.size() - i4; i3++) {
                  this.l.pop();
                }
                this.l.pop();
                ((Category)this.l.peek()).addKid((Category)localObject2);
                this.l.push(localObject2);
              }
              else
              {
                this.l.pop();
                ((Category)this.l.peek()).addKid((Category)localObject2);
                this.l.push(localObject2);
              }
            }
          }
          else if (i1 == 2)
          {
            if (this.d == null) {
              this.d = this.a.getKids();
            }
            if ((localObject2 = i3.split("\t")).length >= 2)
            {
              localObject3 = new ArrayList();
              for (i3 = 1; i3 < localObject2.length; i3++) {
                try
                {
                  ((List)localObject3).add(Integer.valueOf(Integer.parseInt(localObject2[i3])));
                }
                catch (NumberFormatException localNumberFormatException)
                {
                  this.q.error(localNumberFormatException.getLocalizedMessage(), localNumberFormatException);
                }
              }
              if (((List)localObject3).size() > 0)
              {
                localObject1 = localObject2[0].toLowerCase();
                this.f.put(localObject1, localObject3);
              }
            }
          }
        }
      }
    }
    Map localMap;
    Object localObject1 = (localMap = b()).entrySet().iterator();
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (Map.Entry)((Iterator)localObject1).next();
      if ((localObject3 = c(((String)((Map.Entry)localObject2).getKey()).toLowerCase())) != null) {
        this.i.add(localObject3);
      }
    }
    localObject1 = this.f.entrySet().iterator();
    while (((Iterator)localObject1).hasNext())
    {
      localObject2 = (Map.Entry)((Iterator)localObject1).next();
      if (((localObject3 = c(((String)((Map.Entry)localObject2).getKey()).toLowerCase())) != null) && (!this.i.contains(localObject3))) {
        this.i.add(localObject3);
      }
    }
    a();
    this.l.clear();
    this.l = null;
    this.a = null;
    if (this.d == null) {
      throw new IOException("Invalid LIWC dictionary.");
    }
  }
  
  private String c(String paramString)
  {
    paramString = 1;
    String str = paramString;
    paramString = this;
    if (!this.o.matcher(str.replaceAll("\\*", "")).matches())
    {
      int i1 = 1;
      if (c.matcher(str).find()) {
        i1 = 0;
      }
      char[] arrayOfChar = str.toCharArray();
      int i2 = 0;
      for (int i3 = arrayOfChar.length - 1; i3 >= 0; i3--) {
        if (".…,:;?¿!¡-‘\\\"“”«»'’()#$%&\\\\/*+<=>@[]^_`´{}|~•†‡°¦ ".indexOf(arrayOfChar[i3]) != -1)
        {
          i2 = 1;
          if (arrayOfChar[i3] == '*') {
            str = str.substring(0, i3) + "[\\p{L}\\d]*" + paramString.m.getWordSuffixPattern() + str.substring(i3 + 1, str.length());
          } else if (((arrayOfChar[i3] != '(') && (arrayOfChar[i3] != ')')) || (i1 != 0)) {
            str = str.substring(0, i3) + "\\" + str.substring(i3, str.length());
          }
        }
      }
      if (i2 != 0) {
        return str;
      }
    }
    return null;
  }
  
  private void a()
  {
    Iterator localIterator = this.f.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      if (c.matcher((CharSequence)localEntry.getKey()).find())
      {
        ArrayList localArrayList = new ArrayList();
        Object localObject = c.matcher((CharSequence)localEntry.getKey());
        while (((Matcher)localObject).find()) {
          localArrayList.add(((String)localEntry.getKey()).substring(((Matcher)localObject).start(), ((Matcher)localObject).end()));
        }
        localObject = (String)localEntry.getKey();
        while (localArrayList.size() > 0)
        {
          String str1 = (String)localArrayList.get(0);
          String str2 = (str2 = "\\" + str1.substring(0, str1.length() - 1) + "\\)").replaceAll("\\*", "\\\\*");
          str1 = str1.substring(1, str1.length() - 1);
          localObject = ((String)localObject).replaceAll(str2, str1);
          localArrayList.remove(0);
        }
        this.p.put(localObject, localEntry.getValue());
      }
      else
      {
        this.p.put(localEntry.getKey(), localEntry.getValue());
      }
    }
  }
  
  private Category d(String paramString)
  {
    if (paramString.isEmpty()) {
      return null;
    }
    while (paramString.charAt(0) == '\t') {
      paramString = paramString.substring(1);
    }
    int i1 = 0;
    paramString = paramString.split("\t");
    int i2 = this.n;
    try
    {
      i2 = Integer.parseInt(paramString[0]);
      i1++;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      this.n -= 1;
    }
    int i3 = paramString[i1].indexOf('(');
    String str2 = "";
    String str1;
    if (i3 != -1)
    {
      str1 = paramString[i1].substring(0, i3).trim();
      str2 = paramString[i1].substring(i3, paramString[i1].length()).replace("(", "").replace(")", "").trim();
    }
    else
    {
      str1 = paramString[i1].trim();
    }
    if ((str1 == null) || (str1.isEmpty())) {
      return null;
    }
    return new Category(i2, str1, str2);
  }
  
  private static boolean e(String paramString)
  {
    return (paramString.contains("(")) && (paramString.contains(")")) && (b.matcher(paramString).find());
  }
  
  private Map b()
  {
    HashMap localHashMap = new HashMap();
    ArrayList localArrayList = new ArrayList();
    Iterator localIterator = this.f.entrySet().iterator();
    Object localObject1;
    while (localIterator.hasNext()) {
      if (e((String)(localObject1 = (Map.Entry)localIterator.next()).getKey()))
      {
        Object localObject2 = (localObject2 = f((String)((Map.Entry)localObject1).getKey())).iterator();
        while (((Iterator)localObject2).hasNext())
        {
          String str = (String)((Iterator)localObject2).next();
          localHashMap.put(str, ((Map.Entry)localObject1).getValue());
        }
        localArrayList.add(((Map.Entry)localObject1).getKey());
      }
    }
    localIterator = localArrayList.iterator();
    while (localIterator.hasNext())
    {
      localObject1 = (String)localIterator.next();
      this.f.remove(localObject1);
    }
    this.f.putAll(localHashMap);
    return localHashMap;
  }
  
  private Set f(String paramString)
  {
    HashSet localHashSet = new HashSet();
    Matcher localMatcher;
    if ((localMatcher = b.matcher(paramString)).find())
    {
      int i1 = localMatcher.groupCount();
      for (int i2 = 1; i2 <= i1; i2++)
      {
        Object localObject = localMatcher.group(i2);
        try
        {
          localObject = (localObject = a(Integer.parseInt((String)localObject))).iterator();
          while (((Iterator)localObject).hasNext())
          {
            String str = (String)((Iterator)localObject).next();
            if (e(str = b.matcher(paramString).replaceFirst("(" + str + ")"))) {
              localHashSet.addAll(f(str));
            } else {
              localHashSet.add(str);
            }
          }
        }
        catch (NumberFormatException localNumberFormatException) {}
      }
    }
    return localHashSet;
  }
  
  private Set a(int paramInt)
  {
    HashSet localHashSet = new HashSet();
    Iterator localIterator = this.f.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry;
      if (((List)(localEntry = (Map.Entry)localIterator.next()).getValue()).contains(Integer.valueOf(paramInt))) {
        localHashSet.add(localEntry.getKey());
      }
    }
    return localHashSet;
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/core/dictionary/DicFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */