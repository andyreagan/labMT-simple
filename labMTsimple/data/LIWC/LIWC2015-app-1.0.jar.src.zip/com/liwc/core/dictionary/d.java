package com.liwc.core.dictionary;

import java.util.ArrayList;

final class d
  extends ArrayList
{
  d(int paramInt)
  {
    add(Integer.valueOf(this.a));
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/core/dictionary/d.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */