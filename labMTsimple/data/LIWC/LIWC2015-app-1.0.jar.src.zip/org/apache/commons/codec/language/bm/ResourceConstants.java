package org.apache.commons.codec.language.bm;

class ResourceConstants
{
  static final String CMT = "//";
  static final String ENCODING = "UTF-8";
  static final String EXT_CMT_END = "*/";
  static final String EXT_CMT_START = "/*";
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/org/apache/commons/codec/language/bm/ResourceConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */