package com.microsoft.schemas.office.x2006.encryption.impl;

import com.microsoft.schemas.office.x2006.encryption.STSpinCount;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaIntHolderEx;

public class STSpinCountImpl
  extends JavaIntHolderEx
  implements STSpinCount
{
  public STSpinCountImpl(SchemaType paramSchemaType)
  {
    super(paramSchemaType, false);
  }
  
  protected STSpinCountImpl(SchemaType paramSchemaType, boolean paramBoolean)
  {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/encryption/impl/STSpinCountImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */