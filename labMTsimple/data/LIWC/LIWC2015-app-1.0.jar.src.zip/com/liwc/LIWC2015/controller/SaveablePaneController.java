/*    */ package com.liwc.LIWC2015.controller;
/*    */ 
/*    */ import com.liwc.LIWC2015.App;
/*    */ import com.liwc.LIWC2015.LiwcPreferences;
/*    */ import com.liwc.LIWC2015.Utils;
/*    */ import com.liwc.LIWC2015.customview.ExceptionDialog;
/*    */ import com.liwc.LIWC2015.customview.FileChooserWrapper;
/*    */ import com.liwc.LIWC2015.customview.LIWCAlert;
/*    */ import com.liwc.LIWC2015.customview.ResultPane;
/*    */ import java.io.File;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Optional;
/*    */ import javafx.collections.ObservableList;
/*    */ import javafx.scene.control.Alert.AlertType;
/*    */ import javafx.scene.control.ButtonBar.ButtonData;
/*    */ import javafx.scene.control.ButtonType;
/*    */ import javafx.stage.FileChooser;
/*    */ import javafx.stage.FileChooser.ExtensionFilter;
/*    */ import org.slf4j.Logger;
/*    */ 
/*    */ public abstract class SaveablePaneController implements IPaneController
/*    */ {
/* 24 */   private static final Logger logger = org.slf4j.LoggerFactory.getLogger(SaveablePaneController.class);
/*    */   
/*    */   protected App app;
/* 27 */   protected boolean saved = false;
/*    */   protected ResultPane resultPane;
/*    */   
/*    */   public SaveablePaneController(App app) {
/* 31 */     this.app = app;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean save()
/*    */   {
/* 38 */     LinkedHashMap<String, String> extensions = new LinkedHashMap() {};
/* 44 */     FileChooserWrapper wr = new FileChooserWrapper();
/* 45 */     FileChooser fileChooser = wr.getFileChooser();
/*    */     
/* 47 */     for (Map.Entry entry : extensions.entrySet()) {
/* 48 */       if (entry.getKey().equals(this.app.getLiwcPreferences().getLastSaveResultFormat())) {
/* 49 */         fileChooser.getExtensionFilters().add(0, new FileChooser.ExtensionFilter((String)entry.getValue(), new String[] { "*" + entry.getKey() }));
/*    */       } else {
/* 51 */         fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter((String)entry.getValue(), new String[] { "*" + entry.getKey() }));
/*    */       }
/*    */     }
/* 54 */     fileChooser.setTitle("Save Results");
/* 55 */     fileChooser.setInitialFileName(String.format("LIWC2015 Results (%s)", new Object[] { this.resultPane.getText() }) + this.app.getLiwcPreferences().getLastSaveResultFormat());
/* 56 */     Utils.setInitialFolder(fileChooser, this.app.getLiwcPreferences().getLastVisitedFolder());
/* 57 */     this.app.setModalIsOpen(true);
/* 58 */     File file = wr.showSaveDialog();
/* 59 */     this.app.setModalIsOpen(false);
/* 60 */     if (file != null) {
/* 61 */       String extension = file.getName().substring(file.getName().lastIndexOf('.'), file.getName().length());
/* 62 */       if (extensions.containsKey(extension)) {
/* 63 */         this.app.getLiwcPreferences().setLastSaveResultFormat(extension);
/*    */         try {
/* 65 */           this.app.getLiwcPreferences().setLastVisitedFolder(file.getParent());
/* 66 */           CancelableTask task = getSaveTask(file);
/* 67 */           ProgressDialogController.run(this.app, "/com/liwc/LIWC2015/view/ProgressDialog.fxml", new Object[] { task, Boolean.valueOf(false) });
/* 68 */           task.get();
/* 69 */           this.saved = true;
/* 70 */           LIWCAlert alert = new LIWCAlert(this.app, Alert.AlertType.CONFIRMATION, "LIWC2015", null, String.format("Would you like to open %s?", new Object[] { file.getName() }));
/* 71 */           ButtonType buttonTypeYes = new ButtonType("Yes", ButtonBar.ButtonData.YES);
/* 72 */           ButtonType buttonTypeNo = new ButtonType("No", ButtonBar.ButtonData.NO);
/* 73 */           alert.getButtonTypes().setAll(new ButtonType[] { buttonTypeYes, buttonTypeNo });
/* 74 */           Optional<ButtonType> result = alert.showAndWait();
/* 75 */           if (result.get() == buttonTypeYes) {
/* 76 */             Utils.openFile(this.app, file);
/*    */           }
/* 78 */           return true;
/*    */         } catch (Exception e) {
/* 80 */           logger.error(e.getLocalizedMessage(), e);
/* 81 */           this.app.setModalIsOpen(true);
/* 82 */           new ExceptionDialog(this.app, e).showAndWait();
/* 83 */           this.app.setModalIsOpen(false);
/*    */         }
/*    */       } else {
/* 86 */         Utils.showAlert(this.app, Alert.AlertType.ERROR, "LIWC2015", null, "Unsupported File Format");
/*    */       }
/*    */     }
/* 89 */     this.saved = false;
/* 90 */     return false;
/*    */   }
/*    */   
/*    */   public boolean isSaved()
/*    */   {
/* 95 */     return this.saved;
/*    */   }
/*    */   
/*    */   public abstract void close();
/*    */   
/*    */   protected abstract CancelableTask getSaveTask(File paramFile);
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/SaveablePaneController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */