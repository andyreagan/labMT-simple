package com.liwc.LIWC2015.customview;

public abstract interface ICloseable
{
  public abstract void close();
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/customview/ICloseable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */