package javax.xml.stream.events;

import java.util.List;

public abstract interface DTD
  extends XMLEvent
{
  public abstract String getDocumentTypeDeclaration();
  
  public abstract Object getProcessedDTD();
  
  public abstract List getNotations();
  
  public abstract List getEntities();
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/javax/xml/stream/events/DTD.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */