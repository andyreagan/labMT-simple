/*    */ package com.liwc.LIWC2015.model;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.List;
/*    */ import javax.xml.bind.JAXBContext;
/*    */ import javax.xml.bind.JAXBException;
/*    */ import javax.xml.bind.Unmarshaller;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ @XmlRootElement
/*    */ public class Dictionaries
/*    */ {
/* 18 */   public static String DictionariesPackage = "/com/liwc/LIWC2015/data/dict/";
/*    */   
/* 20 */   private static Logger logger = LoggerFactory.getLogger(Dictionaries.class);
/*    */   private List<Dictionary> dictionaries;
/*    */   
/*    */   public static Dictionaries load() throws IOException
/*    */   {
/*    */     try {
/* 26 */       InputStream is = Dictionaries.class.getResourceAsStream(DictionariesPackage + "dictionaries.xml");
/* 27 */       JAXBContext jaxbContext = JAXBContext.newInstance(new Class[] { Dictionaries.class });
/* 28 */       Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
/* 29 */       Dictionaries dictionaries = (Dictionaries)jaxbUnmarshaller.unmarshal(is);
/* 30 */       is.close();
/* 31 */       return dictionaries;
/*    */     } catch (JAXBException e) {
/* 33 */       logger.error(e.getLocalizedMessage(), e); }
/* 34 */     return new Dictionaries();
/*    */   }
/*    */   
/*    */   @XmlElement(name="dictionary")
/*    */   public List<Dictionary> getDictionaries()
/*    */   {
/* 40 */     return this.dictionaries;
/*    */   }
/*    */   
/*    */   public void setDictionaries(List<Dictionary> dictionaries) {
/* 44 */     this.dictionaries = dictionaries;
/*    */   }
/*    */   
/*    */   public Dictionary getDictionary(String id) {
/* 48 */     for (Dictionary dictionary : getDictionaries())
/* 49 */       if (id.equals(dictionary.getId()))
/* 50 */         return dictionary;
/* 51 */     return null;
/*    */   }
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/model/Dictionaries.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */