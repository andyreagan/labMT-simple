package com.microsoft.schemas.office.x2006.encryption;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.SchemaTypeSystem;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public abstract interface CTEncryption
  extends XmlObject
{
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CTEncryption.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0B482D0B338CC9641C1543C3510577FE").resolveHandle("ctencryption365ftype");
  
  public abstract CTKeyData getKeyData();
  
  public abstract void setKeyData(CTKeyData paramCTKeyData);
  
  public abstract CTKeyData addNewKeyData();
  
  public abstract CTDataIntegrity getDataIntegrity();
  
  public abstract void setDataIntegrity(CTDataIntegrity paramCTDataIntegrity);
  
  public abstract CTDataIntegrity addNewDataIntegrity();
  
  public abstract CTKeyEncryptors getKeyEncryptors();
  
  public abstract void setKeyEncryptors(CTKeyEncryptors paramCTKeyEncryptors);
  
  public abstract CTKeyEncryptors addNewKeyEncryptors();
  
  public static final class Factory
  {
    public static CTEncryption newInstance()
    {
      return (CTEncryption)XmlBeans.getContextTypeLoader().newInstance(CTEncryption.type, null);
    }
    
    public static CTEncryption newInstance(XmlOptions paramXmlOptions)
    {
      return (CTEncryption)XmlBeans.getContextTypeLoader().newInstance(CTEncryption.type, paramXmlOptions);
    }
    
    public static CTEncryption parse(String paramString)
      throws XmlException
    {
      return (CTEncryption)XmlBeans.getContextTypeLoader().parse(paramString, CTEncryption.type, null);
    }
    
    public static CTEncryption parse(String paramString, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (CTEncryption)XmlBeans.getContextTypeLoader().parse(paramString, CTEncryption.type, paramXmlOptions);
    }
    
    public static CTEncryption parse(File paramFile)
      throws XmlException, IOException
    {
      return (CTEncryption)XmlBeans.getContextTypeLoader().parse(paramFile, CTEncryption.type, null);
    }
    
    public static CTEncryption parse(File paramFile, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTEncryption)XmlBeans.getContextTypeLoader().parse(paramFile, CTEncryption.type, paramXmlOptions);
    }
    
    public static CTEncryption parse(URL paramURL)
      throws XmlException, IOException
    {
      return (CTEncryption)XmlBeans.getContextTypeLoader().parse(paramURL, CTEncryption.type, null);
    }
    
    public static CTEncryption parse(URL paramURL, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTEncryption)XmlBeans.getContextTypeLoader().parse(paramURL, CTEncryption.type, paramXmlOptions);
    }
    
    public static CTEncryption parse(InputStream paramInputStream)
      throws XmlException, IOException
    {
      return (CTEncryption)XmlBeans.getContextTypeLoader().parse(paramInputStream, CTEncryption.type, null);
    }
    
    public static CTEncryption parse(InputStream paramInputStream, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTEncryption)XmlBeans.getContextTypeLoader().parse(paramInputStream, CTEncryption.type, paramXmlOptions);
    }
    
    public static CTEncryption parse(Reader paramReader)
      throws XmlException, IOException
    {
      return (CTEncryption)XmlBeans.getContextTypeLoader().parse(paramReader, CTEncryption.type, null);
    }
    
    public static CTEncryption parse(Reader paramReader, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTEncryption)XmlBeans.getContextTypeLoader().parse(paramReader, CTEncryption.type, paramXmlOptions);
    }
    
    public static CTEncryption parse(XMLStreamReader paramXMLStreamReader)
      throws XmlException
    {
      return (CTEncryption)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, CTEncryption.type, null);
    }
    
    public static CTEncryption parse(XMLStreamReader paramXMLStreamReader, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (CTEncryption)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, CTEncryption.type, paramXmlOptions);
    }
    
    public static CTEncryption parse(Node paramNode)
      throws XmlException
    {
      return (CTEncryption)XmlBeans.getContextTypeLoader().parse(paramNode, CTEncryption.type, null);
    }
    
    public static CTEncryption parse(Node paramNode, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (CTEncryption)XmlBeans.getContextTypeLoader().parse(paramNode, CTEncryption.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static CTEncryption parse(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return (CTEncryption)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, CTEncryption.type, null);
    }
    
    /**
     * @deprecated
     */
    public static CTEncryption parse(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return (CTEncryption)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, CTEncryption.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, CTEncryption.type, null);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, CTEncryption.type, paramXmlOptions);
    }
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/encryption/CTEncryption.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */