package com.liwc.core;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public class LanguageSettings
{
  public static final String GenericWordPattern = "[\\p{L}\\d]*";
  public static final String EnglishWordPattern = "(ie\\.)|(i\\.e\\.)|(eg\\.)|(e\\.g\\.)|(vs\\.)|(ph\\.d\\.)|(phd\\.)|(m\\.d\\.)|(d\\.d\\.s\\.)|(b\\.a\\.)|(b\\.s\\.)|(m\\.s\\.)|(u\\.s\\.a\\.)|(u\\.s\\.)|(u\\.t\\.)|(attn\\.)|(((prof\\.)|(mr\\.)|(dr\\.)|(mrs\\.)|(ms\\.))?[\\p{L}\\d]*((('|’)[smd])|(('|’)ll)|(('|’)ve)|(('|’)t)|(('|’)nt))?)";
  public static final String EnglishWordSuffixPattern = "((('|’)[smd])|(('|’)ll)|(('|’)ve)|(('|’)t)|(('|’)nt))?";
  private Locale a;
  private String b = "";
  private String c = "";
  
  public LanguageSettings()
  {
    this(Locale.US);
  }
  
  public LanguageSettings(String paramString)
  {
    this(Locale.forLanguageTag(paramString));
  }
  
  public LanguageSettings(Locale paramLocale)
  {
    this(paramLocale, "(ie\\.)|(i\\.e\\.)|(eg\\.)|(e\\.g\\.)|(vs\\.)|(ph\\.d\\.)|(phd\\.)|(m\\.d\\.)|(d\\.d\\.s\\.)|(b\\.a\\.)|(b\\.s\\.)|(m\\.s\\.)|(u\\.s\\.a\\.)|(u\\.s\\.)|(u\\.t\\.)|(attn\\.)|(((prof\\.)|(mr\\.)|(dr\\.)|(mrs\\.)|(ms\\.))?[\\p{L}\\d]*((('|’)[smd])|(('|’)ll)|(('|’)ve)|(('|’)t)|(('|’)nt))?)", "((('|’)[smd])|(('|’)ll)|(('|’)ve)|(('|’)t)|(('|’)nt))?");
  }
  
  public LanguageSettings(Locale paramLocale, String paramString1, String paramString2)
  {
    this.a = paramLocale;
    paramLocale.getLanguage();
    ((DecimalFormat)DecimalFormat.getInstance(paramLocale)).getDecimalFormatSymbols().getDecimalSeparator();
    this.b = paramString1;
    this.c = paramString2;
  }
  
  public String getWordPattern()
  {
    return this.b;
  }
  
  public String getWordSuffixPattern()
  {
    return this.c;
  }
  
  public Locale getLocale()
  {
    return this.a;
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/core/LanguageSettings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */