package com.microsoft.schemas.office.x2006.encryption;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.SchemaTypeSystem;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.XmlUnsignedInt;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public abstract interface STSpinCount
  extends XmlUnsignedInt
{
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(STSpinCount.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0B482D0B338CC9641C1543C3510577FE").resolveHandle("stspincount544ftype");
  
  public abstract int getIntValue();
  
  public abstract void setIntValue(int paramInt);
  
  /**
   * @deprecated
   */
  public abstract int intValue();
  
  /**
   * @deprecated
   */
  public abstract void set(int paramInt);
  
  public static final class Factory
  {
    public static STSpinCount newValue(Object paramObject)
    {
      return (STSpinCount)STSpinCount.type.newValue(paramObject);
    }
    
    public static STSpinCount newInstance()
    {
      return (STSpinCount)XmlBeans.getContextTypeLoader().newInstance(STSpinCount.type, null);
    }
    
    public static STSpinCount newInstance(XmlOptions paramXmlOptions)
    {
      return (STSpinCount)XmlBeans.getContextTypeLoader().newInstance(STSpinCount.type, paramXmlOptions);
    }
    
    public static STSpinCount parse(String paramString)
      throws XmlException
    {
      return (STSpinCount)XmlBeans.getContextTypeLoader().parse(paramString, STSpinCount.type, null);
    }
    
    public static STSpinCount parse(String paramString, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (STSpinCount)XmlBeans.getContextTypeLoader().parse(paramString, STSpinCount.type, paramXmlOptions);
    }
    
    public static STSpinCount parse(File paramFile)
      throws XmlException, IOException
    {
      return (STSpinCount)XmlBeans.getContextTypeLoader().parse(paramFile, STSpinCount.type, null);
    }
    
    public static STSpinCount parse(File paramFile, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (STSpinCount)XmlBeans.getContextTypeLoader().parse(paramFile, STSpinCount.type, paramXmlOptions);
    }
    
    public static STSpinCount parse(URL paramURL)
      throws XmlException, IOException
    {
      return (STSpinCount)XmlBeans.getContextTypeLoader().parse(paramURL, STSpinCount.type, null);
    }
    
    public static STSpinCount parse(URL paramURL, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (STSpinCount)XmlBeans.getContextTypeLoader().parse(paramURL, STSpinCount.type, paramXmlOptions);
    }
    
    public static STSpinCount parse(InputStream paramInputStream)
      throws XmlException, IOException
    {
      return (STSpinCount)XmlBeans.getContextTypeLoader().parse(paramInputStream, STSpinCount.type, null);
    }
    
    public static STSpinCount parse(InputStream paramInputStream, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (STSpinCount)XmlBeans.getContextTypeLoader().parse(paramInputStream, STSpinCount.type, paramXmlOptions);
    }
    
    public static STSpinCount parse(Reader paramReader)
      throws XmlException, IOException
    {
      return (STSpinCount)XmlBeans.getContextTypeLoader().parse(paramReader, STSpinCount.type, null);
    }
    
    public static STSpinCount parse(Reader paramReader, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (STSpinCount)XmlBeans.getContextTypeLoader().parse(paramReader, STSpinCount.type, paramXmlOptions);
    }
    
    public static STSpinCount parse(XMLStreamReader paramXMLStreamReader)
      throws XmlException
    {
      return (STSpinCount)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, STSpinCount.type, null);
    }
    
    public static STSpinCount parse(XMLStreamReader paramXMLStreamReader, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (STSpinCount)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, STSpinCount.type, paramXmlOptions);
    }
    
    public static STSpinCount parse(Node paramNode)
      throws XmlException
    {
      return (STSpinCount)XmlBeans.getContextTypeLoader().parse(paramNode, STSpinCount.type, null);
    }
    
    public static STSpinCount parse(Node paramNode, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (STSpinCount)XmlBeans.getContextTypeLoader().parse(paramNode, STSpinCount.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static STSpinCount parse(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return (STSpinCount)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, STSpinCount.type, null);
    }
    
    /**
     * @deprecated
     */
    public static STSpinCount parse(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return (STSpinCount)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, STSpinCount.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, STSpinCount.type, null);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, STSpinCount.type, paramXmlOptions);
    }
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/encryption/STSpinCount.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */