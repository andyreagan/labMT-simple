/*    */ package com.liwc.LIWC2015.controller;
/*    */ 
/*    */ import com.liwc.LIWC2015.App;
/*    */ import com.liwc.LIWC2015.LiwcPreferences;
/*    */ import com.liwc.LIWC2015.Utils;
/*    */ import java.net.URL;
/*    */ import java.util.ResourceBundle;
/*    */ import javafx.application.HostServices;
/*    */ import javafx.beans.property.StringProperty;
/*    */ import javafx.beans.value.ChangeListener;
/*    */ import javafx.beans.value.ObservableValue;
/*    */ import javafx.collections.ObservableList;
/*    */ import javafx.fxml.FXML;
/*    */ import javafx.scene.Scene;
/*    */ import javafx.scene.control.Button;
/*    */ import javafx.scene.control.TextField;
/*    */ import javafx.stage.Modality;
/*    */ import javafx.stage.Stage;
/*    */ 
/*    */ public class RegisterDialogController extends ModalDialogController implements javafx.fxml.Initializable
/*    */ {
/*    */   @FXML
/*    */   private javafx.scene.layout.VBox vBox;
/*    */   @FXML
/*    */   private TextField serialNumberField;
/*    */   @FXML
/*    */   private Button registerButton;
/* 28 */   private String serialNumber = "";
/* 29 */   private boolean closedByUser = true;
/*    */   
/*    */ 
/*    */   public void initialize(URL location, ResourceBundle resources) {}
/*    */   
/*    */ 
/*    */   public Stage initStage(App app, Object... args)
/*    */     throws Exception
/*    */   {
/* 38 */     Scene newScene = new Scene(this.vBox);
/* 39 */     newScene.getStylesheets().add("/com/liwc/LIWC2015/styles/RegisterDialogStyles.css");
/* 40 */     Stage stage = new Stage();
/* 41 */     stage.setScene(newScene);
/* 42 */     stage.setResizable(false);
/* 43 */     stage.initModality(Modality.APPLICATION_MODAL);
/* 44 */     if (!Utils.isMac())
/* 45 */       stage.initStyle(javafx.stage.StageStyle.UTILITY);
/* 46 */     stage.initOwner(null);
/* 47 */     stage.setTitle("");
/* 48 */     this.serialNumberField.textProperty().addListener(new ChangeListener()
/*    */     {
/*    */       public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
/* 51 */         RegisterDialogController.this.registerButton.setDisable((newValue == null) || (newValue.isEmpty()));
/*    */       }
/* 53 */     });
/* 54 */     this.serialNumberField.setText(app.getLiwcPreferences().getSerialNumber());
/* 55 */     this.registerButton.setDisable((this.serialNumberField.getText() == null) || (this.serialNumberField.getText().isEmpty()));
/* 56 */     return stage;
/*    */   }
/*    */   
/*    */   public final void onRegister() {
/* 60 */     this.serialNumber = this.serialNumberField.getText();
/* 61 */     this.closedByUser = false;
/* 62 */     this.stage.close();
/*    */   }
/*    */   
/*    */   public final String getSerialNumber() {
/* 66 */     return this.serialNumber;
/*    */   }
/*    */   
/*    */   public boolean isClosedByUser() {
/* 70 */     return this.closedByUser;
/*    */   }
/*    */   
/*    */   public void goToLiwcSite() {
/* 74 */     this.app.getHostServices().showDocument("http://www.liwc.net");
/*    */   }
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/RegisterDialogController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */