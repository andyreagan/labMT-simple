/*     */ package org.apache.commons.collections.bag;
/*     */ 
/*     */ import java.util.Set;
/*     */ import org.apache.commons.collections.Bag;
/*     */ import org.apache.commons.collections.collection.SynchronizedCollection;
/*     */ import org.apache.commons.collections.set.SynchronizedSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SynchronizedBag
/*     */   extends SynchronizedCollection
/*     */   implements Bag
/*     */ {
/*     */   private static final long serialVersionUID = 8084674570753837109L;
/*     */   
/*     */   public static Bag decorate(Bag bag)
/*     */   {
/*  53 */     return new SynchronizedBag(bag);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected SynchronizedBag(Bag bag)
/*     */   {
/*  64 */     super(bag);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected SynchronizedBag(Bag bag, Object lock)
/*     */   {
/*  75 */     super(bag, lock);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Bag getBag()
/*     */   {
/*  84 */     return (Bag)this.collection;
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean add(Object object, int count)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 7	org/apache/commons/collections/bag/SynchronizedBag:lock	Ljava/lang/Object;
/*     */     //   4: dup
/*     */     //   5: astore_3
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: invokevirtual 8	org/apache/commons/collections/bag/SynchronizedBag:getBag	()Lorg/apache/commons/collections/Bag;
/*     */     //   11: aload_1
/*     */     //   12: iload_2
/*     */     //   13: invokeinterface 9 3 0
/*     */     //   18: aload_3
/*     */     //   19: monitorexit
/*     */     //   20: ireturn
/*     */     //   21: astore 4
/*     */     //   23: aload_3
/*     */     //   24: monitorexit
/*     */     //   25: aload 4
/*     */     //   27: athrow
/*     */     // Line number table:
/*     */     //   Java source line #89	-> byte code offset #0
/*     */     //   Java source line #90	-> byte code offset #7
/*     */     //   Java source line #91	-> byte code offset #21
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	28	0	this	SynchronizedBag
/*     */     //   0	28	1	object	Object
/*     */     //   0	28	2	count	int
/*     */     //   5	19	3	Ljava/lang/Object;	Object
/*     */     //   21	5	4	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	20	21	finally
/*     */     //   21	25	21	finally
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public boolean remove(Object object, int count)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 7	org/apache/commons/collections/bag/SynchronizedBag:lock	Ljava/lang/Object;
/*     */     //   4: dup
/*     */     //   5: astore_3
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: invokevirtual 8	org/apache/commons/collections/bag/SynchronizedBag:getBag	()Lorg/apache/commons/collections/Bag;
/*     */     //   11: aload_1
/*     */     //   12: iload_2
/*     */     //   13: invokeinterface 10 3 0
/*     */     //   18: aload_3
/*     */     //   19: monitorexit
/*     */     //   20: ireturn
/*     */     //   21: astore 4
/*     */     //   23: aload_3
/*     */     //   24: monitorexit
/*     */     //   25: aload 4
/*     */     //   27: athrow
/*     */     // Line number table:
/*     */     //   Java source line #95	-> byte code offset #0
/*     */     //   Java source line #96	-> byte code offset #7
/*     */     //   Java source line #97	-> byte code offset #21
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	28	0	this	SynchronizedBag
/*     */     //   0	28	1	object	Object
/*     */     //   0	28	2	count	int
/*     */     //   5	19	3	Ljava/lang/Object;	Object
/*     */     //   21	5	4	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	20	21	finally
/*     */     //   21	25	21	finally
/*     */   }
/*     */   
/*     */   public Set uniqueSet()
/*     */   {
/* 101 */     synchronized (this.lock) {
/* 102 */       Set set = getBag().uniqueSet();
/* 103 */       return new SynchronizedBagSet(set, this.lock);
/*     */     }
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public int getCount(Object object)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 7	org/apache/commons/collections/bag/SynchronizedBag:lock	Ljava/lang/Object;
/*     */     //   4: dup
/*     */     //   5: astore_2
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: invokevirtual 8	org/apache/commons/collections/bag/SynchronizedBag:getBag	()Lorg/apache/commons/collections/Bag;
/*     */     //   11: aload_1
/*     */     //   12: invokeinterface 14 2 0
/*     */     //   17: aload_2
/*     */     //   18: monitorexit
/*     */     //   19: ireturn
/*     */     //   20: astore_3
/*     */     //   21: aload_2
/*     */     //   22: monitorexit
/*     */     //   23: aload_3
/*     */     //   24: athrow
/*     */     // Line number table:
/*     */     //   Java source line #108	-> byte code offset #0
/*     */     //   Java source line #109	-> byte code offset #7
/*     */     //   Java source line #110	-> byte code offset #20
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	25	0	this	SynchronizedBag
/*     */     //   0	25	1	object	Object
/*     */     //   5	17	2	Ljava/lang/Object;	Object
/*     */     //   20	4	3	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	19	20	finally
/*     */     //   20	23	20	finally
/*     */   }
/*     */   
/*     */   class SynchronizedBagSet
/*     */     extends SynchronizedSet
/*     */   {
/*     */     SynchronizedBagSet(Set set, Object lock)
/*     */     {
/* 124 */       super(lock);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/org/apache/commons/collections/bag/SynchronizedBag.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */