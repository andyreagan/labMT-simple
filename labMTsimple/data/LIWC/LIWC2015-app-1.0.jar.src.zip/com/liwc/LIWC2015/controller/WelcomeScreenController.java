/*     */ package com.liwc.LIWC2015.controller;
/*     */ 
/*     */ import com.liwc.LIWC2015.App;
/*     */ import com.liwc.LIWC2015.LiwcPreferences.Categories;
/*     */ import com.liwc.LIWC2015.LiwcPreferences.SegmentOptions;
/*     */ import com.liwc.LIWC2015.Utils;
/*     */ import com.liwc.LIWC2015.customview.LIWCAlert;
/*     */ import com.liwc.LIWC2015.model.WelcomeScreenModel;
/*     */ import com.liwc.core.dictionary.IDictionary;
/*     */ import java.util.List;
/*     */ import javafx.beans.property.StringProperty;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.fxml.FXML;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.Scene;
/*     */ import javafx.scene.control.ButtonType;
/*     */ import javafx.scene.control.CheckBox;
/*     */ import javafx.scene.control.Hyperlink;
/*     */ import javafx.scene.control.Label;
/*     */ import javafx.scene.layout.VBox;
/*     */ import javafx.stage.Stage;
/*     */ 
/*     */ public class WelcomeScreenController extends ModelessWindowController implements javafx.fxml.Initializable
/*     */ {
/*  27 */   private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(WelcomeScreenController.class);
/*     */   
/*     */   @FXML
/*     */   private VBox vBox;
/*     */   @FXML
/*     */   private Hyperlink analyzeTextLink;
/*     */   @FXML
/*     */   private Hyperlink categorizeWordsLink;
/*     */   @FXML
/*     */   private Hyperlink colorCodeLink;
/*     */   @FXML
/*     */   private Hyperlink categoryOptionsLink;
/*     */   @FXML
/*     */   private Hyperlink helpLink;
/*     */   @FXML
/*     */   private CheckBox showWelcomeScreenCheckbox;
/*     */   @FXML
/*     */   private Label dictionaryLabel;
/*     */   @FXML
/*     */   private Label segmentOptionsLabel;
/*     */   @FXML
/*     */   private Label allCategoriesOnLabel;
/*     */   @FXML
/*     */   private VBox dictionaryBox;
/*     */   private WelcomeScreenModel model;
/*     */   
/*     */   public static String buildSegmentOptionsString(LiwcPreferences.SegmentOptions so)
/*     */   {
/*  55 */     switch (so.getType()) {
/*     */     case 1: 
/*  57 */       return String.format("Number of segments: %d", new Object[] { so.getNumberOfSegments() });
/*     */     case 2: 
/*  59 */       return String.format("%d words per segment", new Object[] { so.getWordsPerSegment() });
/*     */     case 3: 
/*  61 */       return String.format("Special character(s): %s", new Object[] { so.getSpecialCharacters().replaceFirst("custom\\.", "") });
/*     */     case 4: 
/*  63 */       return String.format("%d carriage returns", new Object[] { so.getNumberOfCarriageReturns() });
/*     */     }
/*  65 */     return "No segmentation";
/*     */   }
/*     */   
/*     */   public static String buildCategoriesString(LiwcPreferences.Categories categories, IDictionary dictionary)
/*     */   {
/*  70 */     if (categories.getSelectAll())
/*  71 */       return "YES";
/*  72 */     List<String> c1 = new java.util.ArrayList(dictionary.getCategoriesPlain().values());
/*  73 */     c1.addAll(IDictionary.PunctuationMarksCategories.values());
/*  74 */     c1.add("AllPunc");
/*  75 */     if (c1.size() != categories.getCategories().size())
/*  76 */       return "NO";
/*  77 */     return (c1.containsAll(categories.getCategories())) && (categories.getCategories().containsAll(c1)) ? "YES" : "NO";
/*     */   }
/*     */   
/*     */   public void initialize(java.net.URL location, java.util.ResourceBundle resources)
/*     */   {
/*  82 */     this.analyzeTextLink.getStyleClass().addAll(new String[] { "left", "analyze-text" });
/*  83 */     this.categorizeWordsLink.getStyleClass().addAll(new String[] { "left", "categorize-words" });
/*  84 */     this.colorCodeLink.getStyleClass().addAll(new String[] { "left", "color-code-text" });
/*  85 */     this.categoryOptionsLink.getStyleClass().addAll(new String[] { "right", "category-options" });
/*  86 */     this.helpLink.getStyleClass().addAll(new String[] { "right", "help" });
/*     */   }
/*     */   
/*     */   public Stage initStage(final App app, Object... args) throws Exception
/*     */   {
/*  91 */     Scene newScene = new Scene(this.vBox);
/*  92 */     newScene.getStylesheets().add("/com/liwc/LIWC2015/styles/WelcomeScreenStyles.css");
/*  93 */     Stage stage = new Stage();
/*  94 */     stage.setScene(newScene);
/*  95 */     stage.setResizable(false);
/*  96 */     if (!Utils.isMac())
/*  97 */       stage.initStyle(javafx.stage.StageStyle.UTILITY);
/*  98 */     stage.initOwner(Utils.isMac() ? null : app.getStage());
/*     */     
/* 100 */     this.showWelcomeScreenCheckbox.setSelected(app.getLiwcPreferences().getShowWelcomeScreen());
/* 101 */     this.showWelcomeScreenCheckbox.selectedProperty().addListener(new ChangeListener()
/*     */     {
/*     */       public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
/* 104 */         app.getLiwcPreferences().setShowWelcomeScreen(newValue.booleanValue());
/*     */       }
/*     */     });
/*     */     
/* 108 */     if (Utils.isMac()) {
/* 109 */       stage.focusedProperty().addListener(new ChangeListener()
/*     */       {
/*     */         public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
/* 112 */           if (newValue.booleanValue()) {
/* 113 */             if (!WelcomeScreenController.this.vBox.getChildren().contains(app.getMenuBar())) {
/* 114 */               WelcomeScreenController.this.vBox.getChildren().addAll(new Node[] { app.getMenuBar() });
/*     */             }
/* 116 */           } else if (!app.getRoot().getChildren().contains(app.getMenuBar())) {
/* 117 */             app.getRoot().getChildren().addAll(new Node[] { app.getMenuBar() });
/*     */           }
/*     */         }
/*     */       });
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 125 */     return stage;
/*     */   }
/*     */   
/*     */   public void onAnalyzeText() {
/* 129 */     LIWCAlert a = new LIWCAlert(this.app, javafx.scene.control.Alert.AlertType.CONFIRMATION, "LIWC2015", null, "What would you like to analyze?");
/* 130 */     a.getButtonTypes().setAll(new ButtonType[] { new ButtonType("Text file(s)"), new ButtonType("Text in folder"), new ButtonType("Excel/CSV file") });
/* 131 */     this.app.setModalIsOpen(true);
/* 132 */     java.util.Optional<ButtonType> btn = a.showAndWait();
/* 133 */     this.app.setModalIsOpen(false);
/* 134 */     switch (((ButtonType)btn.get()).getText()) {
/*     */     case "Text file(s)": 
/* 136 */       new TextAnalyzer(this.app).run(0);
/* 137 */       break;
/*     */     case "Text in folder": 
/* 139 */       new TextAnalyzer(this.app).run(1);
/* 140 */       break;
/*     */     case "Excel/CSV file": 
/* 142 */       new ExcelCsvAnalyzer(this.app).run();
/* 143 */       break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */   public void onCategorizeWords()
/*     */   {
/* 150 */     new WordCategorizer(this.app).run();
/*     */   }
/*     */   
/*     */   public void onColorCodeText() {
/* 154 */     new TextColorCoder(this.app).run();
/*     */   }
/*     */   
/*     */   public void onCategoryOptions() {
/* 158 */     CategoriesDialogController.run(this.app, "/com/liwc/LIWC2015/view/CategoriesDialog.fxml", new Object[0]);
/*     */   }
/*     */   
/*     */   public void onHelp() {
/* 162 */     this.app.openHelpWindow();
/*     */   }
/*     */   
/*     */   public void setModel(WelcomeScreenModel model) {
/* 166 */     this.model = model;
/* 167 */     this.dictionaryLabel.textProperty().bind(model.activeDictionaryNameProperty());
/* 168 */     this.segmentOptionsLabel.textProperty().bind(model.segmentOptionsProperty());
/* 169 */     this.allCategoriesOnLabel.textProperty().bind(model.allCategoriesOnProperty());
/*     */   }
/*     */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/WelcomeScreenController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */