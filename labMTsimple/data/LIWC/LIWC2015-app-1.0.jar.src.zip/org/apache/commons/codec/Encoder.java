package org.apache.commons.codec;

public abstract interface Encoder
{
  public abstract Object encode(Object paramObject)
    throws EncoderException;
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/org/apache/commons/codec/Encoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */