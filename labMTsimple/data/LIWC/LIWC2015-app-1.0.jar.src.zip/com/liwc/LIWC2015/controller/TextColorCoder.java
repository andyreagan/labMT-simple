/*     */ package com.liwc.LIWC2015.controller;
/*     */ 
/*     */ import com.liwc.LIWC2015.App;
/*     */ import com.liwc.LIWC2015.LiwcPreferences;
/*     */ import com.liwc.LIWC2015.LiwcPreferences.Categories;
/*     */ import com.liwc.LIWC2015.Utils;
/*     */ import com.liwc.LIWC2015.customview.ExceptionDialog;
/*     */ import com.liwc.LIWC2015.customview.FileChooserWrapper;
/*     */ import com.liwc.core.dictionary.IDictionary;
/*     */ import com.liwc.core.text.IText;
/*     */ import com.liwc.core.text.TextParser;
/*     */ import com.liwc.core.text.TextToken;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.InputStream;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.stage.FileChooser;
/*     */ import javafx.stage.FileChooser.ExtensionFilter;
/*     */ import org.slf4j.Logger;
/*     */ 
/*     */ public class TextColorCoder
/*     */ {
/*  26 */   private static final Logger logger = org.slf4j.LoggerFactory.getLogger(TextColorCoder.class);
/*     */   private App app;
/*     */   
/*     */   public TextColorCoder(App app)
/*     */   {
/*  31 */     this.app = app;
/*     */   }
/*     */   
/*     */   public void run() {
/*  35 */     FileChooserWrapper wr = new FileChooserWrapper();
/*  36 */     FileChooser fileChooser = wr.getFileChooser();
/*  37 */     fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("All Text Documents (*.txt, *.doc, *.docx, *.rtf, *.pdf)", new String[] { "*.txt", "*.doc", "*.docx", "*.rtf", "*.pdf" }));
/*  38 */     fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text Files (*.txt)", new String[] { "*.txt" }));
/*  39 */     fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Word Documents (*.doc, *.docx)", new String[] { "*.doc", "*.docx" }));
/*  40 */     fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("RTF Documents (*.rtf)", new String[] { "*.rtf" }));
/*  41 */     fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF Documents (*.pdf)", new String[] { "*.pdf" }));
/*  42 */     fileChooser.setTitle("Select Text File");
/*  43 */     Utils.setInitialFolder(fileChooser, this.app.getLiwcPreferences().getLastVisitedFolder());
/*  44 */     this.app.setModalIsOpen(true);
/*  45 */     File file = wr.showOpenDialog();
/*  46 */     this.app.setModalIsOpen(false);
/*  47 */     if (file != null) {
/*     */       try {
/*  49 */         this.app.getLiwcPreferences().setLastVisitedFolder(file.getParent());
/*  50 */         WordColorCoderTask task = new WordColorCoderTask(this.app, file, null);
/*  51 */         ProgressDialogController.run(this.app, "/com/liwc/LIWC2015/view/ProgressDialog.fxml", new Object[] { task, Boolean.valueOf(false) });
/*  52 */         File result = (File)task.get();
/*  53 */         result.deleteOnExit();
/*  54 */         ColorCodeTextPaneController controller = new ColorCodeTextPaneController(this.app);
/*  55 */         controller.build(Utils.getFilenameWithoutExtension(file), result);
/*     */       } catch (Exception e) {
/*  57 */         logger.error(e.getLocalizedMessage(), e);
/*  58 */         this.app.setModalIsOpen(true);
/*  59 */         new ExceptionDialog(this.app, e).showAndWait();
/*  60 */         this.app.setModalIsOpen(false);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static class WordColorCoderTask extends CancelableTask<File>
/*     */   {
/*  67 */     private static final byte[] br = "<br/>".getBytes();
/*  68 */     private static final byte[] spanOpen = "<span class=\"span-black\">".getBytes();
/*  69 */     private static final byte[] redSpanOpen = "<span class=\"span-red\">".getBytes();
/*  70 */     private static final byte[] spanClose = "</span>".getBytes();
/*  71 */     private static final byte[] htmlHead = "<html>\n<head>\n<style>\n@font-face {\nfont-family: 'Titillium Regular';\nsrc: url(\"titillium-regular-webfont.ttf\");\n}\n@font-face {\nfont-family: 'Titillium Bold';\nsrc: url(\"Titillium-Bold.otf\");\n}\n.span-red {\ncolor:#E74E31;\nfont-size:13px;\nfont-family:'Titillium Bold';\n}\n.span-black {\ncolor:#4E4E4A;\nfont-size:13px;\nfont-family:'Titillium Regular';\n}\n</style>\n</head>\n<body>"
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  94 */       .getBytes();
/*  95 */     private static byte[] htmlFoot = "</body>\n</html>".getBytes();
/*     */     private App app;
/*     */     private File file;
/*     */     
/*     */     private WordColorCoderTask(App app, File file)
/*     */     {
/* 101 */       this.app = app;
/* 102 */       this.file = file;
/*     */     }
/*     */     
/*     */     protected File call() throws Exception
/*     */     {
/* 107 */       List<Integer> catsToCheck = new java.util.ArrayList();
/* 108 */       if (this.app.getLiwcPreferences().getCategories().getSelectAll()) {
/* 109 */         catsToCheck.addAll(this.app.getActiveDictionary().getCategoriesPlain().keySet());
/*     */       } else {
/* 111 */         for (Map.Entry<Integer, String> entry : this.app.getActiveDictionary().getCategoriesPlain().entrySet()) {
/* 112 */           if (this.app.getLiwcPreferences().getCategories().getCategories().contains(entry.getValue()))
/* 113 */             catsToCheck.add(entry.getKey());
/*     */         }
/*     */       }
/* 116 */       File result = File.createTempFile("liwc2015", ".html");
/*     */       
/* 118 */       String tempFolder = result.getParent();
/*     */       
/* 120 */       copyFontStream("titillium-regular-webfont.ttf", tempFolder);
/* 121 */       copyFontStream("Titillium-Bold.otf", tempFolder);
/*     */       
/* 123 */       FileOutputStream fos = new FileOutputStream(result);
/* 124 */       updateMessage("Processing...");
/* 125 */       IText text = com.liwc.core.text.TextFactory.getText(this.file);
/* 126 */       TextParser parser = new TextParser(this.app.getActiveDictionary(), new com.liwc.core.LanguageSettings(this.app.getLiwcPreferences().getLocale()));
/* 127 */       List<TextToken> tokens = text.readText(parser);
/*     */       
/* 129 */       fos.write(htmlHead);
/* 130 */       for (int i = 0; i < tokens.size(); i++) {
/* 131 */         TextToken token = (TextToken)tokens.get(i);
/* 132 */         if (token.isLineEnding()) {
/* 133 */           fos.write(br);
/*     */         } else {
/* 135 */           List<Integer> cats = null;
/* 136 */           if ((token.isWord()) && ((cats = this.app.getActiveDictionary().findWord(token.getTokenValue())) != null) && (!org.apache.commons.collections.CollectionUtils.intersection(cats, catsToCheck).isEmpty())) {
/* 137 */             fos.write(redSpanOpen);
/*     */           } else
/* 139 */             fos.write(spanOpen);
/* 140 */           fos.write(token.getTokenValue().getBytes());
/* 141 */           fos.write(spanClose);
/*     */         }
/* 143 */         updateProgress(i + 1, tokens.size());
/*     */       }
/* 145 */       fos.write(htmlFoot);
/*     */       
/* 147 */       text.close();
/* 148 */       fos.close();
/* 149 */       return result;
/*     */     }
/*     */     
/*     */     private void copyFontStream(String fontName, String destinationFolder) throws java.io.IOException {
/* 153 */       File fontFile = new File(destinationFolder + File.separator + fontName);
/* 154 */       if (fontFile.exists())
/* 155 */         return;
/* 156 */       InputStream is = WordColorCoderTask.class.getResourceAsStream("/com/liwc/LIWC2015/fonts/" + fontName);
/* 157 */       FileOutputStream fos = new FileOutputStream(fontFile);
/* 158 */       int bufLen = 65536;
/* 159 */       byte[] bytes = new byte[bufLen];
/*     */       for (;;) {
/* 161 */         int len = is.read(bytes, 0, bufLen);
/* 162 */         if (len <= 0) break;
/* 163 */         fos.write(bytes, 0, len);
/*     */       }
/*     */       
/*     */ 
/* 167 */       fos.close();
/* 168 */       is.close();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/TextColorCoder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */