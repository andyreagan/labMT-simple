package javax.xml.stream.events;

public abstract interface Characters
  extends XMLEvent
{
  public abstract String getData();
  
  public abstract boolean isWhiteSpace();
  
  public abstract boolean isCData();
  
  public abstract boolean isIgnorableWhiteSpace();
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/javax/xml/stream/events/Characters.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */