/*     */ package com.liwc.LIWC2015.controller;
/*     */ 
/*     */ import com.liwc.LIWC2015.App;
/*     */ import com.liwc.LIWC2015.LiwcPreferences;
/*     */ import com.liwc.LIWC2015.Utils;
/*     */ import com.sun.javafx.scene.control.skin.LabeledText;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.ResourceBundle;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ListChangeListener;
/*     */ import javafx.collections.ListChangeListener.Change;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.fxml.FXML;
/*     */ import javafx.fxml.Initializable;
/*     */ import javafx.scene.Scene;
/*     */ import javafx.scene.control.Button;
/*     */ import javafx.scene.control.Label;
/*     */ import javafx.scene.control.TableColumn;
/*     */ import javafx.scene.control.TableColumn.CellDataFeatures;
/*     */ import javafx.scene.control.TablePosition;
/*     */ import javafx.scene.control.TableView;
/*     */ import javafx.scene.control.TableView.TableViewSelectionModel;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.layout.VBox;
/*     */ import javafx.stage.Modality;
/*     */ import javafx.stage.Stage;
/*     */ import org.apache.commons.csv.CSVFormat;
/*     */ import org.apache.commons.csv.CSVParser;
/*     */ import org.apache.commons.csv.CSVRecord;
/*     */ import org.apache.commons.io.ByteOrderMark;
/*     */ import org.apache.commons.io.input.BOMInputStream;
/*     */ import org.apache.poi.openxml4j.opc.OPCPackage;
/*     */ import org.apache.poi.ss.usermodel.DataFormatter;
/*     */ import org.apache.poi.ss.usermodel.Row;
/*     */ import org.apache.poi.ss.usermodel.Sheet;
/*     */ import org.apache.poi.ss.usermodel.Workbook;
/*     */ import org.apache.poi.ss.usermodel.WorkbookFactory;
/*     */ import org.apache.poi.xssf.eventusermodel.XSSFReader;
/*     */ import org.apache.poi.xssf.eventusermodel.XSSFReader.SheetIterator;
/*     */ import org.apache.poi.xssf.usermodel.XSSFComment;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.XMLReader;
/*     */ 
/*     */ public class ExcelCsvPreviewDialogController extends ModalDialogController implements Initializable
/*     */ {
/*  54 */   private static final Logger logger = LoggerFactory.getLogger(ExcelCsvPreviewDialogController.class);
/*     */   private static final int maxFileSize = 5242880;
/*     */   @FXML
/*     */   private VBox vBox;
/*     */   @FXML
/*     */   private TableView tableView;
/*     */   @FXML
/*     */   private Button analyzeButton;
/*     */   private ObservableList<List<String>> data;
/*     */   private boolean analyzeClicked;
/*     */   private List<Float> columnWidths;
/*     */   
/*  66 */   public ExcelCsvPreviewDialogController() { this.data = FXCollections.observableArrayList();
/*     */     
/*  68 */     this.analyzeClicked = false;
/*     */     
/*  70 */     this.columnWidths = null;
/*     */   }
/*     */   
/*     */ 
/*     */   public void initialize(URL location, ResourceBundle resources) {}
/*     */   
/*     */   public Stage getStage()
/*     */   {
/*  78 */     return (Stage)this.vBox.getScene().getWindow();
/*     */   }
/*     */   
/*     */   public void onCancel() {
/*  82 */     getStage().close();
/*     */   }
/*     */   
/*     */   public void onAnalyze() {
/*  86 */     this.analyzeClicked = true;
/*  87 */     getStage().close();
/*     */   }
/*     */   
/*     */   public ObservableList<List<String>> getData() {
/*  91 */     return this.data;
/*     */   }
/*     */   
/*     */   public void openExcelFile(File file) throws Exception {
/*  95 */     openExcelFileInt(file);
/*  96 */     initializeTableView();
/*     */   }
/*     */   
/*     */   public List<TablePosition> getSelectedCells() {
/* 100 */     return this.tableView.getSelectionModel().getSelectedCells();
/*     */   }
/*     */   
/*     */   public boolean isAnalyzeClicked() {
/* 104 */     return this.analyzeClicked;
/*     */   }
/*     */   
/*     */   public List<Float> getColumnWidths() {
/* 108 */     return this.columnWidths;
/*     */   }
/*     */   
/*     */   public Stage initStage(App app, Object... args) throws Exception
/*     */   {
/* 113 */     Scene scene = new Scene(this.vBox);
/* 114 */     scene.getStylesheets().addAll(new String[] { "/com/liwc/LIWC2015/styles/ResultPaneStyles.css" });
/* 115 */     Stage stage = new Stage();
/* 116 */     stage.setScene(scene);
/* 117 */     stage.setMinWidth(400.0D);
/* 118 */     stage.setMinHeight(400.0D);
/* 119 */     if (!Utils.isMac())
/* 120 */       stage.initStyle(javafx.stage.StageStyle.UTILITY);
/* 121 */     stage.initModality(Modality.APPLICATION_MODAL);
/* 122 */     stage.initOwner(null);
/* 123 */     openExcelFileInt((File)args[0]);
/* 124 */     initializeTableView();
/* 125 */     return stage;
/*     */   }
/*     */   
/*     */   private void openExcelFileInt(File file) throws Exception {
/* 129 */     OpenExcelFileTask task = file.getAbsolutePath().endsWith(".csv") ? new OpenCsvFileTask(this.app, file, null) : new OpenExcelFileTask(this.app, file, null);
/* 130 */     ProgressDialogController.run(this.app, "/com/liwc/LIWC2015/view/ProgressDialog.fxml", new Object[] { task, Boolean.valueOf(false) });
/* 131 */     this.data = ((ObservableList)task.get());
/* 132 */     this.columnWidths = task.getColumnWidths();
/*     */   }
/*     */   
/*     */   private void initializeTableView() {
/* 136 */     this.tableView.setEditable(false);
/* 137 */     for (int i = 0; i < this.columnWidths.size(); i++) {
/* 138 */       final int i1 = i;
/* 139 */       TableColumn<List<String>, String> column = new TableColumn(ExcelCsvAnalyzer.getColumnName(i));
/* 140 */       Float columnWidth = (Float)this.columnWidths.get(i);
/* 141 */       if (columnWidth != null)
/* 142 */         column.setPrefWidth(Math.round(columnWidth.floatValue()));
/* 143 */       column.setSortable(false);
/* 144 */       column.setCellValueFactory(new javafx.util.Callback()
/*     */       {
/*     */         public ObservableValue<String> call(TableColumn.CellDataFeatures<List<String>, String> param) {
/* 147 */           return new javafx.beans.property.SimpleStringProperty((String)((List)param.getValue()).get(i1));
/*     */         }
/* 149 */       });
/* 150 */       this.tableView.getColumns().add(column);
/*     */     }
/* 152 */     this.tableView.getSelectionModel().setCellSelectionEnabled(true);
/* 153 */     this.tableView.getSelectionModel().setSelectionMode(javafx.scene.control.SelectionMode.MULTIPLE);
/* 154 */     this.tableView.getSelectionModel().getSelectedCells().addListener(new ListChangeListener()
/*     */     {
/*     */       public void onChanged(ListChangeListener.Change c) {
/* 157 */         ExcelCsvPreviewDialogController.this.analyzeButton.setDisable(ExcelCsvPreviewDialogController.this.tableView.getSelectionModel().getSelectedCells().size() == 0);
/*     */       }
/*     */       
/* 160 */     });
/* 161 */     this.tableView.setOnMouseClicked(new javafx.event.EventHandler()
/*     */     {
/*     */       public void handle(MouseEvent event) {
/* 164 */         String text = null;
/* 165 */         if ((event.getTarget() instanceof Label)) {
/* 166 */           text = ((Label)event.getTarget()).getText();
/* 167 */         } else if (((event.getTarget() instanceof LabeledText)) && ((((LabeledText)event.getTarget()).getParent() instanceof Label))) {
/* 168 */           text = ((LabeledText)event.getTarget()).getText();
/*     */         }
/* 170 */         if (text != null) {
/* 171 */           int columnIndex = ExcelCsvAnalyzer.getColumnIndex(text);
/* 172 */           if ((event.isShiftDown()) && (event.isControlDown())) {
/* 173 */             ExcelCsvPreviewDialogController.this.tableView.getSelectionModel().clearSelection();
/* 174 */             TableColumn tc = (TableColumn)ExcelCsvPreviewDialogController.this.tableView.getColumns().get(columnIndex);
/* 175 */             ExcelCsvPreviewDialogController.this.tableView.getSelectionModel().selectRange(0, tc, ExcelCsvPreviewDialogController.this.data.size() - 1, tc);
/* 176 */           } else if (event.isShiftDown()) {
/* 177 */             ObservableList<TablePosition> selectedCells = ExcelCsvPreviewDialogController.this.tableView.getSelectionModel().getSelectedCells();
/* 178 */             Integer rightMostColumn = null;
/* 179 */             for (TablePosition tp : selectedCells) {
/* 180 */               if (rightMostColumn == null)
/* 181 */                 rightMostColumn = Integer.valueOf(0);
/* 182 */               rightMostColumn = Integer.valueOf(Math.max(rightMostColumn.intValue(), tp.getColumn()));
/*     */             }
/*     */             
/* 185 */             if (rightMostColumn == null) {
/* 186 */               TableColumn tc = (TableColumn)ExcelCsvPreviewDialogController.this.tableView.getColumns().get(columnIndex);
/* 187 */               ExcelCsvPreviewDialogController.this.tableView.getSelectionModel().selectRange(0, tc, ExcelCsvPreviewDialogController.this.data.size() - 1, tc);
/*     */             } else {
/* 189 */               ExcelCsvPreviewDialogController.this.tableView.getSelectionModel().selectRange(0, (TableColumn)ExcelCsvPreviewDialogController.this.tableView.getColumns().get(columnIndex), ExcelCsvPreviewDialogController.this.data.size() - 1, (TableColumn)ExcelCsvPreviewDialogController.this.tableView.getColumns().get(rightMostColumn.intValue()));
/*     */             }
/* 191 */           } else if (event.isControlDown()) {
/* 192 */             TableColumn tc = (TableColumn)ExcelCsvPreviewDialogController.this.tableView.getColumns().get(columnIndex);
/* 193 */             ExcelCsvPreviewDialogController.this.tableView.getSelectionModel().selectRange(0, tc, ExcelCsvPreviewDialogController.this.data.size() - 1, tc);
/*     */           } else {
/* 195 */             ExcelCsvPreviewDialogController.this.tableView.getSelectionModel().clearSelection();
/* 196 */             TableColumn tc = (TableColumn)ExcelCsvPreviewDialogController.this.tableView.getColumns().get(columnIndex);
/* 197 */             ExcelCsvPreviewDialogController.this.tableView.getSelectionModel().selectRange(0, tc, ExcelCsvPreviewDialogController.this.data.size() - 1, tc);
/*     */           }
/*     */         }
/*     */       }
/* 201 */     });
/* 202 */     this.tableView.setItems(this.data);
/* 203 */     Utils.disableColumnReordering(this.tableView);
/*     */   }
/*     */   
/*     */   private static class OpenExcelFileTask extends CancelableTask<ObservableList<List<String>>>
/*     */   {
/* 208 */     private static final Logger logger = LoggerFactory.getLogger(OpenExcelFileTask.class);
/*     */     
/*     */     protected File file;
/* 211 */     protected List<Float> columnWidths = new ArrayList();
/* 212 */     protected int maxRowSize = 0;
/*     */     protected App app;
/*     */     
/*     */     private OpenExcelFileTask(App app, File file) {
/* 216 */       this.file = file;
/* 217 */       this.app = app;
/*     */     }
/*     */     
/*     */     protected ObservableList<List<String>> call()
/*     */       throws Exception
/*     */     {
/* 223 */       final ObservableList<List<String>> data = FXCollections.observableArrayList();
/* 224 */       updateMessage("Opening Excel file...");
/* 225 */       boolean fileLoaded = false;
/* 226 */       if (this.file.length() > 5242880L) {
/* 227 */         FileInputStream fis = null;
/*     */         try {
/* 229 */           OPCPackage pkg = OPCPackage.open(this.file);
/* 230 */           XSSFReader reader = new XSSFReader(pkg);
/* 231 */           fis = new FileInputStream(this.file);
/* 232 */           XSSFReader.SheetIterator it = (XSSFReader.SheetIterator)reader.getSheetsData();
/* 233 */           InputSource sheetSource = new InputSource(it.next());
/* 234 */           XMLReader sheetParser = org.apache.poi.util.SAXHelper.newXMLReader();
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 282 */           org.xml.sax.ContentHandler handler = new org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler(reader.getStylesTable(), new org.apache.poi.xssf.eventusermodel.ReadOnlySharedStringsTable(pkg), new org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler.SheetContentsHandler()new DataFormatter
/*     */           {
/* 238 */             private List<String> stringRow = null;
/* 239 */             private int previousCellIndex = 0;
/*     */             
/*     */             public void startRow(int i)
/*     */             {
/* 243 */               this.previousCellIndex = 0;
/* 244 */               this.stringRow = new ArrayList();
/* 245 */               ExcelCsvPreviewDialogController.OpenExcelFileTask.this.updateMessage(String.format("Opening Excel file: Row %d", new Object[] { Integer.valueOf(i + 1) }));
/*     */             }
/*     */             
/*     */             public void endRow(int i)
/*     */             {
/* 250 */               if (this.stringRow.size() > ExcelCsvPreviewDialogController.OpenExcelFileTask.this.maxRowSize)
/* 251 */                 ExcelCsvPreviewDialogController.OpenExcelFileTask.this.maxRowSize = this.stringRow.size();
/* 252 */               data.add(this.stringRow);
/*     */             }
/*     */             
/*     */             public void cell(String s, String s2, XSSFComment xssfComment)
/*     */             {
/* 257 */               String columnName = getColumnName(s);
/* 258 */               int columnIndex = ExcelCsvAnalyzer.getColumnIndex(columnName);
/* 259 */               if (columnIndex - this.previousCellIndex > 1) {
/* 260 */                 for (int i = this.previousCellIndex; i < columnIndex - 1; i++) {
/* 261 */                   this.stringRow.add("");
/*     */                 }
/*     */               }
/* 264 */               this.stringRow.add(s2);
/* 265 */               this.previousCellIndex = columnIndex;
/*     */             }
/*     */             
/*     */ 
/*     */             public void headerFooter(String s, boolean b, String s2) {}
/*     */             
/*     */             private String getColumnName(String cellName)
/*     */             {
/* 273 */               String result = "";
/* 274 */               for (int i = 0; i < cellName.length(); i++) {
/* 275 */                 if (Character.isDigit(cellName.charAt(i)))
/*     */                   break;
/* 277 */                 result = result + cellName.charAt(i);
/*     */               }
/* 279 */               return result; } }, new DataFormatter(this.app
/*     */           
/*     */ 
/* 282 */             .getLiwcPreferences().getLocale()), false);
/* 283 */           sheetParser.setContentHandler(handler);
/* 284 */           sheetParser.parse(sheetSource);
/* 285 */           for (int i = 0; i < this.maxRowSize; i++)
/* 286 */             this.columnWidths.add(null);
/* 287 */           fileLoaded = true;
/*     */         } catch (Exception e) {
/* 289 */           logger.error(e.getLocalizedMessage(), e);
/*     */         } finally {
/* 291 */           if (fis != null) {
/* 292 */             fis.close();
/*     */           }
/*     */         }
/*     */       }
/* 296 */       if (!fileLoaded) {
/* 297 */         Workbook workbook = WorkbookFactory.create(this.file);
/* 298 */         Sheet sheet = workbook.getSheetAt(0);
/* 299 */         updateProgress(0L, sheet.getLastRowNum());
/* 300 */         DataFormatter dataFormatter = new DataFormatter();
/* 301 */         for (int rowIndex = 0; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
/* 302 */           Row row = sheet.getRow(rowIndex);
/* 303 */           if (row != null) {
/* 304 */             List<String> stringRow = new ArrayList();
/* 305 */             int rowSize = row.getLastCellNum();
/* 306 */             if (rowSize > this.maxRowSize)
/* 307 */               this.maxRowSize = rowSize;
/* 308 */             for (int cellIndex = 0; cellIndex < rowSize; cellIndex++) {
/* 309 */               if ((cellIndex >= this.columnWidths.size()) && (cellIndex < rowSize))
/* 310 */                 this.columnWidths.add(Float.valueOf(sheet.getColumnWidthInPixels(cellIndex)));
/* 311 */               org.apache.poi.ss.usermodel.Cell cell = row.getCell(cellIndex);
/* 312 */               if (cell != null) {
/* 313 */                 stringRow.add(dataFormatter.formatCellValue(cell));
/*     */               } else {
/* 315 */                 stringRow.add("");
/*     */               }
/*     */             }
/* 318 */             data.add(stringRow);
/*     */           }
/* 320 */           updateProgress(rowIndex + 1, sheet.getLastRowNum() + 1);
/*     */         }
/* 322 */         workbook.close();
/* 323 */         System.gc();
/* 324 */         System.runFinalization();
/*     */       }
/* 326 */       for (int i = 0; i < data.size(); i++) {
/* 327 */         List<String> stringRow = (List)data.get(i);
/* 328 */         for (int j = stringRow.size(); j < this.maxRowSize; j++) {
/* 329 */           stringRow.add("");
/*     */         }
/*     */       }
/* 332 */       return data;
/*     */     }
/*     */     
/*     */     public List<Float> getColumnWidths() {
/* 336 */       return this.columnWidths;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class OpenCsvFileTask
/*     */     extends ExcelCsvPreviewDialogController.OpenExcelFileTask
/*     */   {
/* 343 */     private static final Logger logger = LoggerFactory.getLogger(ExcelCsvPreviewDialogController.OpenExcelFileTask.class);
/*     */     
/*     */     private OpenCsvFileTask(App app, File file) {
/* 346 */       super(file, null);
/*     */     }
/*     */     
/*     */     protected ObservableList<List<String>> call() throws Exception
/*     */     {
/* 351 */       ObservableList<List<String>> data = FXCollections.observableArrayList();
/* 352 */       updateMessage("Opening CSV file...");
/* 353 */       FileInputStream fis = null;
/* 354 */       CSVParser csvParser = null;
/* 355 */       BOMInputStream bomInputStream = null;
/*     */       try {
/* 357 */         fis = new FileInputStream(this.file);
/* 358 */         LiwcPreferences prefs = this.app.getLiwcPreferences();
/* 359 */         bomInputStream = new BOMInputStream(new FileInputStream(this.file), new ByteOrderMark[] { ByteOrderMark.UTF_8, ByteOrderMark.UTF_16BE, ByteOrderMark.UTF_16LE, ByteOrderMark.UTF_32BE, ByteOrderMark.UTF_32LE });
/* 360 */         ByteOrderMark bom = bomInputStream.getBOM();
/* 361 */         String charsetName = bom == null ? prefs.getPlainTextEncoding() : bom.getCharsetName();
/* 362 */         Reader reader = new java.io.InputStreamReader(bomInputStream, charsetName);
/*     */         
/*     */ 
/* 365 */         csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withDelimiter(Utils.getCsvDelimiter(prefs)).withEscape(prefs.getCsvEscapeCharacter() == 0 ? null : Character.valueOf(prefs.getCsvEscapeCharacter())).withQuote(prefs.getCsvQuoteCharacter() == 0 ? null : Character.valueOf(prefs.getCsvQuoteCharacter())));
/* 366 */         int recordIndex = 0;
/* 367 */         List<CSVRecord> records = csvParser.getRecords();
/* 368 */         int totalRecords = records.size();
/* 369 */         List<String> stringRow = null;
/* 370 */         for (CSVRecord record : records) {
/* 371 */           for (int i = 0; i < record.size(); i++) {
/* 372 */             if (stringRow == null)
/* 373 */               stringRow = new ArrayList();
/* 374 */             stringRow.add(record.get(i));
/* 375 */             if (i == record.size() - 1) {
/* 376 */               if (stringRow.size() > this.maxRowSize)
/* 377 */                 this.maxRowSize = stringRow.size();
/* 378 */               data.add(stringRow);
/* 379 */               stringRow = null;
/*     */             }
/*     */           }
/* 382 */           updateProgress(totalRecords, ++recordIndex);
/*     */         }
/* 384 */         csvParser.close();
/* 385 */         reader.close();
/*     */       } catch (Exception e) {
/* 387 */         logger.error(e.getLocalizedMessage(), e);
/*     */       } finally {
/* 389 */         if (csvParser != null)
/* 390 */           csvParser.close();
/* 391 */         if (bomInputStream != null)
/* 392 */           bomInputStream.close();
/* 393 */         if (fis != null)
/* 394 */           fis.close();
/*     */       }
/* 396 */       for (int i = 0; i < data.size(); i++) {
/* 397 */         List<String> stringRow = (List)data.get(i);
/* 398 */         for (int j = stringRow.size(); j < this.maxRowSize; j++) {
/* 399 */           stringRow.add("");
/*     */         }
/*     */       }
/* 402 */       for (int i = 0; i < this.maxRowSize; i++)
/* 403 */         this.columnWidths.add(null);
/* 404 */       return data;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/ExcelCsvPreviewDialogController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */