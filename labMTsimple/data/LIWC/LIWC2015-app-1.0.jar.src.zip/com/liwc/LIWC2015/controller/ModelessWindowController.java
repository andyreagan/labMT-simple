/*    */ package com.liwc.LIWC2015.controller;
/*    */ 
/*    */ import javafx.fxml.FXMLLoader;
/*    */ import javafx.stage.Stage;
/*    */ 
/*    */ public abstract class ModelessWindowController extends WindowController
/*    */ {
/*    */   public static <T> T run(com.liwc.LIWC2015.App app, String resourcePath, Object... args)
/*    */   {
/*    */     try
/*    */     {
/* 12 */       FXMLLoader loader = new FXMLLoader(ModelessWindowController.class.getResource(resourcePath));
/* 13 */       loader.load();
/* 14 */       ModelessWindowController controller = (ModelessWindowController)loader.getController();
/* 15 */       controller.app = app;
/* 16 */       Stage stage = controller.initStage(app, new Object[0]);
/* 17 */       controller.stage = stage;
/* 18 */       stage.show();
/* 19 */       return controller;
/*    */     } catch (Exception e) {
/* 21 */       logger.error(e.getLocalizedMessage(), e);
/* 22 */       com.liwc.LIWC2015.Utils.showException(app, e); }
/* 23 */     return null;
/*    */   }
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/ModelessWindowController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */