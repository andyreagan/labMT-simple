package com.microsoft.schemas.office.x2006.encryption;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.SchemaTypeSystem;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public abstract interface EncryptionDocument
  extends XmlObject
{
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(EncryptionDocument.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0B482D0B338CC9641C1543C3510577FE").resolveHandle("encryptione8b3doctype");
  
  public abstract CTEncryption getEncryption();
  
  public abstract void setEncryption(CTEncryption paramCTEncryption);
  
  public abstract CTEncryption addNewEncryption();
  
  public static final class Factory
  {
    public static EncryptionDocument newInstance()
    {
      return (EncryptionDocument)XmlBeans.getContextTypeLoader().newInstance(EncryptionDocument.type, null);
    }
    
    public static EncryptionDocument newInstance(XmlOptions paramXmlOptions)
    {
      return (EncryptionDocument)XmlBeans.getContextTypeLoader().newInstance(EncryptionDocument.type, paramXmlOptions);
    }
    
    public static EncryptionDocument parse(String paramString)
      throws XmlException
    {
      return (EncryptionDocument)XmlBeans.getContextTypeLoader().parse(paramString, EncryptionDocument.type, null);
    }
    
    public static EncryptionDocument parse(String paramString, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (EncryptionDocument)XmlBeans.getContextTypeLoader().parse(paramString, EncryptionDocument.type, paramXmlOptions);
    }
    
    public static EncryptionDocument parse(File paramFile)
      throws XmlException, IOException
    {
      return (EncryptionDocument)XmlBeans.getContextTypeLoader().parse(paramFile, EncryptionDocument.type, null);
    }
    
    public static EncryptionDocument parse(File paramFile, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (EncryptionDocument)XmlBeans.getContextTypeLoader().parse(paramFile, EncryptionDocument.type, paramXmlOptions);
    }
    
    public static EncryptionDocument parse(URL paramURL)
      throws XmlException, IOException
    {
      return (EncryptionDocument)XmlBeans.getContextTypeLoader().parse(paramURL, EncryptionDocument.type, null);
    }
    
    public static EncryptionDocument parse(URL paramURL, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (EncryptionDocument)XmlBeans.getContextTypeLoader().parse(paramURL, EncryptionDocument.type, paramXmlOptions);
    }
    
    public static EncryptionDocument parse(InputStream paramInputStream)
      throws XmlException, IOException
    {
      return (EncryptionDocument)XmlBeans.getContextTypeLoader().parse(paramInputStream, EncryptionDocument.type, null);
    }
    
    public static EncryptionDocument parse(InputStream paramInputStream, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (EncryptionDocument)XmlBeans.getContextTypeLoader().parse(paramInputStream, EncryptionDocument.type, paramXmlOptions);
    }
    
    public static EncryptionDocument parse(Reader paramReader)
      throws XmlException, IOException
    {
      return (EncryptionDocument)XmlBeans.getContextTypeLoader().parse(paramReader, EncryptionDocument.type, null);
    }
    
    public static EncryptionDocument parse(Reader paramReader, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (EncryptionDocument)XmlBeans.getContextTypeLoader().parse(paramReader, EncryptionDocument.type, paramXmlOptions);
    }
    
    public static EncryptionDocument parse(XMLStreamReader paramXMLStreamReader)
      throws XmlException
    {
      return (EncryptionDocument)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, EncryptionDocument.type, null);
    }
    
    public static EncryptionDocument parse(XMLStreamReader paramXMLStreamReader, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (EncryptionDocument)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, EncryptionDocument.type, paramXmlOptions);
    }
    
    public static EncryptionDocument parse(Node paramNode)
      throws XmlException
    {
      return (EncryptionDocument)XmlBeans.getContextTypeLoader().parse(paramNode, EncryptionDocument.type, null);
    }
    
    public static EncryptionDocument parse(Node paramNode, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (EncryptionDocument)XmlBeans.getContextTypeLoader().parse(paramNode, EncryptionDocument.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static EncryptionDocument parse(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return (EncryptionDocument)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, EncryptionDocument.type, null);
    }
    
    /**
     * @deprecated
     */
    public static EncryptionDocument parse(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return (EncryptionDocument)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, EncryptionDocument.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, EncryptionDocument.type, null);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, EncryptionDocument.type, paramXmlOptions);
    }
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/encryption/EncryptionDocument.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */