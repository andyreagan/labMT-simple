/*    */ package com.liwc.LIWC2015.controller;
/*    */ 
/*    */ import java.util.concurrent.atomic.AtomicBoolean;
/*    */ import javafx.concurrent.Task;
/*    */ 
/*    */ 
/*    */ public abstract class CancelableTask<T>
/*    */   extends Task<T>
/*    */ {
/* 10 */   protected AtomicBoolean cancelRequested = new AtomicBoolean(false);
/*    */   
/*    */   public void requestCancel() {
/* 13 */     this.cancelRequested.set(true);
/* 14 */     updateMessage("Stopping. Please wait...");
/*    */   }
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/CancelableTask.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */