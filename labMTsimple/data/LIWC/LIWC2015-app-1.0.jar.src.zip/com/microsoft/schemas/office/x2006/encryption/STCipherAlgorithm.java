package com.microsoft.schemas.office.x2006.encryption;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.SchemaTypeSystem;
import org.apache.xmlbeans.StringEnumAbstractBase;
import org.apache.xmlbeans.StringEnumAbstractBase.Table;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.XmlToken;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public abstract interface STCipherAlgorithm
  extends XmlToken
{
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(STCipherAlgorithm.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0B482D0B338CC9641C1543C3510577FE").resolveHandle("stcipheralgorithme346type");
  public static final Enum AES = Enum.forString("AES");
  public static final Enum RC_2 = Enum.forString("RC2");
  public static final Enum RC_4 = Enum.forString("RC4");
  public static final Enum DES = Enum.forString("DES");
  public static final Enum DESX = Enum.forString("DESX");
  public static final Enum X_3_DES = Enum.forString("3DES");
  public static final Enum X_3_DES_112 = Enum.forString("3DES_112");
  public static final int INT_AES = 1;
  public static final int INT_RC_2 = 2;
  public static final int INT_RC_4 = 3;
  public static final int INT_DES = 4;
  public static final int INT_DESX = 5;
  public static final int INT_X_3_DES = 6;
  public static final int INT_X_3_DES_112 = 7;
  
  public abstract StringEnumAbstractBase enumValue();
  
  public abstract void set(StringEnumAbstractBase paramStringEnumAbstractBase);
  
  public static final class Factory
  {
    public static STCipherAlgorithm newValue(Object paramObject)
    {
      return (STCipherAlgorithm)STCipherAlgorithm.type.newValue(paramObject);
    }
    
    public static STCipherAlgorithm newInstance()
    {
      return (STCipherAlgorithm)XmlBeans.getContextTypeLoader().newInstance(STCipherAlgorithm.type, null);
    }
    
    public static STCipherAlgorithm newInstance(XmlOptions paramXmlOptions)
    {
      return (STCipherAlgorithm)XmlBeans.getContextTypeLoader().newInstance(STCipherAlgorithm.type, paramXmlOptions);
    }
    
    public static STCipherAlgorithm parse(String paramString)
      throws XmlException
    {
      return (STCipherAlgorithm)XmlBeans.getContextTypeLoader().parse(paramString, STCipherAlgorithm.type, null);
    }
    
    public static STCipherAlgorithm parse(String paramString, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (STCipherAlgorithm)XmlBeans.getContextTypeLoader().parse(paramString, STCipherAlgorithm.type, paramXmlOptions);
    }
    
    public static STCipherAlgorithm parse(File paramFile)
      throws XmlException, IOException
    {
      return (STCipherAlgorithm)XmlBeans.getContextTypeLoader().parse(paramFile, STCipherAlgorithm.type, null);
    }
    
    public static STCipherAlgorithm parse(File paramFile, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (STCipherAlgorithm)XmlBeans.getContextTypeLoader().parse(paramFile, STCipherAlgorithm.type, paramXmlOptions);
    }
    
    public static STCipherAlgorithm parse(URL paramURL)
      throws XmlException, IOException
    {
      return (STCipherAlgorithm)XmlBeans.getContextTypeLoader().parse(paramURL, STCipherAlgorithm.type, null);
    }
    
    public static STCipherAlgorithm parse(URL paramURL, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (STCipherAlgorithm)XmlBeans.getContextTypeLoader().parse(paramURL, STCipherAlgorithm.type, paramXmlOptions);
    }
    
    public static STCipherAlgorithm parse(InputStream paramInputStream)
      throws XmlException, IOException
    {
      return (STCipherAlgorithm)XmlBeans.getContextTypeLoader().parse(paramInputStream, STCipherAlgorithm.type, null);
    }
    
    public static STCipherAlgorithm parse(InputStream paramInputStream, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (STCipherAlgorithm)XmlBeans.getContextTypeLoader().parse(paramInputStream, STCipherAlgorithm.type, paramXmlOptions);
    }
    
    public static STCipherAlgorithm parse(Reader paramReader)
      throws XmlException, IOException
    {
      return (STCipherAlgorithm)XmlBeans.getContextTypeLoader().parse(paramReader, STCipherAlgorithm.type, null);
    }
    
    public static STCipherAlgorithm parse(Reader paramReader, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (STCipherAlgorithm)XmlBeans.getContextTypeLoader().parse(paramReader, STCipherAlgorithm.type, paramXmlOptions);
    }
    
    public static STCipherAlgorithm parse(XMLStreamReader paramXMLStreamReader)
      throws XmlException
    {
      return (STCipherAlgorithm)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, STCipherAlgorithm.type, null);
    }
    
    public static STCipherAlgorithm parse(XMLStreamReader paramXMLStreamReader, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (STCipherAlgorithm)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, STCipherAlgorithm.type, paramXmlOptions);
    }
    
    public static STCipherAlgorithm parse(Node paramNode)
      throws XmlException
    {
      return (STCipherAlgorithm)XmlBeans.getContextTypeLoader().parse(paramNode, STCipherAlgorithm.type, null);
    }
    
    public static STCipherAlgorithm parse(Node paramNode, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (STCipherAlgorithm)XmlBeans.getContextTypeLoader().parse(paramNode, STCipherAlgorithm.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static STCipherAlgorithm parse(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return (STCipherAlgorithm)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, STCipherAlgorithm.type, null);
    }
    
    /**
     * @deprecated
     */
    public static STCipherAlgorithm parse(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return (STCipherAlgorithm)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, STCipherAlgorithm.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, STCipherAlgorithm.type, null);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, STCipherAlgorithm.type, paramXmlOptions);
    }
  }
  
  public static final class Enum
    extends StringEnumAbstractBase
  {
    static final int INT_AES = 1;
    static final int INT_RC_2 = 2;
    static final int INT_RC_4 = 3;
    static final int INT_DES = 4;
    static final int INT_DESX = 5;
    static final int INT_X_3_DES = 6;
    static final int INT_X_3_DES_112 = 7;
    public static final StringEnumAbstractBase.Table table = new StringEnumAbstractBase.Table(new Enum[] { new Enum("AES", 1), new Enum("RC2", 2), new Enum("RC4", 3), new Enum("DES", 4), new Enum("DESX", 5), new Enum("3DES", 6), new Enum("3DES_112", 7) });
    private static final long serialVersionUID = 1L;
    
    public static Enum forString(String paramString)
    {
      return (Enum)table.forString(paramString);
    }
    
    public static Enum forInt(int paramInt)
    {
      return (Enum)table.forInt(paramInt);
    }
    
    private Enum(String paramString, int paramInt)
    {
      super(paramInt);
    }
    
    private Object readResolve()
    {
      return forInt(intValue());
    }
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/encryption/STCipherAlgorithm.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */