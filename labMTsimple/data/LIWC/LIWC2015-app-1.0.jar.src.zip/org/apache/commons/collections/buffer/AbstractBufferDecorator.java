/*    */ package org.apache.commons.collections.buffer;
/*    */ 
/*    */ import org.apache.commons.collections.Buffer;
/*    */ import org.apache.commons.collections.collection.AbstractCollectionDecorator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractBufferDecorator
/*    */   extends AbstractCollectionDecorator
/*    */   implements Buffer
/*    */ {
/*    */   protected AbstractBufferDecorator() {}
/*    */   
/*    */   protected AbstractBufferDecorator(Buffer buffer)
/*    */   {
/* 49 */     super(buffer);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected Buffer getBuffer()
/*    */   {
/* 58 */     return (Buffer)getCollection();
/*    */   }
/*    */   
/*    */   public Object get()
/*    */   {
/* 63 */     return getBuffer().get();
/*    */   }
/*    */   
/*    */   public Object remove() {
/* 67 */     return getBuffer().remove();
/*    */   }
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/org/apache/commons/collections/buffer/AbstractBufferDecorator.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */