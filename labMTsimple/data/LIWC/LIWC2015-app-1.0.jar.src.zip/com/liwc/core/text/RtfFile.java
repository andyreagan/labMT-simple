package com.liwc.core.text;

import java.io.InputStream;
import javax.swing.text.Document;
import javax.swing.text.rtf.RTFEditorKit;

public class RtfFile
  extends RawText
{
  public RtfFile(InputStream paramInputStream)
  {
    super(paramInputStream = localDocument.getText(0, localDocument.getLength()));
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/core/text/RtfFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */