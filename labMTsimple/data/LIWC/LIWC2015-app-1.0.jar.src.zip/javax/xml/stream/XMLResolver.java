package javax.xml.stream;

public abstract interface XMLResolver
{
  public abstract Object resolveEntity(String paramString1, String paramString2, String paramString3, String paramString4)
    throws XMLStreamException;
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/javax/xml/stream/XMLResolver.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */