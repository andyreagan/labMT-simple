package com.liwc.core.text;

import java.io.File;
import java.io.FileInputStream;
import java.nio.charset.Charset;
import org.apache.commons.io.Charsets;

public class TextFactory
{
  public static IText getText(File paramFile)
  {
    return getText(paramFile, Charsets.UTF_8);
  }
  
  public static IText getText(File paramFile, Charset paramCharset)
  {
    Object localObject = null;
    String str = paramFile.getName().toLowerCase();
    paramFile = new FileInputStream(paramFile);
    if (str.endsWith(".txt")) {
      localObject = new TxtFile(paramFile, paramCharset);
    } else if ((str.endsWith(".doc")) || (str.endsWith(".docx"))) {
      localObject = new MSWordFile(paramFile);
    } else if (str.endsWith(".rtf")) {
      localObject = new RtfFile(paramFile);
    } else if (str.endsWith(".pdf")) {
      localObject = new PdfFile(paramFile);
    }
    paramFile.close();
    return (IText)localObject;
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/core/text/TextFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */