/*    */ package org.apache.commons.collections.iterators;
/*    */ 
/*    */ import org.apache.commons.collections.OrderedIterator;
/*    */ import org.apache.commons.collections.ResettableIterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmptyOrderedIterator
/*    */   extends AbstractEmptyIterator
/*    */   implements OrderedIterator, ResettableIterator
/*    */ {
/* 36 */   public static final OrderedIterator INSTANCE = new EmptyOrderedIterator();
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/org/apache/commons/collections/iterators/EmptyOrderedIterator.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */