/*     */ package org.apache.commons.collections.buffer;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.util.AbstractCollection;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ import org.apache.commons.collections.BoundedCollection;
/*     */ import org.apache.commons.collections.Buffer;
/*     */ import org.apache.commons.collections.BufferOverflowException;
/*     */ import org.apache.commons.collections.BufferUnderflowException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BoundedFifoBuffer
/*     */   extends AbstractCollection
/*     */   implements Buffer, BoundedCollection, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 5603722811189451017L;
/*     */   private transient Object[] elements;
/*  75 */   private transient int start = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  84 */   private transient int end = 0;
/*     */   
/*     */ 
/*  87 */   private transient boolean full = false;
/*     */   
/*     */ 
/*     */ 
/*     */   private final int maxElements;
/*     */   
/*     */ 
/*     */ 
/*     */   public BoundedFifoBuffer()
/*     */   {
/*  97 */     this(32);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BoundedFifoBuffer(int size)
/*     */   {
/* 108 */     if (size <= 0) {
/* 109 */       throw new IllegalArgumentException("The size must be greater than 0");
/*     */     }
/* 111 */     this.elements = new Object[size];
/* 112 */     this.maxElements = this.elements.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BoundedFifoBuffer(Collection coll)
/*     */   {
/* 124 */     this(coll.size());
/* 125 */     addAll(coll);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeObject(ObjectOutputStream out)
/*     */     throws IOException
/*     */   {
/* 136 */     out.defaultWriteObject();
/* 137 */     out.writeInt(size());
/* 138 */     for (Iterator it = iterator(); it.hasNext();) {
/* 139 */       out.writeObject(it.next());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void readObject(ObjectInputStream in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 151 */     in.defaultReadObject();
/* 152 */     this.elements = new Object[this.maxElements];
/* 153 */     int size = in.readInt();
/* 154 */     for (int i = 0; i < size; i++) {
/* 155 */       this.elements[i] = in.readObject();
/*     */     }
/* 157 */     this.start = 0;
/* 158 */     this.full = (size == this.maxElements);
/* 159 */     if (this.full) {
/* 160 */       this.end = 0;
/*     */     } else {
/* 162 */       this.end = size;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int size()
/*     */   {
/* 173 */     int size = 0;
/*     */     
/* 175 */     if (this.end < this.start) {
/* 176 */       size = this.maxElements - this.start + this.end;
/* 177 */     } else if (this.end == this.start) {
/* 178 */       size = this.full ? this.maxElements : 0;
/*     */     } else {
/* 180 */       size = this.end - this.start;
/*     */     }
/*     */     
/* 183 */     return size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 192 */     return size() == 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFull()
/*     */   {
/* 201 */     return size() == this.maxElements;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int maxSize()
/*     */   {
/* 210 */     return this.maxElements;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/* 217 */     this.full = false;
/* 218 */     this.start = 0;
/* 219 */     this.end = 0;
/* 220 */     Arrays.fill(this.elements, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean add(Object element)
/*     */   {
/* 232 */     if (null == element) {
/* 233 */       throw new NullPointerException("Attempted to add null object to buffer");
/*     */     }
/*     */     
/* 236 */     if (this.full) {
/* 237 */       throw new BufferOverflowException("The buffer cannot hold more than " + this.maxElements + " objects.");
/*     */     }
/*     */     
/* 240 */     this.elements[(this.end++)] = element;
/*     */     
/* 242 */     if (this.end >= this.maxElements) {
/* 243 */       this.end = 0;
/*     */     }
/*     */     
/* 246 */     if (this.end == this.start) {
/* 247 */       this.full = true;
/*     */     }
/*     */     
/* 250 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object get()
/*     */   {
/* 260 */     if (isEmpty()) {
/* 261 */       throw new BufferUnderflowException("The buffer is already empty");
/*     */     }
/*     */     
/* 264 */     return this.elements[this.start];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object remove()
/*     */   {
/* 274 */     if (isEmpty()) {
/* 275 */       throw new BufferUnderflowException("The buffer is already empty");
/*     */     }
/*     */     
/* 278 */     Object element = this.elements[this.start];
/*     */     
/* 280 */     if (null != element) {
/* 281 */       this.elements[(this.start++)] = null;
/*     */       
/* 283 */       if (this.start >= this.maxElements) {
/* 284 */         this.start = 0;
/*     */       }
/*     */       
/* 287 */       this.full = false;
/*     */     }
/*     */     
/* 290 */     return element;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int increment(int index)
/*     */   {
/*     */     
/*     */     
/*     */ 
/* 301 */     if (index >= this.maxElements) {
/* 302 */       index = 0;
/*     */     }
/* 304 */     return index;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int decrement(int index)
/*     */   {
/*     */     
/*     */     
/*     */ 
/* 315 */     if (index < 0) {
/* 316 */       index = this.maxElements - 1;
/*     */     }
/* 318 */     return index;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Iterator iterator()
/*     */   {
/* 327 */     new Iterator()
/*     */     {
/* 329 */       private int index = BoundedFifoBuffer.this.start;
/* 330 */       private int lastReturnedIndex = -1;
/* 331 */       private boolean isFirst = BoundedFifoBuffer.this.full;
/*     */       
/*     */       public boolean hasNext() {
/* 334 */         return (this.isFirst) || (this.index != BoundedFifoBuffer.this.end);
/*     */       }
/*     */       
/*     */       public Object next()
/*     */       {
/* 339 */         if (!hasNext()) {
/* 340 */           throw new NoSuchElementException();
/*     */         }
/* 342 */         this.isFirst = false;
/* 343 */         this.lastReturnedIndex = this.index;
/* 344 */         this.index = BoundedFifoBuffer.this.increment(this.index);
/* 345 */         return BoundedFifoBuffer.this.elements[this.lastReturnedIndex];
/*     */       }
/*     */       
/*     */       public void remove() {
/* 349 */         if (this.lastReturnedIndex == -1) {
/* 350 */           throw new IllegalStateException();
/*     */         }
/*     */         
/*     */ 
/* 354 */         if (this.lastReturnedIndex == BoundedFifoBuffer.this.start) {
/* 355 */           BoundedFifoBuffer.this.remove();
/* 356 */           this.lastReturnedIndex = -1;
/* 357 */           return;
/*     */         }
/*     */         
/* 360 */         int pos = this.lastReturnedIndex + 1;
/* 361 */         if ((BoundedFifoBuffer.this.start < this.lastReturnedIndex) && (pos < BoundedFifoBuffer.this.end))
/*     */         {
/* 363 */           System.arraycopy(BoundedFifoBuffer.this.elements, pos, BoundedFifoBuffer.this.elements, this.lastReturnedIndex, BoundedFifoBuffer.this.end - pos);
/*     */         }
/*     */         else
/*     */         {
/* 367 */           while (pos != BoundedFifoBuffer.this.end) {
/* 368 */             if (pos >= BoundedFifoBuffer.this.maxElements) {
/* 369 */               BoundedFifoBuffer.this.elements[(pos - 1)] = BoundedFifoBuffer.this.elements[0];
/* 370 */               pos = 0;
/*     */             } else {
/* 372 */               BoundedFifoBuffer.this.elements[BoundedFifoBuffer.this.decrement(pos)] = BoundedFifoBuffer.this.elements[pos];
/* 373 */               pos = BoundedFifoBuffer.this.increment(pos);
/*     */             }
/*     */           }
/*     */         }
/*     */         
/* 378 */         this.lastReturnedIndex = -1;
/* 379 */         BoundedFifoBuffer.this.end = BoundedFifoBuffer.this.decrement(BoundedFifoBuffer.this.end);
/* 380 */         BoundedFifoBuffer.this.elements[BoundedFifoBuffer.this.end] = null;
/* 381 */         BoundedFifoBuffer.this.full = false;
/* 382 */         this.index = BoundedFifoBuffer.this.decrement(this.index);
/*     */       }
/*     */     };
/*     */   }
/*     */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/org/apache/commons/collections/buffer/BoundedFifoBuffer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */