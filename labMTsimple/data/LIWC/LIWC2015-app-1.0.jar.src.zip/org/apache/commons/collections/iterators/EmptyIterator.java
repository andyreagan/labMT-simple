/*    */ package org.apache.commons.collections.iterators;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import org.apache.commons.collections.ResettableIterator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EmptyIterator
/*    */   extends AbstractEmptyIterator
/*    */   implements ResettableIterator
/*    */ {
/* 41 */   public static final ResettableIterator RESETTABLE_INSTANCE = new EmptyIterator();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 46 */   public static final Iterator INSTANCE = RESETTABLE_INSTANCE;
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/org/apache/commons/collections/iterators/EmptyIterator.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */