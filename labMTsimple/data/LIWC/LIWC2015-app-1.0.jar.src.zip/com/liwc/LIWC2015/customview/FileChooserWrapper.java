/*    */ package com.liwc.LIWC2015.customview;
/*    */ 
/*    */ import com.liwc.LIWC2015.Utils;
/*    */ import java.io.File;
/*    */ import java.util.List;
/*    */ import javafx.stage.FileChooser;
/*    */ import javafx.stage.Modality;
/*    */ import javafx.stage.Stage;
/*    */ import javafx.stage.StageStyle;
/*    */ 
/*    */ public class FileChooserWrapper
/*    */   extends Stage
/*    */ {
/*    */   private FileChooser fileChooser;
/*    */   
/*    */   public FileChooserWrapper()
/*    */   {
/* 18 */     this.fileChooser = new FileChooser();
/*    */   }
/*    */   
/*    */   public FileChooser getFileChooser() {
/* 22 */     return this.fileChooser;
/*    */   }
/*    */   
/*    */   public List<File> showOpenMultipleDialog() {
/* 26 */     initStyle(Utils.isMac() ? StageStyle.TRANSPARENT : StageStyle.UTILITY);
/* 27 */     initModality(Modality.APPLICATION_MODAL);
/* 28 */     setWidth(1.0D);
/* 29 */     setHeight(1.0D);
/* 30 */     setX(-100.0D);
/* 31 */     setY(-100.0D);
/* 32 */     show();
/* 33 */     List<File> files = this.fileChooser.showOpenMultipleDialog(this);
/* 34 */     close();
/* 35 */     return files;
/*    */   }
/*    */   
/*    */   public File showOpenDialog() {
/* 39 */     initStyle(Utils.isMac() ? StageStyle.TRANSPARENT : StageStyle.UTILITY);
/* 40 */     initModality(Modality.APPLICATION_MODAL);
/* 41 */     setWidth(1.0D);
/* 42 */     setHeight(1.0D);
/* 43 */     setX(-100.0D);
/* 44 */     setY(-100.0D);
/* 45 */     show();
/* 46 */     File file = this.fileChooser.showOpenDialog(this);
/* 47 */     close();
/* 48 */     return file;
/*    */   }
/*    */   
/*    */   public File showSaveDialog() {
/* 52 */     initStyle(Utils.isMac() ? StageStyle.TRANSPARENT : StageStyle.UTILITY);
/* 53 */     initModality(Modality.APPLICATION_MODAL);
/* 54 */     setWidth(1.0D);
/* 55 */     setHeight(1.0D);
/* 56 */     setX(-100.0D);
/* 57 */     setY(-100.0D);
/* 58 */     show();
/* 59 */     File file = this.fileChooser.showSaveDialog(this);
/* 60 */     close();
/* 61 */     return file;
/*    */   }
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/customview/FileChooserWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */