package com.liwc.core.text;

import com.liwc.core.LanguageSettings;
import com.liwc.core.dictionary.IDictionary;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TextParser
{
  public static final String PunctuationMarks = ".…,:;?¿!¡-‘\\\"“”«»'’()#$%&\\\\/*+<=>@[]^_`´{}|~•†‡°¦";
  public static final Pattern ExtraPunctuationMarksPattern = Pattern.compile("[\\.'’-]");
  private char a;
  private Pattern b;
  private Pattern c;
  private Pattern d = Pattern.compile("\\d+\\p{L}+", 2);
  
  public TextParser()
  {
    this(null);
  }
  
  public TextParser(IDictionary paramIDictionary)
  {
    this(paramIDictionary, new LanguageSettings());
  }
  
  public TextParser(IDictionary paramIDictionary, LanguageSettings paramLanguageSettings)
  {
    this.a = ((DecimalFormat)DecimalFormat.getInstance(paramLanguageSettings.getLocale())).getDecimalFormatSymbols().getDecimalSeparator();
    paramLanguageSettings = paramLanguageSettings.getWordPattern();
    if (paramIDictionary != null) {
      for (int i = paramIDictionary.getSpecialWords().size() - 1; i >= 0; i--)
      {
        String str = (String)paramIDictionary.getSpecialWords().get(i);
        paramLanguageSettings = "(" + str + ")|" + paramLanguageSettings;
      }
    }
    this.b = Pattern.compile(paramLanguageSettings, 2);
    this.c = Pattern.compile("\\d*(\\" + this.a + "\\d+)?", 2);
  }
  
  public static List extractPunctuationMarks(String paramString)
  {
    paramString = ExtraPunctuationMarksPattern.matcher(paramString);
    ArrayList localArrayList = null;
    while (paramString.find())
    {
      if (localArrayList == null) {
        localArrayList = new ArrayList();
      }
      localArrayList.add(paramString.group(0));
    }
    return localArrayList;
  }
  
  public List parseText(String paramString)
  {
    String str = paramString;
    paramString = this;
    StringTokenizer localStringTokenizer = new StringTokenizer(str, "\t\r\n", true);
    ArrayList localArrayList = new ArrayList();
    while (localStringTokenizer.hasMoreTokens())
    {
      str = localStringTokenizer.nextToken();
      if ("\r\n\t".contains(str))
      {
        localArrayList.add(new TextToken(4, str));
      }
      else
      {
        a locala1 = new a(paramString);
        while (locala1.a() != str.length())
        {
          a locala2 = locala1;
          Object localObject2 = str;
          Object localObject1 = paramString;
          Matcher localMatcher;
          locala2.a(localMatcher.end());
          localObject1 = Character.isDigit(((String)localObject2).charAt(locala2.a())) ? null : ((localMatcher = ((TextParser)localObject1).d.matcher((CharSequence)localObject2)).find(locala2.a())) && (localMatcher.start() != localMatcher.end()) && (locala2.a() == localMatcher.start()) ? new TextToken(1, (String)localObject2, localMatcher.start(), localMatcher.end()) : null;
          List localList = null;
          if (localObject1 == null)
          {
            locala2 = locala1;
            localObject2 = str;
            localObject1 = paramString;
            char c1;
            locala2.a(((Matcher)localObject1).end());
            localObject1 = ((c1 = ((String)localObject2).charAt(locala2.a())) == ((TextParser)localObject1).a) || (Character.isDigit(c1)) ? null : ((localObject1 = ((TextParser)localObject1).c.matcher((CharSequence)localObject2)).find(locala2.a())) && (((Matcher)localObject1).start() != ((Matcher)localObject1).end()) && (locala2.a() == ((Matcher)localObject1).start()) ? new TextToken(2, (String)localObject2, ((Matcher)localObject1).start(), ((Matcher)localObject1).end()) : null;
          }
          if (localObject1 == null)
          {
            localObject2 = locala1;
            ((a)localObject2).b();
            localObject1 = (localObject1 = str).charAt(((a)localObject2).a()) == ' ' ? new TextToken(4, (String)localObject1, ((a)localObject2).a() - 1, ((a)localObject2).a()) : null;
          }
          if (localObject1 == null) {
            localList = paramString.a(str, locala1);
          }
          if ((localObject1 == null) && (localList == null))
          {
            localObject2 = locala1;
            localObject1 = str;
            ((a)localObject2).b();
            localObject1 = ".…,:;?¿!¡-‘\\\"“”«»'’()#$%&\\\\/*+<=>@[]^_`´{}|~•†‡°¦".indexOf(((String)localObject1).charAt(((a)localObject2).a())) != -1 ? new TextToken(3, (String)localObject1, ((a)localObject2).a() - 1, ((a)localObject2).a()) : null;
          }
          if ((localObject1 == null) && (localList == null)) {
            locala1.b();
          } else if (localObject1 != null) {
            localArrayList.add(localObject1);
          } else if (localList != null) {
            localArrayList.addAll(localList);
          }
        }
      }
    }
    return localArrayList;
  }
  
  private List a(String paramString, a parama)
  {
    Matcher localMatcher;
    if (((localMatcher = this.b.matcher(paramString)).find(parama.a())) && (localMatcher.start() != localMatcher.end()) && (parama.a() == localMatcher.start()))
    {
      ArrayList localArrayList;
      (localArrayList = new ArrayList()).add(new TextToken(1, paramString, localMatcher.start(), localMatcher.end()));
      paramString = localMatcher.groupCount();
      String str1;
      if (((str1 = localMatcher.group(0)) != null) && (str1.contains(" ")) && (paramString > 0)) {
        for (String str2 = 0; str2 < paramString; str2++)
        {
          String str3;
          if (((str3 = localMatcher.group(str2)) != null) && (!str3.equals(str1))) {
            localArrayList.add(new TextToken(1, str3));
          }
        }
      }
      parama.a(localMatcher.end());
      return localArrayList;
    }
    return null;
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/core/text/TextParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */