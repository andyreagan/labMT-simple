package com.liwc.core.text;

import java.io.InputStream;
import org.apache.poi.POITextExtractor;
import org.apache.poi.extractor.ExtractorFactory;
import org.apache.poi.hwpf.extractor.Word6Extractor;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

public class MSWordFile
  extends RawText
{
  public MSWordFile(InputStream paramInputStream)
  {
    super(a(paramInputStream));
  }
  
  private static String a(InputStream paramInputStream)
  {
    try
    {
      paramInputStream = ExtractorFactory.createExtractor(paramInputStream);
    }
    catch (Exception localException)
    {
      throw new InvalidFormatException("MSWord document is corrupted or unsupported");
    }
    if ((paramInputStream instanceof Word6Extractor)) {
      throw new InvalidFormatException("MSWord6 documents are not supported");
    }
    if (paramInputStream == null) {
      throw new InvalidFormatException("Cannot open MSWord document");
    }
    String str = paramInputStream.getText();
    paramInputStream.close();
    return str;
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/core/text/MSWordFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */