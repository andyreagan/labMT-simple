/*     */ package com.liwc.LIWC2015;
/*     */ 
/*     */ import com.liwc.LIWC2015.controller.HelpWindowController;
/*     */ import com.liwc.LIWC2015.controller.MainMenuController;
/*     */ import com.liwc.LIWC2015.controller.ProgressDialogController;
/*     */ import com.liwc.LIWC2015.controller.RegisterDialogController;
/*     */ import com.liwc.LIWC2015.controller.WelcomeScreenController;
/*     */ import com.liwc.LIWC2015.customview.ResultPane;
/*     */ import com.liwc.LIWC2015.model.Dictionaries;
/*     */ import com.liwc.LIWC2015.model.Dictionary;
/*     */ import com.liwc.LIWC2015.model.WelcomeScreenModel;
/*     */ import com.liwc.core.dictionary.IDictionary;
/*     */ import com.liwc.jsell.ESellerate;
/*     */ import com.liwc.jsell.ESellerateException;
/*     */ import com.sun.glass.ui.Application.EventHandler;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.fxml.FXMLLoader;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.Scene;
/*     */ import javafx.scene.control.Alert.AlertType;
/*     */ import javafx.scene.control.ButtonType;
/*     */ import javafx.scene.control.Menu;
/*     */ import javafx.scene.control.MenuBar;
/*     */ import javafx.scene.control.Tab;
/*     */ import javafx.scene.control.TabPane;
/*     */ import javafx.scene.layout.VBox;
/*     */ import javafx.stage.Stage;
/*     */ import javafx.stage.WindowEvent;
/*     */ import org.slf4j.Logger;
/*     */ 
/*     */ public class App extends javafx.application.Application
/*     */ {
/*  41 */   private static Logger logger = org.slf4j.LoggerFactory.getLogger(App.class);
/*     */   private LiwcPreferences liwcPreferences;
/*     */   private Dictionaries dictionaries;
/*     */   private IDictionary activeDictionary;
/*     */   private Stage stage;
/*     */   private TabPane resultTabs;
/*     */   private ResultPane activeResultPane;
/*     */   
/*     */   public App() {
/*  50 */     this.activeResultPane = null;
/*     */     
/*  52 */     this.menuBar = null;
/*  53 */     this.resultPaneList = new java.util.ArrayList();
/*  54 */     this.modalIsOpen = false;
/*  55 */     this.helpWindow = null;
/*  56 */     this.welcomeScreenModel = new WelcomeScreenModel();
/*     */   }
/*     */   
/*     */   public final void start(Stage stage) throws Exception {
/*  60 */     this.stage = stage;
/*  61 */     this.liwcPreferences = LiwcPreferences.load();
/*     */     
/*  63 */     this.dictionaries = Dictionaries.load();
/*  64 */     initActiveDictionary();
/*  65 */     this.welcomeScreenModel.setSegmentOptions(WelcomeScreenController.buildSegmentOptionsString(this.liwcPreferences.getSegmentOptions()));
/*  66 */     this.welcomeScreenModel.setAllCategoriesOn(WelcomeScreenController.buildCategoriesString(this.liwcPreferences.getCategories(), this.activeDictionary));
/*     */     
/*  68 */     if (Utils.isMac()) {
/*  69 */       stage.initStyle(javafx.stage.StageStyle.TRANSPARENT);
/*     */     }
/*  71 */     javafx.scene.Parent rootNode = (javafx.scene.Parent)FXMLLoader.load(getClass().getResource("/com/liwc/LIWC2015/view/MainWindow.fxml"));
/*     */     Scene scene;
/*     */     Scene scene;
/*  74 */     if (Utils.isMac()) {
/*  75 */       scene = new Scene(rootNode, 1.0D, 1.0D);
/*     */     } else {
/*  77 */       scene = new Scene(rootNode);
/*     */     }
/*     */     
/*  80 */     scene.getStylesheets().add("/com/liwc/LIWC2015/styles/styles.css");
/*  81 */     stage.setTitle("LIWC2015");
/*  82 */     stage.setScene(scene);
/*  83 */     scene.setFill(null);
/*     */     
/*     */ 
/*  86 */     if (Utils.isMac()) {
/*  87 */       com.sun.glass.ui.Application app = com.sun.glass.ui.Application.GetApplication();
/*  88 */       final Application.EventHandler origEventHandler = app.getEventHandler();
/*  89 */       app.setEventHandler(new Application.EventHandler()
/*     */       {
/*     */         public void handleQuitAction(com.sun.glass.ui.Application app, long time) {
/*  92 */           if (!App.this.modalIsOpen) {
/*  93 */             LiwcPreferences.save(App.this.liwcPreferences);
/*  94 */             if (App.this.closeResultPanes())
/*  95 */               origEventHandler.handleQuitAction(app, time);
/*     */           }
/*     */         }
/*     */       });
/*     */     } else {
/* 100 */       stage.setOnCloseRequest(new EventHandler()
/*     */       {
/*     */         public void handle(WindowEvent event) {
/* 103 */           if (!App.this.modalIsOpen) {
/* 104 */             LiwcPreferences.save(App.this.liwcPreferences);
/* 105 */             if (!App.this.closeResultPanes()) {
/* 106 */               event.consume();
/*     */             }
/*     */           } else {
/* 109 */             event.consume();
/*     */           }
/*     */         }
/*     */       });
/*     */     }
/*     */     
/* 115 */     stage.show();
/* 116 */     initMenu(scene);
/* 117 */     if (!Utils.isMac())
/*     */     {
/*     */ 
/* 120 */       VBox vBox = (VBox)rootNode;
/* 121 */       this.resultTabs = new TabPane();
/* 122 */       this.resultTabs.prefWidthProperty().bind(stage.widthProperty());
/* 123 */       this.resultTabs.prefHeightProperty().bind(stage.heightProperty());
/* 124 */       vBox.getChildren().add(this.resultTabs);
/*     */     }
/*     */     
/* 127 */     if (!validate()) {
/* 128 */       javafx.application.Platform.exit();
/*     */     }
/* 130 */     showWelcomeScreen();
/*     */   }
/*     */   
/*     */   public Stage getStage() {
/* 134 */     return this.stage;
/*     */   }
/*     */   
/*     */   public Dictionaries getDictionaries() {
/* 138 */     return this.dictionaries;
/*     */   }
/*     */   
/*     */   public IDictionary getActiveDictionary() {
/* 142 */     return this.activeDictionary;
/*     */   }
/*     */   
/*     */   private MainMenuController mainMenuController;
/*     */   private MenuBar menuBar;
/*     */   private List<ResultPane> resultPaneList;
/*     */   private boolean modalIsOpen;
/*     */   private Stage helpWindow;
/*     */   private WelcomeScreenModel welcomeScreenModel;
/*     */   public IDictionary setExtActiveDictionary(String dictionaryPath) {
/* 152 */     IDictionary dictionary = null;
/*     */     try {
/* 154 */       File dicPath = new File(dictionaryPath);
/* 155 */       if (dicPath.exists()) {
/* 156 */         FileInputStream fis = new FileInputStream(dicPath);
/* 157 */         dictionary = new com.liwc.core.dictionary.DicFile(fis, new com.liwc.core.LanguageSettings(getLiwcPreferences().getLocale()));
/* 158 */         fis.close();
/*     */       }
/*     */     } catch (Exception e) {
/* 161 */       logger.error(e.getLocalizedMessage(), e);
/* 162 */       Utils.showException(this, e);
/*     */     }
/* 164 */     if (dictionary != null) {
/* 165 */       this.activeDictionary = dictionary;
/* 166 */       this.liwcPreferences.setExternalDictionary(dictionaryPath);
/* 167 */       this.liwcPreferences.getCategories().setShowAnalytic(false);
/* 168 */       this.liwcPreferences.getCategories().setShowClout(false);
/* 169 */       this.liwcPreferences.getCategories().setShowAuthentic(false);
/* 170 */       this.liwcPreferences.getCategories().setShowTone(false);
/* 171 */       this.welcomeScreenModel.setActiveDictionaryName(new File(dictionaryPath).getName());
/* 172 */       return dictionary;
/*     */     }
/* 174 */     return dictionary;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IDictionary setIntActiveDictionary(String dictionaryId)
/*     */   {
/* 184 */     IDictionary dictionary = null;
/*     */     try {
/* 186 */       dictionary = Dictionary.load(this.dictionaries.getDictionary(dictionaryId).getRef(), getLiwcPreferences().getLocale());
/*     */     } catch (Exception e) {
/* 188 */       logger.error(e.getLocalizedMessage(), e);
/* 189 */       Utils.showException(this, e);
/*     */     }
/* 191 */     if (dictionary != null) {
/* 192 */       this.activeDictionary = dictionary;
/* 193 */       this.liwcPreferences.setInternalDictionary(dictionaryId);
/* 194 */       if (!dictionaryId.equals("LIWC2015")) {
/* 195 */         this.liwcPreferences.getCategories().setShowAnalytic(false);
/* 196 */         this.liwcPreferences.getCategories().setShowClout(false);
/* 197 */         this.liwcPreferences.getCategories().setShowAuthentic(false);
/* 198 */         this.liwcPreferences.getCategories().setShowTone(false);
/*     */       }
/* 200 */       this.welcomeScreenModel.setActiveDictionaryName(this.dictionaries.getDictionary(dictionaryId).getName());
/*     */     }
/* 202 */     return dictionary;
/*     */   }
/*     */   
/*     */   public LiwcPreferences getLiwcPreferences() {
/* 206 */     return this.liwcPreferences;
/*     */   }
/*     */   
/*     */   public ResultPane newResultPane(com.liwc.LIWC2015.controller.IPaneController controller, String text) {
/* 210 */     com.liwc.LIWC2015.customview.ICloseable parent = Utils.isMac() ? new com.liwc.LIWC2015.customview.CloseableStage() : new com.liwc.LIWC2015.customview.CloseableTab();
/* 211 */     final ResultPane pane = new ResultPane(this, parent, text);
/* 212 */     pane.getStylesheets().addAll(new String[] { "/com/liwc/LIWC2015/styles/ResultPaneStyles.css" });
/* 213 */     pane.setController(controller);
/* 214 */     this.resultPaneList.add(pane);
/* 215 */     if (Utils.isMac()) {
/* 216 */       Stage stage = (Stage)parent;
/* 217 */       Scene scene = new Scene(pane, 800.0D, 600.0D);
/* 218 */       stage.setTitle(text);
/* 219 */       stage.setScene(scene);
/* 220 */       stage.initOwner(null);
/* 221 */       stage.setOnCloseRequest(new EventHandler()
/*     */       {
/*     */         public void handle(WindowEvent event) {
/* 224 */           pane.onClose(event);
/* 225 */           if (!event.isConsumed())
/* 226 */             App.this.resultPaneList.remove(pane);
/*     */         }
/* 228 */       });
/* 229 */       stage.focusedProperty().addListener(new javafx.beans.value.ChangeListener()
/*     */       {
/*     */         public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
/* 232 */           if (newValue.booleanValue()) {
/* 233 */             App.this.activeResultPane = pane;
/* 234 */             if ((pane != null) && 
/* 235 */               (!pane.getChildren().contains(App.this.menuBar))) {
/* 236 */               pane.getChildren().addAll(new Node[] { App.this.menuBar });
/*     */             }
/*     */           } else {
/* 239 */             App.this.activeResultPane = null;
/* 240 */             if (!App.this.getRoot().getChildren().contains(App.this.menuBar))
/* 241 */               App.this.getRoot().getChildren().addAll(new Node[] { App.this.menuBar });
/*     */           }
/* 243 */           App.this.updateMenu();
/*     */         }
/* 245 */       });
/* 246 */       pane.prefWidthProperty().bind(stage.widthProperty());
/* 247 */       pane.prefHeightProperty().bind(stage.heightProperty());
/* 248 */       stage.show();
/*     */     } else {
/* 250 */       Tab tab = (com.liwc.LIWC2015.customview.CloseableTab)parent;
/* 251 */       tab.setContent(pane);
/* 252 */       tab.setText(text);
/* 253 */       tab.setOnCloseRequest(new EventHandler()
/*     */       {
/*     */         public void handle(Event event) {
/* 256 */           pane.onClose(event);
/* 257 */           if (!event.isConsumed())
/* 258 */             App.this.resultPaneList.remove(pane);
/*     */         }
/* 260 */       });
/* 261 */       this.resultTabs.getSelectionModel().selectedItemProperty().addListener(new javafx.beans.value.ChangeListener()
/*     */       {
/*     */         public void changed(ObservableValue<? extends Tab> observable, Tab oldValue, Tab newValue) {
/* 264 */           App.this.activeResultPane = (newValue == null ? null : (ResultPane)newValue.getContent());
/* 265 */           App.this.updateMenu();
/*     */         }
/* 267 */       });
/* 268 */       this.resultTabs.getTabs().add(tab);
/* 269 */       this.resultTabs.getSelectionModel().select(tab);
/* 270 */       pane.prefWidthProperty().bind(this.resultTabs.widthProperty());
/* 271 */       pane.prefHeightProperty().bind(this.resultTabs.heightProperty());
/*     */     }
/* 273 */     return pane;
/*     */   }
/*     */   
/*     */   public void updateMenu() {
/* 277 */     if (this.mainMenuController != null)
/* 278 */       this.mainMenuController.updateMenu(this.modalIsOpen);
/*     */   }
/*     */   
/*     */   public ResultPane getActiveResultPane() {
/* 282 */     return this.activeResultPane;
/*     */   }
/*     */   
/*     */   public void setModalIsOpen(boolean modalIsOpen) {
/* 286 */     this.modalIsOpen = modalIsOpen;
/* 287 */     updateMenu();
/*     */   }
/*     */   
/*     */   public Stage openHelpWindow() {
/* 291 */     if (this.helpWindow == null) {
/* 292 */       HelpWindowController controller = (HelpWindowController)HelpWindowController.run(this, "/com/liwc/LIWC2015/view/HelpWindow.fxml", new Object[0]);
/* 293 */       this.helpWindow = controller.getStage();
/* 294 */       this.helpWindow.setOnCloseRequest(new EventHandler()
/*     */       {
/*     */         public void handle(WindowEvent event) {
/* 297 */           App.this.helpWindow = null;
/*     */         }
/*     */       });
/*     */     } else {
/* 301 */       this.helpWindow.toFront();
/*     */     }
/* 303 */     return this.helpWindow;
/*     */   }
/*     */   
/*     */   public MenuBar getMenuBar() {
/* 307 */     return this.menuBar;
/*     */   }
/*     */   
/*     */   public VBox getRoot() {
/* 311 */     return (VBox)getStage().getScene().getRoot();
/*     */   }
/*     */   
/*     */   public WelcomeScreenModel getWelcomeScreenModel() {
/* 315 */     return this.welcomeScreenModel;
/*     */   }
/*     */   
/*     */   public java.util.Properties getMvnProperties() {
/* 319 */     return null;
/*     */   }
/*     */   
/*     */   private void initMenu(Scene scene) throws java.io.IOException {
/* 323 */     FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/liwc/LIWC2015/view/MainMenu.fxml"));
/* 324 */     this.menuBar = ((MenuBar)loader.load());
/* 325 */     this.mainMenuController = ((MainMenuController)loader.getController());
/* 326 */     this.mainMenuController.setApp(this);
/* 327 */     if (Utils.isMac())
/* 328 */       this.menuBar.useSystemMenuBarProperty().set(true);
/* 329 */     ((VBox)scene.getRoot()).getChildren().addAll(new Node[] { this.menuBar });
/*     */     
/* 331 */     if (Utils.isMac())
/*     */     {
/* 333 */       Menu file = MainMenuController.getMenu(this.menuBar, "menuFile");
/* 334 */       javafx.scene.control.MenuItem fileQuit = MainMenuController.getMenuItem(file, "menuItemFileQuit");
/* 335 */       javafx.scene.control.MenuItem fileQuitSep = MainMenuController.getMenuItem(file, "menuItemFileQuitSep");
/* 336 */       file.getItems().remove(fileQuit);
/* 337 */       file.getItems().remove(fileQuitSep);
/*     */     }
/*     */   }
/*     */   
/*     */   private void initActiveDictionary()
/*     */   {
/* 343 */     if (this.liwcPreferences.hasExternalDictionary()) {
/* 344 */       IDictionary dictionary = setExtActiveDictionary(this.liwcPreferences.getDictionaryPath());
/* 345 */       if (dictionary == null)
/* 346 */         setIntActiveDictionary("LIWC2015");
/* 347 */     } else if (this.liwcPreferences.hasInternalDictionary()) {
/* 348 */       setIntActiveDictionary(this.liwcPreferences.getDictionaryId());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean closeResultPanes()
/*     */   {
/* 356 */     for (int i = this.resultPaneList.size() - 1; i >= 0; i--) {
/* 357 */       ((ResultPane)this.resultPaneList.get(i)).close();
/* 358 */       if (this.resultPaneList.size() == i + 1)
/*     */         break;
/*     */     }
/* 361 */     return this.resultPaneList.isEmpty();
/*     */   }
/*     */   
/*     */   private void showWelcomeScreen() {
/* 365 */     if (this.liwcPreferences.getShowWelcomeScreen()) {
/* 366 */       WelcomeScreenController controller = (WelcomeScreenController)WelcomeScreenController.run(this, "/com/liwc/LIWC2015/view/WelcomeScreen.fxml", new Object[0]);
/* 367 */       controller.setModel(this.welcomeScreenModel);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean showRegistrationDialog() {
/* 372 */     RegisterDialogController controller = (RegisterDialogController)RegisterDialogController.run(this, "/com/liwc/LIWC2015/view/RegisterDialog.fxml", new Object[0]);
/* 373 */     if (controller.isClosedByUser()) {
/* 374 */       return false;
/*     */     }
/* 376 */     getLiwcPreferences().setSerialNumber(controller.getSerialNumber());
/* 377 */     return validate();
/*     */   }
/*     */   
/*     */   private boolean activate()
/*     */   {
/* 382 */     ActivationTask task = new ActivationTask(this);
/*     */     try {
/* 384 */       ProgressDialogController.run(this, "/com/liwc/LIWC2015/view/ProgressDialog.fxml", new Object[] { task, Boolean.valueOf(false) });
/* 385 */       if (task.getValidationAndActivationException() != null)
/* 386 */         throw task.getValidationAndActivationException();
/* 387 */       boolean result = ((Boolean)task.get()).booleanValue();
/* 388 */       if (result)
/* 389 */         Utils.showAlert(this, Alert.AlertType.INFORMATION, "LIWC2015", null, "Product activation succeeded.");
/* 390 */       return result;
/*     */     } catch (ESellerateException vae) {
/* 392 */       switch (vae.getReason()) {
/*     */       case 5: 
/* 394 */         Utils.showAlert(this, Alert.AlertType.ERROR, "LIWC2015", null, vae.getMessage());
/* 395 */         return showRegistrationDialog();
/*     */       }
/* 397 */       return false;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 401 */       Utils.showException(this, e); }
/* 402 */     return false;
/*     */   }
/*     */   
/*     */   private boolean validate()
/*     */   {
/* 407 */     if ((getLiwcPreferences().getSerialNumber() == null) || (getLiwcPreferences().getSerialNumber().isEmpty())) {
/* 408 */       return showRegistrationDialog();
/*     */     }
/* 410 */     ValidationTask task = new ValidationTask(this);
/*     */     try {
/* 412 */       ProgressDialogController.run(this, "/com/liwc/LIWC2015/view/ProgressDialog.fxml", new Object[] { task, Boolean.valueOf(false) });
/* 413 */       if (task.getValidationAndActivationException() != null)
/* 414 */         throw task.getValidationAndActivationException();
/* 415 */       boolean b = ((Boolean)task.get()).booleanValue();
/* 416 */       if ((b) && (task.getDaysToExpire() <= 10)) {
/* 417 */         Utils.showAlert(this, Alert.AlertType.WARNING, "LIWC2015", null, String.format("Activation for serial number %s expires in %d day(s).", new Object[] { getLiwcPreferences().getSerialNumber(), Integer.valueOf(task.getDaysToExpire()) }));
/*     */       }
/* 419 */       return b;
/*     */     } catch (ESellerateException vae) {
/* 421 */       switch (vae.getReason()) {
/*     */       case 0: 
/* 423 */         Utils.showException(this, vae);
/* 424 */         return showRegistrationDialog();
/*     */       case 1: 
/* 426 */         Utils.showAlert(this, Alert.AlertType.ERROR, "LIWC2015", null, vae.getMessage());
/* 427 */         return showRegistrationDialog();
/*     */       case 3: 
/* 429 */         Utils.showAlert(this, Alert.AlertType.ERROR, "LIWC2015", null, vae.getMessage());
/* 430 */         return showRegistrationDialog();
/*     */       case 2: 
/* 432 */         Utils.showAlert(this, Alert.AlertType.ERROR, "LIWC2015", null, vae.getMessage());
/* 433 */         return showRegistrationDialog();
/*     */       
/*     */       case 4: 
/* 436 */         setModalIsOpen(true);
/* 437 */         Optional<ButtonType> result = new com.liwc.LIWC2015.customview.LIWCAlert(this, Alert.AlertType.CONFIRMATION, "LIWC2015", null, String.format("Would you like to activate serial number %s?", new Object[] { getLiwcPreferences().getSerialNumber() })).showAndWait();
/* 438 */         setModalIsOpen(false);
/* 439 */         if (result.get() == ButtonType.OK) {
/* 440 */           if (activate()) {
/* 441 */             return validate();
/*     */           }
/* 443 */           return false;
/*     */         }
/* 445 */         getLiwcPreferences().setSerialNumber("");
/* 446 */         return validate();
/*     */       }
/*     */       
/* 449 */       return false;
/*     */     }
/*     */     catch (Exception e) {
/* 452 */       Utils.showException(this, e); }
/* 453 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */   public final void deactivate()
/*     */   {
/* 459 */     if (Utils.showAlert(this, Alert.AlertType.CONFIRMATION, "LIWC2015", null, String.format("Would you like to deactivate serial number %s?", new Object[] { this.liwcPreferences.getSerialNumber() }), new ButtonType[] { ButtonType.YES, ButtonType.NO }).get() == ButtonType.YES) {
/* 460 */       DeactivationTask task = new DeactivationTask(this);
/*     */       try {
/* 462 */         ProgressDialogController.run(this, "/com/liwc/LIWC2015/view/ProgressDialog.fxml", new Object[] { task, Boolean.valueOf(false) });
/* 463 */         if (task.getValidationAndActivationException() != null)
/* 464 */           throw task.getValidationAndActivationException();
/* 465 */         boolean result = ((Boolean)task.get()).booleanValue();
/* 466 */         if (result) {
/* 467 */           Utils.showAlert(this, Alert.AlertType.INFORMATION, "LIWC2015", null, "Product deactivation succeeded.");
/* 468 */           getLiwcPreferences().setSerialNumber("");
/* 469 */           LiwcPreferences.save(getLiwcPreferences());
/* 470 */           if (!validate())
/* 471 */             javafx.application.Platform.exit();
/* 472 */           return;
/*     */         }
/*     */       } catch (ESellerateException vae) {
/* 475 */         switch (vae.getReason()) {
/*     */         case 6: 
/* 477 */           Utils.showAlert(this, Alert.AlertType.ERROR, "LIWC2015", null, vae.getMessage());
/*     */         }
/*     */         
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 483 */         Utils.showException(this, e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isLicensePermanent()
/*     */   {
/* 493 */     return Boolean.parseBoolean(getMvnProperties().getProperty("permanent"));
/*     */   }
/*     */   
/*     */   static class ValidationTask extends com.liwc.LIWC2015.controller.CancelableTask<Boolean>
/*     */   {
/*     */     protected App app;
/*     */     protected ESellerateException validationAndActivationException;
/* 500 */     protected int daysToExpire = 8192;
/*     */     
/*     */     public ValidationTask(App app) {
/* 503 */       this.app = app;
/*     */     }
/*     */     
/*     */     final ESellerateException getValidationAndActivationException() {
/* 507 */       return this.validationAndActivationException;
/*     */     }
/*     */     
/*     */     protected Boolean call() throws Exception
/*     */     {
/* 512 */       updateMessage("Validating serial number...");
/* 513 */       boolean result = false;
/*     */       try {
/* 515 */         ESellerate esell = new ESellerate(this.app.isLicensePermanent());
/* 516 */         result = esell.validate(this.app.getLiwcPreferences().getSerialNumber());
/* 517 */         this.daysToExpire = esell.getDaysToExpire();
/*     */       } catch (Exception e) {
/* 519 */         if ((e instanceof ESellerateException)) {
/* 520 */           this.validationAndActivationException = ((ESellerateException)e);
/*     */         } else
/* 522 */           throw e;
/*     */       }
/* 524 */       return Boolean.valueOf(result);
/*     */     }
/*     */     
/*     */     public int getDaysToExpire() {
/* 528 */       return this.daysToExpire;
/*     */     }
/*     */   }
/*     */   
/*     */   static class ActivationTask extends App.ValidationTask
/*     */   {
/*     */     public ActivationTask(App app) {
/* 535 */       super();
/*     */     }
/*     */     
/*     */     protected Boolean call() throws Exception
/*     */     {
/* 540 */       updateMessage("Activating serial number...");
/* 541 */       boolean result = false;
/*     */       try {
/* 543 */         result = new ESellerate(this.app.isLicensePermanent()).activate(this.app.getLiwcPreferences().getSerialNumber());
/*     */       } catch (Exception e) {
/* 545 */         if ((e instanceof ESellerateException)) {
/* 546 */           this.validationAndActivationException = ((ESellerateException)e);
/*     */         } else
/* 548 */           throw e;
/*     */       }
/* 550 */       return Boolean.valueOf(result);
/*     */     }
/*     */   }
/*     */   
/*     */   static class DeactivationTask extends App.ValidationTask
/*     */   {
/*     */     public DeactivationTask(App app) {
/* 557 */       super();
/*     */     }
/*     */     
/*     */     protected Boolean call() throws Exception
/*     */     {
/* 562 */       updateMessage("Deactivating serial number...");
/* 563 */       boolean result = false;
/*     */       try {
/* 565 */         result = new ESellerate(this.app.isLicensePermanent()).deactivate(this.app.getLiwcPreferences().getSerialNumber());
/*     */       } catch (Exception e) {
/* 567 */         if ((e instanceof ESellerateException)) {
/* 568 */           this.validationAndActivationException = ((ESellerateException)e);
/*     */         } else
/* 570 */           throw e;
/*     */       }
/* 572 */       return Boolean.valueOf(result);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/App.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */