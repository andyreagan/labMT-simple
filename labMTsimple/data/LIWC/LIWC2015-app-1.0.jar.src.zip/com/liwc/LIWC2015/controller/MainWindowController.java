/*    */ package com.liwc.LIWC2015.controller;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import java.util.ResourceBundle;
/*    */ import javafx.collections.ObservableList;
/*    */ import javafx.fxml.FXML;
/*    */ import javafx.fxml.FXMLLoader;
/*    */ import javafx.fxml.Initializable;
/*    */ import javafx.scene.Parent;
/*    */ import javafx.scene.Scene;
/*    */ import javafx.scene.control.MenuBar;
/*    */ import javafx.scene.layout.VBox;
/*    */ import javafx.stage.Modality;
/*    */ import javafx.stage.Stage;
/*    */ import javafx.stage.Window;
/*    */ 
/*    */ public class MainWindowController implements Initializable
/*    */ {
/* 20 */   private static Stage stage = null;
/*    */   @FXML
/*    */   private VBox mainVBox;
/*    */   @FXML
/*    */   private MenuBar mainMenuBar;
/*    */   
/* 26 */   private static Stage getStage(Window window) throws IOException { if (stage == null) {
/* 27 */       stage = new Stage();
/* 28 */       String fxmlFile = "/com/liwc/desktop/view/AboutWindow.fxml";
/* 29 */       FXMLLoader loader = new FXMLLoader();
/* 30 */       Parent rootNode = (Parent)loader.load(MainWindowController.class.getResourceAsStream(fxmlFile));
/* 31 */       Scene newScene = new Scene(rootNode);
/* 32 */       newScene.getStylesheets().add("/com/liwc/desktop/styles/styles.css");
/* 33 */       stage.setScene(newScene);
/* 34 */       stage.setTitle("About LIWC2015");
/* 35 */       stage.setResizable(false);
/* 36 */       stage.initModality(Modality.WINDOW_MODAL);
/* 37 */       stage.initOwner(window);
/*    */     }
/* 39 */     return stage;
/*    */   }
/*    */   
/*    */   @FXML
/*    */   private void onAboutMenuItemClick() {
/*    */     try {
/* 45 */       Stage stage = getStage(this.mainVBox.getScene().getWindow());
/* 46 */       stage.show();
/*    */     }
/*    */     catch (IOException localIOException) {}
/*    */   }
/*    */   
/*    */   public void initialize(URL location, ResourceBundle resources) {}
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/MainWindowController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */