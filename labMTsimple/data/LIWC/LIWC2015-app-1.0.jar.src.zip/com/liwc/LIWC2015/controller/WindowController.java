/*    */ package com.liwc.LIWC2015.controller;
/*    */ 
/*    */ import com.liwc.LIWC2015.App;
/*    */ import javafx.stage.Stage;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class WindowController
/*    */ {
/* 12 */   protected static final Logger logger = LoggerFactory.getLogger(WindowController.class);
/*    */   protected App app;
/*    */   protected Stage stage;
/*    */   
/*    */   public App getApp()
/*    */   {
/* 18 */     return this.app;
/*    */   }
/*    */   
/*    */   public Stage getStage() {
/* 22 */     return this.stage;
/*    */   }
/*    */   
/*    */   public abstract Stage initStage(App paramApp, Object... paramVarArgs)
/*    */     throws Exception;
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/WindowController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */