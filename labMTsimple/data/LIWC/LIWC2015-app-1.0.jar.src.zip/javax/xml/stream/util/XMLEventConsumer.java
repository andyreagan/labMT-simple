package javax.xml.stream.util;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;

public abstract interface XMLEventConsumer
{
  public abstract void add(XMLEvent paramXMLEvent)
    throws XMLStreamException;
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/javax/xml/stream/util/XMLEventConsumer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */