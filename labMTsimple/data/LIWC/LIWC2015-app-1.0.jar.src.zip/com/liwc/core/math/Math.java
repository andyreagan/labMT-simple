package com.liwc.core.math;

public class Math
{
  public static final double[] ZScores = { -2.326D, -2.054D, -1.881D, -1.751D, -1.645D, -1.555D, -1.476D, -1.405D, -1.341D, -1.282D, -1.227D, -1.175D, -1.126D, -1.08D, -1.036D, -0.994D, -0.954D, -0.915D, -0.878D, -0.842D, -0.806D, -0.772D, -0.739D, -0.706D, -0.674D, -0.643D, -0.613D, -0.583D, -0.553D, -0.524D, -0.496D, -0.468D, -0.44D, -0.412D, -0.385D, -0.358D, -0.332D, -0.305D, -0.279D, -0.253D, -0.228D, -0.202D, -0.176D, -0.151D, -0.126D, -0.1D, -0.075D, -0.05D, -0.025D, 0.0D, 0.025D, 0.05D, 0.075D, 0.1D, 0.126D, 0.151D, 0.176D, 0.202D, 0.228D, 0.253D, 0.279D, 0.305D, 0.332D, 0.358D, 0.385D, 0.412D, 0.44D, 0.468D, 0.496D, 0.524D, 0.553D, 0.583D, 0.613D, 0.643D, 0.674D, 0.706D, 0.739D, 0.772D, 0.806D, 0.842D, 0.878D, 0.915D, 0.954D, 0.994D, 1.036D, 1.08D, 1.126D, 1.175D, 1.227D, 1.282D, 1.341D, 1.405D, 1.476D, 1.555D, 1.645D, 1.751D, 1.881D, 2.054D, 2.326D };
  
  public static float getPercentileFromZScore(float paramFloat)
  {
    if (paramFloat <= ZScores[0]) {
      return 1.0F;
    }
    if (paramFloat >= ZScores[(ZScores.length - 1)]) {
      return ZScores.length;
    }
    for (int i = 0; i < ZScores.length - 1; i++)
    {
      if (ZScores[i] == paramFloat) {
        return i + 1;
      }
      if ((paramFloat > ZScores[i]) && (paramFloat < ZScores[(i + 1)])) {
        return (float)(i + 1 + (paramFloat - ZScores[i]) / (ZScores[(i + 1)] - ZScores[i]));
      }
    }
    return 0.0F;
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/core/math/Math.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */