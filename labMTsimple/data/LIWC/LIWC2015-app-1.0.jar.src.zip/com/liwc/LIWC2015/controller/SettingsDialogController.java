/*     */ package com.liwc.LIWC2015.controller;
/*     */ 
/*     */ import com.liwc.LIWC2015.App;
/*     */ import com.liwc.LIWC2015.LiwcPreferences;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.Charset;
/*     */ import java.text.DateFormat;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import javafx.beans.property.StringProperty;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.fxml.FXML;
/*     */ import javafx.scene.Scene;
/*     */ import javafx.scene.control.CheckBox;
/*     */ import javafx.scene.control.ChoiceBox;
/*     */ import javafx.scene.control.SingleSelectionModel;
/*     */ import javafx.scene.control.TextField;
/*     */ import javafx.stage.Modality;
/*     */ import javafx.stage.Stage;
/*     */ import org.apache.commons.io.Charsets;
/*     */ 
/*     */ public class SettingsDialogController extends ModalDialogController implements javafx.fxml.Initializable
/*     */ {
/*     */   @FXML
/*     */   private javafx.scene.layout.VBox vBox;
/*     */   @FXML
/*     */   private CheckBox showWelcomeScreenCheckBox;
/*     */   @FXML
/*     */   private ChoiceBox<String> encodingChoice;
/*     */   @FXML
/*     */   private ChoiceBox<String> csvDelimitersChoice;
/*     */   @FXML
/*     */   private ChoiceBox<String> localeChoice;
/*  40 */   private Map<String, Locale> locales = new java.util.TreeMap();
/*     */   
/*     */   @FXML
/*     */   private TextField csvQuoteCharacter;
/*     */   @FXML
/*     */   private TextField csvEscapeCharacter;
/*  46 */   private static final String[] csvDelimiters = { ", (comma)", "tab", "; (semi-colon)", "| (pipe)", "^ (caret)" };
/*     */   
/*     */   public void initialize(URL location, ResourceBundle resources)
/*     */   {
/*  50 */     for (Object localObject = Charset.availableCharsets().keySet().iterator(); ((Iterator)localObject).hasNext();) { enc = (String)((Iterator)localObject).next();
/*  51 */       if (enc.equals(Charsets.UTF_8.name())) {
/*  52 */         this.encodingChoice.getItems().add(String.format("%s [Default]", new Object[] { enc }));
/*     */       } else
/*  54 */         this.encodingChoice.getItems().add(enc);
/*     */     }
/*  56 */     this.encodingChoice.getItems().addAll(Charset.availableCharsets().keySet());
/*  57 */     localObject = DateFormat.getAvailableLocales();String enc = localObject.length; for (String str1 = 0; str1 < enc; str1++) { Locale locale = localObject[str1];
/*  58 */       this.locales.put(locale.getDisplayName(), locale);
/*     */     }
/*  60 */     this.localeChoice.getItems().addAll(this.locales.keySet());
/*  61 */     this.csvDelimitersChoice.getItems().addAll(csvDelimiters);
/*  62 */     this.csvQuoteCharacter.textProperty().addListener(new ChangeListener()
/*     */     {
/*     */       public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
/*  65 */         if (newValue.length() > 1)
/*  66 */           SettingsDialogController.this.csvQuoteCharacter.setText(newValue.substring(0, 1));
/*     */       }
/*  68 */     });
/*  69 */     this.csvEscapeCharacter.textProperty().addListener(new ChangeListener()
/*     */     {
/*     */       public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
/*  72 */         if (newValue.length() > 1) {
/*  73 */           SettingsDialogController.this.csvEscapeCharacter.setText(newValue.substring(0, 1));
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public Stage initStage(App app, Object... args) throws Exception
/*     */   {
/*  81 */     Scene newScene = new Scene(this.vBox);
/*  82 */     Stage stage = new Stage();
/*  83 */     stage.setScene(newScene);
/*  84 */     stage.setResizable(false);
/*  85 */     stage.initModality(Modality.APPLICATION_MODAL);
/*  86 */     if (!com.liwc.LIWC2015.Utils.isMac())
/*  87 */       stage.initStyle(javafx.stage.StageStyle.UTILITY);
/*  88 */     stage.initOwner(null);
/*  89 */     stage.setTitle("Settings");
/*     */     
/*  91 */     this.showWelcomeScreenCheckBox.setSelected(app.getLiwcPreferences().getShowWelcomeScreen());
/*  92 */     if (this.encodingChoice.getItems().contains(app.getLiwcPreferences().getPlainTextEncoding())) {
/*  93 */       this.encodingChoice.setValue(app.getLiwcPreferences().getPlainTextEncoding());
/*     */     } else {
/*  95 */       this.encodingChoice.setValue(Charsets.UTF_8.name());
/*     */     }
/*  97 */     if (((String)this.encodingChoice.getValue()).equals(Charsets.UTF_8.name()))
/*  98 */       this.encodingChoice.setValue(String.format("%s [Default]", new Object[] { Charsets.UTF_8.name() }));
/*  99 */     if (this.localeChoice.getItems().contains(app.getLiwcPreferences().getLocale().getDisplayName())) {
/* 100 */       this.localeChoice.setValue(app.getLiwcPreferences().getLocale().getDisplayName());
/*     */     } else {
/* 102 */       this.localeChoice.setValue(Locale.US.getDisplayName());
/*     */     }
/* 104 */     if (app.getLiwcPreferences().getCsvDelimiter() < this.csvDelimitersChoice.getItems().size()) {
/* 105 */       this.csvDelimitersChoice.getSelectionModel().select(app.getLiwcPreferences().getCsvDelimiter());
/*     */     } else {
/* 107 */       this.csvDelimitersChoice.getSelectionModel().select(0);
/*     */     }
/* 109 */     this.csvQuoteCharacter.setText("" + (app.getLiwcPreferences().getCsvQuoteCharacter() == 0 ? "" : Character.valueOf(app.getLiwcPreferences().getCsvQuoteCharacter())));
/* 110 */     this.csvEscapeCharacter.setText("" + (app.getLiwcPreferences().getCsvEscapeCharacter() == 0 ? "" : Character.valueOf(app.getLiwcPreferences().getCsvEscapeCharacter())));
/* 111 */     return stage;
/*     */   }
/*     */   
/*     */   public void onCancel() {
/* 115 */     this.stage.close();
/*     */   }
/*     */   
/*     */   public void onOK() {
/* 119 */     this.app.getLiwcPreferences().setShowWelcomeScreen(this.showWelcomeScreenCheckBox.isSelected());
/* 120 */     if (((String)this.encodingChoice.getValue()).equals(String.format("%s [Default]", new Object[] { Charsets.UTF_8.name() }))) {
/* 121 */       this.encodingChoice.setValue(Charsets.UTF_8.name());
/*     */     }
/* 123 */     this.app.getLiwcPreferences().setPlainTextEncoding((String)this.encodingChoice.getValue());
/* 124 */     this.app.getLiwcPreferences().setLocale((Locale)this.locales.get(this.localeChoice.getValue()));
/* 125 */     this.app.getLiwcPreferences().setCsvDelimiter(this.csvDelimitersChoice.getSelectionModel().getSelectedIndex());
/* 126 */     this.app.getLiwcPreferences().setCsvQuoteCharacter(this.csvQuoteCharacter.getText().length() == 0 ? '\000' : this.csvQuoteCharacter.getText().charAt(0));
/* 127 */     this.app.getLiwcPreferences().setCsvEscapeCharacter(this.csvEscapeCharacter.getText().length() == 0 ? '\000' : this.csvEscapeCharacter.getText().charAt(0));
/* 128 */     this.stage.close();
/*     */   }
/*     */   
/*     */   public void onLink() {
/* 132 */     this.app.getHostServices().showDocument("http://docs.oracle.com/javase/6/docs/technotes/guides/intl/encoding.doc.html");
/*     */   }
/*     */   
/*     */   public void onReset() {
/* 136 */     this.encodingChoice.setValue(String.format("%s [Default]", new Object[] { Charsets.UTF_8.name() }));
/* 137 */     this.localeChoice.setValue(Locale.US.getDisplayName());
/* 138 */     this.csvDelimitersChoice.getSelectionModel().select(0);
/* 139 */     this.csvQuoteCharacter.setText("\"");
/* 140 */     this.csvEscapeCharacter.setText("");
/* 141 */     this.showWelcomeScreenCheckBox.setSelected(true);
/*     */   }
/*     */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/SettingsDialogController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */