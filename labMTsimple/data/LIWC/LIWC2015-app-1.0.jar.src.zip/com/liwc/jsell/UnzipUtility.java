package com.liwc.jsell;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class UnzipUtility
{
  public void unzip(String paramString1, String paramString2)
  {
    if (!(localObject = new File(paramString2)).exists()) {
      ((File)localObject).mkdir();
    }
    for (Object localObject = (paramString1 = new ZipInputStream(new FileInputStream(paramString1))).getNextEntry(); localObject != null; localObject = paramString1.getNextEntry())
    {
      String str = paramString2 + File.separator + ((ZipEntry)localObject).getName();
      if (!((ZipEntry)localObject).isDirectory()) {
        a(paramString1, str);
      } else {
        (localObject = new File(str)).mkdir();
      }
      paramString1.closeEntry();
    }
    paramString1.close();
  }
  
  private static void a(ZipInputStream paramZipInputStream, String paramString)
  {
    paramString = new BufferedOutputStream(new FileOutputStream(paramString));
    byte[] arrayOfByte = new byte['က'];
    int i;
    while ((i = paramZipInputStream.read(arrayOfByte)) != -1) {
      paramString.write(arrayOfByte, 0, i);
    }
    paramString.close();
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/jsell/UnzipUtility.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */