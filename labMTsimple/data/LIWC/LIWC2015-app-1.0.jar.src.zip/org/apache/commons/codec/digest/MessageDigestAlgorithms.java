package org.apache.commons.codec.digest;

public class MessageDigestAlgorithms
{
  public static final String MD2 = "MD2";
  public static final String MD5 = "MD5";
  public static final String SHA_1 = "SHA-1";
  public static final String SHA_256 = "SHA-256";
  public static final String SHA_384 = "SHA-384";
  public static final String SHA_512 = "SHA-512";
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/org/apache/commons/codec/digest/MessageDigestAlgorithms.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */