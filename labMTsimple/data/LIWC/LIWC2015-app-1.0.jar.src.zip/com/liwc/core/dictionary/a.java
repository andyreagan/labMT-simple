package com.liwc.core.dictionary;

import java.util.Stack;

final class a
  extends Stack
{
  a(DicFile paramDicFile)
  {
    add(this.a.a);
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/core/dictionary/a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */