/*    */ package com.liwc.LIWC2015.controller;
/*    */ 
/*    */ import com.liwc.LIWC2015.App;
/*    */ import com.liwc.LIWC2015.Utils;
/*    */ import java.net.URL;
/*    */ import java.util.ResourceBundle;
/*    */ import javafx.beans.property.BooleanProperty;
/*    */ import javafx.beans.property.DoubleProperty;
/*    */ import javafx.beans.property.ReadOnlyBooleanProperty;
/*    */ import javafx.beans.property.SimpleBooleanProperty;
/*    */ import javafx.beans.property.StringProperty;
/*    */ import javafx.beans.value.ChangeListener;
/*    */ import javafx.beans.value.ObservableValue;
/*    */ import javafx.event.EventHandler;
/*    */ import javafx.fxml.FXML;
/*    */ import javafx.fxml.Initializable;
/*    */ import javafx.scene.Scene;
/*    */ import javafx.scene.control.Button;
/*    */ import javafx.scene.control.Label;
/*    */ import javafx.scene.control.ProgressBar;
/*    */ import javafx.stage.Modality;
/*    */ import javafx.stage.Stage;
/*    */ import javafx.stage.StageStyle;
/*    */ import javafx.stage.WindowEvent;
/*    */ 
/*    */ public class ProgressDialogController extends ModalDialogController implements Initializable
/*    */ {
/*    */   @FXML
/*    */   private ProgressBar progressBar;
/*    */   @FXML
/*    */   private Label progressMessage;
/*    */   private Stage stage;
/*    */   private CancelableTask task;
/*    */   @FXML
/*    */   private javafx.scene.layout.VBox progressDialog;
/* 36 */   private BooleanProperty cancelable = new SimpleBooleanProperty(true);
/*    */   @FXML
/*    */   private Button cancelButton;
/*    */   
/*    */   public void initialize(URL location, ResourceBundle resources)
/*    */   {
/* 42 */     this.cancelButton.visibleProperty().bind(this.cancelable);
/*    */   }
/*    */   
/*    */   public void onCancel() {
/* 46 */     this.task.requestCancel();
/*    */   }
/*    */   
/*    */   private void setTask(CancelableTask task) {
/* 50 */     this.task = task;
/* 51 */     this.progressBar.progressProperty().bind(task.progressProperty());
/* 52 */     this.progressMessage.textProperty().bind(task.messageProperty());
/* 53 */     task.runningProperty().addListener(new ChangeListener()
/*    */     {
/*    */       public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
/* 56 */         if ((ProgressDialogController.this.stage != null) && (!newValue.booleanValue())) {
/* 57 */           ProgressDialogController.this.stage.close();
/*    */         }
/*    */       }
/*    */     });
/*    */   }
/*    */   
/*    */   public Stage initStage(App app, Object... args) throws Exception {
/* 64 */     setTask((CancelableTask)args[0]);
/* 65 */     setCancelable(((Boolean)args[1]).booleanValue());
/* 66 */     Thread th = new Thread(this.task);
/* 67 */     th.setDaemon(true);
/* 68 */     th.start();
/* 69 */     Scene newScene = new Scene(this.progressDialog);
/* 70 */     this.stage = new Stage();
/* 71 */     this.stage.setScene(newScene);
/* 72 */     this.stage.setResizable(false);
/* 73 */     this.stage.initModality(Modality.APPLICATION_MODAL);
/* 74 */     if (!Utils.isMac())
/* 75 */       this.stage.initStyle(StageStyle.UTILITY);
/* 76 */     this.stage.initOwner(null);
/* 77 */     this.stage.setTitle("LIWC2015");
/* 78 */     this.stage.setOnCloseRequest(new EventHandler()
/*    */     {
/*    */       public void handle(WindowEvent event) {
/* 81 */         if (ProgressDialogController.this.cancelable.get())
/* 82 */           ProgressDialogController.this.task.requestCancel();
/* 83 */         event.consume();
/*    */       }
/* 85 */     });
/* 86 */     return this.stage;
/*    */   }
/*    */   
/*    */   private void setCancelable(boolean cancelable) {
/* 90 */     this.cancelable.setValue(Boolean.valueOf(cancelable));
/*    */   }
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/ProgressDialogController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */