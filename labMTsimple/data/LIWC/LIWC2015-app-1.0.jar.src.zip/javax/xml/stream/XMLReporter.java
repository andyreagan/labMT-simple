package javax.xml.stream;

public abstract interface XMLReporter
{
  public abstract void report(String paramString1, String paramString2, Object paramObject, Location paramLocation)
    throws XMLStreamException;
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/javax/xml/stream/XMLReporter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */