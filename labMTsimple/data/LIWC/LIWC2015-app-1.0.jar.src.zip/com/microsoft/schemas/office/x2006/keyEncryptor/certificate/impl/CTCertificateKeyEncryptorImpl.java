package com.microsoft.schemas.office.x2006.keyEncryptor.certificate.impl;

import com.microsoft.schemas.office.x2006.keyEncryptor.certificate.CTCertificateKeyEncryptor;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlBase64Binary;
import org.apache.xmlbeans.impl.values.TypeStore;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;

public class CTCertificateKeyEncryptorImpl
  extends XmlComplexContentImpl
  implements CTCertificateKeyEncryptor
{
  private static final QName ENCRYPTEDKEYVALUE$0 = new QName("", "encryptedKeyValue");
  private static final QName X509CERTIFICATE$2 = new QName("", "X509Certificate");
  private static final QName CERTVERIFIER$4 = new QName("", "certVerifier");
  
  public CTCertificateKeyEncryptorImpl(SchemaType paramSchemaType)
  {
    super(paramSchemaType);
  }
  
  public byte[] getEncryptedKeyValue()
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(ENCRYPTEDKEYVALUE$0);
      if (localSimpleValue == null) {
        return null;
      }
      return localSimpleValue.getByteArrayValue();
    }
  }
  
  public XmlBase64Binary xgetEncryptedKeyValue()
  {
    synchronized (monitor())
    {
      check_orphaned();
      XmlBase64Binary localXmlBase64Binary = null;
      localXmlBase64Binary = (XmlBase64Binary)get_store().find_attribute_user(ENCRYPTEDKEYVALUE$0);
      return localXmlBase64Binary;
    }
  }
  
  public void setEncryptedKeyValue(byte[] paramArrayOfByte)
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(ENCRYPTEDKEYVALUE$0);
      if (localSimpleValue == null) {
        localSimpleValue = (SimpleValue)get_store().add_attribute_user(ENCRYPTEDKEYVALUE$0);
      }
      localSimpleValue.setByteArrayValue(paramArrayOfByte);
    }
  }
  
  public void xsetEncryptedKeyValue(XmlBase64Binary paramXmlBase64Binary)
  {
    synchronized (monitor())
    {
      check_orphaned();
      XmlBase64Binary localXmlBase64Binary = null;
      localXmlBase64Binary = (XmlBase64Binary)get_store().find_attribute_user(ENCRYPTEDKEYVALUE$0);
      if (localXmlBase64Binary == null) {
        localXmlBase64Binary = (XmlBase64Binary)get_store().add_attribute_user(ENCRYPTEDKEYVALUE$0);
      }
      localXmlBase64Binary.set(paramXmlBase64Binary);
    }
  }
  
  public byte[] getX509Certificate()
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(X509CERTIFICATE$2);
      if (localSimpleValue == null) {
        return null;
      }
      return localSimpleValue.getByteArrayValue();
    }
  }
  
  public XmlBase64Binary xgetX509Certificate()
  {
    synchronized (monitor())
    {
      check_orphaned();
      XmlBase64Binary localXmlBase64Binary = null;
      localXmlBase64Binary = (XmlBase64Binary)get_store().find_attribute_user(X509CERTIFICATE$2);
      return localXmlBase64Binary;
    }
  }
  
  public void setX509Certificate(byte[] paramArrayOfByte)
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(X509CERTIFICATE$2);
      if (localSimpleValue == null) {
        localSimpleValue = (SimpleValue)get_store().add_attribute_user(X509CERTIFICATE$2);
      }
      localSimpleValue.setByteArrayValue(paramArrayOfByte);
    }
  }
  
  public void xsetX509Certificate(XmlBase64Binary paramXmlBase64Binary)
  {
    synchronized (monitor())
    {
      check_orphaned();
      XmlBase64Binary localXmlBase64Binary = null;
      localXmlBase64Binary = (XmlBase64Binary)get_store().find_attribute_user(X509CERTIFICATE$2);
      if (localXmlBase64Binary == null) {
        localXmlBase64Binary = (XmlBase64Binary)get_store().add_attribute_user(X509CERTIFICATE$2);
      }
      localXmlBase64Binary.set(paramXmlBase64Binary);
    }
  }
  
  public byte[] getCertVerifier()
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(CERTVERIFIER$4);
      if (localSimpleValue == null) {
        return null;
      }
      return localSimpleValue.getByteArrayValue();
    }
  }
  
  public XmlBase64Binary xgetCertVerifier()
  {
    synchronized (monitor())
    {
      check_orphaned();
      XmlBase64Binary localXmlBase64Binary = null;
      localXmlBase64Binary = (XmlBase64Binary)get_store().find_attribute_user(CERTVERIFIER$4);
      return localXmlBase64Binary;
    }
  }
  
  public void setCertVerifier(byte[] paramArrayOfByte)
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(CERTVERIFIER$4);
      if (localSimpleValue == null) {
        localSimpleValue = (SimpleValue)get_store().add_attribute_user(CERTVERIFIER$4);
      }
      localSimpleValue.setByteArrayValue(paramArrayOfByte);
    }
  }
  
  public void xsetCertVerifier(XmlBase64Binary paramXmlBase64Binary)
  {
    synchronized (monitor())
    {
      check_orphaned();
      XmlBase64Binary localXmlBase64Binary = null;
      localXmlBase64Binary = (XmlBase64Binary)get_store().find_attribute_user(CERTVERIFIER$4);
      if (localXmlBase64Binary == null) {
        localXmlBase64Binary = (XmlBase64Binary)get_store().add_attribute_user(CERTVERIFIER$4);
      }
      localXmlBase64Binary.set(paramXmlBase64Binary);
    }
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/keyEncryptor/certificate/impl/CTCertificateKeyEncryptorImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */