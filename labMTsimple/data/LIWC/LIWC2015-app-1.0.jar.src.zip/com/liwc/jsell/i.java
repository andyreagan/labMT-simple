package com.liwc.jsell;

import java.io.File;

abstract interface i
{
  public abstract Process a(File paramFile);
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/jsell/i.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */