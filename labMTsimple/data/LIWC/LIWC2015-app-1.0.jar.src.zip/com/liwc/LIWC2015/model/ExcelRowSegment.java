/*    */ package com.liwc.LIWC2015.model;
/*    */ 
/*    */ import com.liwc.core.Segment;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ExcelRowSegment extends DataSegment
/*    */ {
/*    */   private List<Cell> excelRow;
/*    */   
/*    */   public ExcelRowSegment(List<Cell> excelRow)
/*    */   {
/* 12 */     super(null);
/* 13 */     this.excelRow = excelRow;
/*    */   }
/*    */   
/*    */   public void addSegment(Segment segment) {
/* 17 */     if (this.segment == null) {
/* 18 */       this.segment = segment;
/*    */     } else
/* 20 */       this.segment = this.segment.merge(segment);
/*    */   }
/*    */   
/*    */   public List<Cell> getExcelRow() {
/* 24 */     return this.excelRow;
/*    */   }
/*    */   
/*    */   public static class Cell {
/*    */     private String value;
/*    */     private boolean selected;
/*    */     
/*    */     public Cell(String value, boolean selected) {
/* 32 */       this.value = value;
/* 33 */       this.selected = selected;
/*    */     }
/*    */     
/*    */     public Cell(String value) {
/* 37 */       this(value, false);
/*    */     }
/*    */     
/*    */     public String getValue() {
/* 41 */       return this.value;
/*    */     }
/*    */     
/*    */     public boolean isSelected() {
/* 45 */       return this.selected;
/*    */     }
/*    */     
/*    */     public void setSelected(boolean selected) {
/* 49 */       this.selected = selected;
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/model/ExcelRowSegment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */