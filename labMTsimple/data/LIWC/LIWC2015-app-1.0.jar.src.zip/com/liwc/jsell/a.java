package com.liwc.jsell;

import java.util.HashMap;

final class a
  extends HashMap
{
  a()
  {
    put(Long.valueOf(0L), "The call completed successfully.");
    put(Long.valueOf(3758096384L), "A parameter is incorrect.");
    put(Long.valueOf(1610612742L), "A SKU update is available from the eSellerate servers.");
    put(Long.valueOf(1610612743L), "No SKU update is available from the eSellerate servers.");
    put(Long.valueOf(3758096387L), "An internal error has occurred in the engine.");
    put(Long.valueOf(3758096388L), "A purchase attempt was unsuccessful.");
    put(Long.valueOf(3758424064L), "The current machine does not match the machine on which the product was activated.");
    put(Long.valueOf(537198593L), "The current machine matches the machine on which the product was activated.");
    put(Long.valueOf(3758424065L), "The supplied activation key is invalid.");
    put(Long.valueOf(3758424066L), "The format of the supplied activation key is invalid.");
    put(Long.valueOf(3758424067L), "An unknown server error has occurred.");
    put(Long.valueOf(3758424068L), "An attempt was made to activate an unknown serial number.");
    put(Long.valueOf(3758424069L), "Improper usage of the activation routines.");
    put(Long.valueOf(3758424070L), "An attempt was made to activate a blacklisted serial number.");
    put(Long.valueOf(3758424071L), "An activation attempt was made on an invalid order.");
    put(Long.valueOf(3758424072L), "An activation attempt failed due to the maximum number of allowable activations being met.");
    put(Long.valueOf(3758424073L), "The serial number to be activated is not unique.");
    put(Long.valueOf(3758424074L), "An error occurred finalizing the activation on the client machine.");
    put(Long.valueOf(3758424075L), "The eSellerate servers failed to return a valid activation key.");
    put(Long.valueOf(3758424076L), "The user canceled a manual activation attempt.");
    put(Long.valueOf(3768582145L), "An activation attempt failed due to an unexpected error.");
    put(Long.valueOf(3768733714L), "eSellerate denied the activation request.");
    put(Long.valueOf(3770679297L), "A confirmation attempt failed due to an unexpected error.");
    put(Long.valueOf(3770830849L), "An attempt was made to confirm an unknown serial number.");
    put(Long.valueOf(3770830851L), "An attempt was made to confirm a blacklisted serial number.");
    put(Long.valueOf(3770830852L), "A confirmation attempt was made on an invalid order.");
    put(Long.valueOf(3771727873L), "A deactivation attempt failed due to an unexpected error.");
    put(Long.valueOf(3771879425L), "An attempt was made to deactivate an unknown serial number.");
    put(Long.valueOf(3771879427L), "An attempt was made to deactivate a blacklisted serial number");
    put(Long.valueOf(3771879428L), "A deactivation attempt was made on an invalid order.");
    put(Long.valueOf(3771879430L), "A deactivation attempt failed because the supplied activation key is unknown.");
    put(Long.valueOf(3771879431L), "A deactivation attempt failed because the current machine does not match the machine on which the product was activated.");
    put(Long.valueOf(3771879432L), "A deactivation attempt failed because the supplied activation key is invalid.");
    put(Long.valueOf(3771879433L), "A deactivation attempt failed because the serial number to be deactivated is not unique.");
    put(Long.valueOf(3771879440L), "A deactivation attempt failed because the supplied activation key is unknown.");
    put(Long.valueOf(3771879441L), "A deactivation attempt failed due to the maximum number of allowable deactivations being met.");
    put(Long.valueOf(3758292992L), "The engine requires functionality of the operating system that is not available.");
    put(Long.valueOf(536936448L), "The latest engine is already installed.");
    put(Long.valueOf(536936449L), "The latest engine was successfully installed.");
    put(Long.valueOf(3758161924L), "No engine is installed.");
    put(Long.valueOf(3758161925L), "The SDK failed to add a name/value entry.");
    put(Long.valueOf(3758161926L), "The engine is corrupted.");
    put(Long.valueOf(3758161927L), "The engine resource could not be used.");
    put(Long.valueOf(3758161928L), "A parameter is incorrect.");
    put(Long.valueOf(3758161929L), "The SDK could not find a requested data object or value.");
    put(Long.valueOf(3758161936L), "A system is not compatible with activation SDK.");
    put(Long.valueOf(3758227456L), "A general connection failure has occurred.");
    put(Long.valueOf(3758227458L), "The engine could not reach the network because it is operating in silent mode.");
    put(Long.valueOf(3758227459L), "The engine failed to reach the network due to a device failure.");
    put(Long.valueOf(-2001L), "The SDK failed to add a name/value entnry.");
    put(Long.valueOf(-2002L), "A parameter is incorrect.");
    put(Long.valueOf(-2003L), "There was an error installing the engine.");
    put(Long.valueOf(-2005L), "The engine is corrupted.");
    put(Long.valueOf(-2007L), "The result from the engine could not be found.");
    put(Long.valueOf(-2008L), "The engine is already running within the application.");
    put(Long.valueOf(-3001L), "A general connection failure has occured.");
    put(Long.valueOf(-3002L), "The engine failed to connect to the eSellerate servers.");
    put(Long.valueOf(-3003L), "The engine failed to download an update.");
    put(Long.valueOf(-3004L), "The eSellerate engine data is missing from the results.");
    put(Long.valueOf(5000L), "The current machine matches the machine on which the product was activated.");
    put(Long.valueOf(-5001L), "The current machine does not match the machine on which the product was activated.");
    put(Long.valueOf(-5002L), "The old activation key is invalid.");
    put(Long.valueOf(-5005L), "The user cancelled a manual activation attempt.");
    put(Long.valueOf(-25000L), "The format of the supplied activation key is invalid.");
    put(Long.valueOf(-25001L), "An attempt was made to activate an unknown serial number.");
    put(Long.valueOf(-25002L), "Improper usage of the activation routines.");
    put(Long.valueOf(-25003L), "An attempt was made to activate an blacklisted serial number.");
    put(Long.valueOf(-25004L), "An activation attempt was made on an invalid order.");
    put(Long.valueOf(-25005L), "An activation attempt failed due to the maximum number of allowable activations being met.");
    put(Long.valueOf(-25009L), "The serial number to be activated is not unique.");
    put(Long.valueOf(-25010L), "An unknown server error has occured.");
    put(Long.valueOf(-25011L), "An error occured finalizing the activation on the client machine.");
    put(Long.valueOf(-25012L), "");
    put(Long.valueOf(-25013L), "The eSellerate server failed to return a valid activation key.");
    put(Long.valueOf(-25001L), "");
    put(Long.valueOf(-25002L), "");
    put(Long.valueOf(-25003L), "");
    put(Long.valueOf(-25004L), "");
    put(Long.valueOf(-25010L), "");
    put(Long.valueOf(-25001L), "");
    put(Long.valueOf(-25003L), "");
    put(Long.valueOf(-25004L), "");
    put(Long.valueOf(-25006L), "");
    put(Long.valueOf(-25007L), "");
    put(Long.valueOf(-25008L), "");
    put(Long.valueOf(-25009L), "");
    put(Long.valueOf(-25010L), "");
    put(Long.valueOf(-25011L), "");
    put(Long.valueOf(6000L), "A SKU update is available from the eSellerate Servers.");
    put(Long.valueOf(-6000L), "No SKU update is available from the eSellerate Servers.");
    put(Long.valueOf(-6001L), "An internal error has occured in the engine.");
    put(Long.valueOf(-6002L), "A purchase attempt was unsuccessful.");
    put(Long.valueOf(-7000L), "The system does not meet the minimum requirements for the Embedded Web Store");
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/jsell/a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */