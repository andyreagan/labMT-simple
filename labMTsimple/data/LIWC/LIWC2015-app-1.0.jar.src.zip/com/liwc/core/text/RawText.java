package com.liwc.core.text;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class RawText
  implements IText
{
  private String a;
  private List b = new ArrayList();
  private int c = 0;
  private int d = 0;
  private int e = 0;
  private int f = 0;
  
  public RawText(String paramString)
  {
    paramString = paramString.replaceAll("(\r\n)|\n", "\r").replaceAll("’", "'");
    this.a = paramString;
  }
  
  public List readText(TextParser paramTextParser)
  {
    this.b = paramTextParser.parseText(this.a);
    paramTextParser = this.b.iterator();
    while (paramTextParser.hasNext())
    {
      Object localObject;
      switch ((localObject = (TextToken)paramTextParser.next()).getTokenType())
      {
      case 1: 
        this.c += 1;
        localObject = TextParser.extractPunctuationMarks(((TextToken)localObject).getTokenValue());
        this.d += (localObject == null ? 0 : ((List)localObject).size());
        break;
      case 3: 
        this.d += 1;
        break;
      case 4: 
        this.e += 1;
        break;
      case 2: 
        this.f += 1;
      }
    }
    return this.b;
  }
  
  public void close()
  {
    this.a = null;
    this.b.clear();
    this.b = null;
    this.c = (this.d = this.e = 0);
  }
  
  public int getWordsCount(boolean paramBoolean)
  {
    if (paramBoolean) {
      return this.c + this.f;
    }
    return this.c;
  }
  
  public int getPunctuationMarksCount()
  {
    return this.d;
  }
  
  public int getDelimitersCount()
  {
    return this.e;
  }
  
  public int getNumbersCount()
  {
    return this.f;
  }
  
  public List getTokens()
  {
    return this.b;
  }
  
  public String getText()
  {
    return this.a;
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/core/text/RawText.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */