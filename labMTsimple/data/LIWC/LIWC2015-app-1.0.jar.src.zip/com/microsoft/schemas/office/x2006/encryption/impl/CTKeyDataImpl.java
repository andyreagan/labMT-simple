package com.microsoft.schemas.office.x2006.encryption.impl;

import com.microsoft.schemas.office.x2006.encryption.CTKeyData;
import com.microsoft.schemas.office.x2006.encryption.STBlockSize;
import com.microsoft.schemas.office.x2006.encryption.STCipherAlgorithm;
import com.microsoft.schemas.office.x2006.encryption.STCipherAlgorithm.Enum;
import com.microsoft.schemas.office.x2006.encryption.STCipherChaining;
import com.microsoft.schemas.office.x2006.encryption.STCipherChaining.Enum;
import com.microsoft.schemas.office.x2006.encryption.STHashAlgorithm;
import com.microsoft.schemas.office.x2006.encryption.STHashAlgorithm.Enum;
import com.microsoft.schemas.office.x2006.encryption.STHashSize;
import com.microsoft.schemas.office.x2006.encryption.STKeyBits;
import com.microsoft.schemas.office.x2006.encryption.STSaltSize;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlBase64Binary;
import org.apache.xmlbeans.impl.values.TypeStore;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;

public class CTKeyDataImpl
  extends XmlComplexContentImpl
  implements CTKeyData
{
  private static final QName SALTSIZE$0 = new QName("", "saltSize");
  private static final QName BLOCKSIZE$2 = new QName("", "blockSize");
  private static final QName KEYBITS$4 = new QName("", "keyBits");
  private static final QName HASHSIZE$6 = new QName("", "hashSize");
  private static final QName CIPHERALGORITHM$8 = new QName("", "cipherAlgorithm");
  private static final QName CIPHERCHAINING$10 = new QName("", "cipherChaining");
  private static final QName HASHALGORITHM$12 = new QName("", "hashAlgorithm");
  private static final QName SALTVALUE$14 = new QName("", "saltValue");
  
  public CTKeyDataImpl(SchemaType paramSchemaType)
  {
    super(paramSchemaType);
  }
  
  public int getSaltSize()
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(SALTSIZE$0);
      if (localSimpleValue == null) {
        return 0;
      }
      return localSimpleValue.getIntValue();
    }
  }
  
  public STSaltSize xgetSaltSize()
  {
    synchronized (monitor())
    {
      check_orphaned();
      STSaltSize localSTSaltSize = null;
      localSTSaltSize = (STSaltSize)get_store().find_attribute_user(SALTSIZE$0);
      return localSTSaltSize;
    }
  }
  
  public void setSaltSize(int paramInt)
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(SALTSIZE$0);
      if (localSimpleValue == null) {
        localSimpleValue = (SimpleValue)get_store().add_attribute_user(SALTSIZE$0);
      }
      localSimpleValue.setIntValue(paramInt);
    }
  }
  
  public void xsetSaltSize(STSaltSize paramSTSaltSize)
  {
    synchronized (monitor())
    {
      check_orphaned();
      STSaltSize localSTSaltSize = null;
      localSTSaltSize = (STSaltSize)get_store().find_attribute_user(SALTSIZE$0);
      if (localSTSaltSize == null) {
        localSTSaltSize = (STSaltSize)get_store().add_attribute_user(SALTSIZE$0);
      }
      localSTSaltSize.set(paramSTSaltSize);
    }
  }
  
  public int getBlockSize()
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(BLOCKSIZE$2);
      if (localSimpleValue == null) {
        return 0;
      }
      return localSimpleValue.getIntValue();
    }
  }
  
  public STBlockSize xgetBlockSize()
  {
    synchronized (monitor())
    {
      check_orphaned();
      STBlockSize localSTBlockSize = null;
      localSTBlockSize = (STBlockSize)get_store().find_attribute_user(BLOCKSIZE$2);
      return localSTBlockSize;
    }
  }
  
  public void setBlockSize(int paramInt)
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(BLOCKSIZE$2);
      if (localSimpleValue == null) {
        localSimpleValue = (SimpleValue)get_store().add_attribute_user(BLOCKSIZE$2);
      }
      localSimpleValue.setIntValue(paramInt);
    }
  }
  
  public void xsetBlockSize(STBlockSize paramSTBlockSize)
  {
    synchronized (monitor())
    {
      check_orphaned();
      STBlockSize localSTBlockSize = null;
      localSTBlockSize = (STBlockSize)get_store().find_attribute_user(BLOCKSIZE$2);
      if (localSTBlockSize == null) {
        localSTBlockSize = (STBlockSize)get_store().add_attribute_user(BLOCKSIZE$2);
      }
      localSTBlockSize.set(paramSTBlockSize);
    }
  }
  
  public long getKeyBits()
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(KEYBITS$4);
      if (localSimpleValue == null) {
        return 0L;
      }
      return localSimpleValue.getLongValue();
    }
  }
  
  public STKeyBits xgetKeyBits()
  {
    synchronized (monitor())
    {
      check_orphaned();
      STKeyBits localSTKeyBits = null;
      localSTKeyBits = (STKeyBits)get_store().find_attribute_user(KEYBITS$4);
      return localSTKeyBits;
    }
  }
  
  public void setKeyBits(long paramLong)
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(KEYBITS$4);
      if (localSimpleValue == null) {
        localSimpleValue = (SimpleValue)get_store().add_attribute_user(KEYBITS$4);
      }
      localSimpleValue.setLongValue(paramLong);
    }
  }
  
  public void xsetKeyBits(STKeyBits paramSTKeyBits)
  {
    synchronized (monitor())
    {
      check_orphaned();
      STKeyBits localSTKeyBits = null;
      localSTKeyBits = (STKeyBits)get_store().find_attribute_user(KEYBITS$4);
      if (localSTKeyBits == null) {
        localSTKeyBits = (STKeyBits)get_store().add_attribute_user(KEYBITS$4);
      }
      localSTKeyBits.set(paramSTKeyBits);
    }
  }
  
  public int getHashSize()
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(HASHSIZE$6);
      if (localSimpleValue == null) {
        return 0;
      }
      return localSimpleValue.getIntValue();
    }
  }
  
  public STHashSize xgetHashSize()
  {
    synchronized (monitor())
    {
      check_orphaned();
      STHashSize localSTHashSize = null;
      localSTHashSize = (STHashSize)get_store().find_attribute_user(HASHSIZE$6);
      return localSTHashSize;
    }
  }
  
  public void setHashSize(int paramInt)
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(HASHSIZE$6);
      if (localSimpleValue == null) {
        localSimpleValue = (SimpleValue)get_store().add_attribute_user(HASHSIZE$6);
      }
      localSimpleValue.setIntValue(paramInt);
    }
  }
  
  public void xsetHashSize(STHashSize paramSTHashSize)
  {
    synchronized (monitor())
    {
      check_orphaned();
      STHashSize localSTHashSize = null;
      localSTHashSize = (STHashSize)get_store().find_attribute_user(HASHSIZE$6);
      if (localSTHashSize == null) {
        localSTHashSize = (STHashSize)get_store().add_attribute_user(HASHSIZE$6);
      }
      localSTHashSize.set(paramSTHashSize);
    }
  }
  
  public STCipherAlgorithm.Enum getCipherAlgorithm()
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(CIPHERALGORITHM$8);
      if (localSimpleValue == null) {
        return null;
      }
      return (STCipherAlgorithm.Enum)localSimpleValue.getEnumValue();
    }
  }
  
  public STCipherAlgorithm xgetCipherAlgorithm()
  {
    synchronized (monitor())
    {
      check_orphaned();
      STCipherAlgorithm localSTCipherAlgorithm = null;
      localSTCipherAlgorithm = (STCipherAlgorithm)get_store().find_attribute_user(CIPHERALGORITHM$8);
      return localSTCipherAlgorithm;
    }
  }
  
  public void setCipherAlgorithm(STCipherAlgorithm.Enum paramEnum)
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(CIPHERALGORITHM$8);
      if (localSimpleValue == null) {
        localSimpleValue = (SimpleValue)get_store().add_attribute_user(CIPHERALGORITHM$8);
      }
      localSimpleValue.setEnumValue(paramEnum);
    }
  }
  
  public void xsetCipherAlgorithm(STCipherAlgorithm paramSTCipherAlgorithm)
  {
    synchronized (monitor())
    {
      check_orphaned();
      STCipherAlgorithm localSTCipherAlgorithm = null;
      localSTCipherAlgorithm = (STCipherAlgorithm)get_store().find_attribute_user(CIPHERALGORITHM$8);
      if (localSTCipherAlgorithm == null) {
        localSTCipherAlgorithm = (STCipherAlgorithm)get_store().add_attribute_user(CIPHERALGORITHM$8);
      }
      localSTCipherAlgorithm.set(paramSTCipherAlgorithm);
    }
  }
  
  public STCipherChaining.Enum getCipherChaining()
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(CIPHERCHAINING$10);
      if (localSimpleValue == null) {
        return null;
      }
      return (STCipherChaining.Enum)localSimpleValue.getEnumValue();
    }
  }
  
  public STCipherChaining xgetCipherChaining()
  {
    synchronized (monitor())
    {
      check_orphaned();
      STCipherChaining localSTCipherChaining = null;
      localSTCipherChaining = (STCipherChaining)get_store().find_attribute_user(CIPHERCHAINING$10);
      return localSTCipherChaining;
    }
  }
  
  public void setCipherChaining(STCipherChaining.Enum paramEnum)
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(CIPHERCHAINING$10);
      if (localSimpleValue == null) {
        localSimpleValue = (SimpleValue)get_store().add_attribute_user(CIPHERCHAINING$10);
      }
      localSimpleValue.setEnumValue(paramEnum);
    }
  }
  
  public void xsetCipherChaining(STCipherChaining paramSTCipherChaining)
  {
    synchronized (monitor())
    {
      check_orphaned();
      STCipherChaining localSTCipherChaining = null;
      localSTCipherChaining = (STCipherChaining)get_store().find_attribute_user(CIPHERCHAINING$10);
      if (localSTCipherChaining == null) {
        localSTCipherChaining = (STCipherChaining)get_store().add_attribute_user(CIPHERCHAINING$10);
      }
      localSTCipherChaining.set(paramSTCipherChaining);
    }
  }
  
  public STHashAlgorithm.Enum getHashAlgorithm()
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(HASHALGORITHM$12);
      if (localSimpleValue == null) {
        return null;
      }
      return (STHashAlgorithm.Enum)localSimpleValue.getEnumValue();
    }
  }
  
  public STHashAlgorithm xgetHashAlgorithm()
  {
    synchronized (monitor())
    {
      check_orphaned();
      STHashAlgorithm localSTHashAlgorithm = null;
      localSTHashAlgorithm = (STHashAlgorithm)get_store().find_attribute_user(HASHALGORITHM$12);
      return localSTHashAlgorithm;
    }
  }
  
  public void setHashAlgorithm(STHashAlgorithm.Enum paramEnum)
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(HASHALGORITHM$12);
      if (localSimpleValue == null) {
        localSimpleValue = (SimpleValue)get_store().add_attribute_user(HASHALGORITHM$12);
      }
      localSimpleValue.setEnumValue(paramEnum);
    }
  }
  
  public void xsetHashAlgorithm(STHashAlgorithm paramSTHashAlgorithm)
  {
    synchronized (monitor())
    {
      check_orphaned();
      STHashAlgorithm localSTHashAlgorithm = null;
      localSTHashAlgorithm = (STHashAlgorithm)get_store().find_attribute_user(HASHALGORITHM$12);
      if (localSTHashAlgorithm == null) {
        localSTHashAlgorithm = (STHashAlgorithm)get_store().add_attribute_user(HASHALGORITHM$12);
      }
      localSTHashAlgorithm.set(paramSTHashAlgorithm);
    }
  }
  
  public byte[] getSaltValue()
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(SALTVALUE$14);
      if (localSimpleValue == null) {
        return null;
      }
      return localSimpleValue.getByteArrayValue();
    }
  }
  
  public XmlBase64Binary xgetSaltValue()
  {
    synchronized (monitor())
    {
      check_orphaned();
      XmlBase64Binary localXmlBase64Binary = null;
      localXmlBase64Binary = (XmlBase64Binary)get_store().find_attribute_user(SALTVALUE$14);
      return localXmlBase64Binary;
    }
  }
  
  public void setSaltValue(byte[] paramArrayOfByte)
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(SALTVALUE$14);
      if (localSimpleValue == null) {
        localSimpleValue = (SimpleValue)get_store().add_attribute_user(SALTVALUE$14);
      }
      localSimpleValue.setByteArrayValue(paramArrayOfByte);
    }
  }
  
  public void xsetSaltValue(XmlBase64Binary paramXmlBase64Binary)
  {
    synchronized (monitor())
    {
      check_orphaned();
      XmlBase64Binary localXmlBase64Binary = null;
      localXmlBase64Binary = (XmlBase64Binary)get_store().find_attribute_user(SALTVALUE$14);
      if (localXmlBase64Binary == null) {
        localXmlBase64Binary = (XmlBase64Binary)get_store().add_attribute_user(SALTVALUE$14);
      }
      localXmlBase64Binary.set(paramXmlBase64Binary);
    }
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/encryption/impl/CTKeyDataImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */