package com.microsoft.schemas.office.x2006.encryption.impl;

import com.microsoft.schemas.office.x2006.encryption.CTDataIntegrity;
import com.microsoft.schemas.office.x2006.encryption.CTEncryption;
import com.microsoft.schemas.office.x2006.encryption.CTKeyData;
import com.microsoft.schemas.office.x2006.encryption.CTKeyEncryptors;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.TypeStore;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;

public class CTEncryptionImpl
  extends XmlComplexContentImpl
  implements CTEncryption
{
  private static final QName KEYDATA$0 = new QName("http://schemas.microsoft.com/office/2006/encryption", "keyData");
  private static final QName DATAINTEGRITY$2 = new QName("http://schemas.microsoft.com/office/2006/encryption", "dataIntegrity");
  private static final QName KEYENCRYPTORS$4 = new QName("http://schemas.microsoft.com/office/2006/encryption", "keyEncryptors");
  
  public CTEncryptionImpl(SchemaType paramSchemaType)
  {
    super(paramSchemaType);
  }
  
  public CTKeyData getKeyData()
  {
    synchronized (monitor())
    {
      check_orphaned();
      CTKeyData localCTKeyData = null;
      localCTKeyData = (CTKeyData)get_store().find_element_user(KEYDATA$0, 0);
      if (localCTKeyData == null) {
        return null;
      }
      return localCTKeyData;
    }
  }
  
  public void setKeyData(CTKeyData paramCTKeyData)
  {
    synchronized (monitor())
    {
      check_orphaned();
      CTKeyData localCTKeyData = null;
      localCTKeyData = (CTKeyData)get_store().find_element_user(KEYDATA$0, 0);
      if (localCTKeyData == null) {
        localCTKeyData = (CTKeyData)get_store().add_element_user(KEYDATA$0);
      }
      localCTKeyData.set(paramCTKeyData);
    }
  }
  
  public CTKeyData addNewKeyData()
  {
    synchronized (monitor())
    {
      check_orphaned();
      CTKeyData localCTKeyData = null;
      localCTKeyData = (CTKeyData)get_store().add_element_user(KEYDATA$0);
      return localCTKeyData;
    }
  }
  
  public CTDataIntegrity getDataIntegrity()
  {
    synchronized (monitor())
    {
      check_orphaned();
      CTDataIntegrity localCTDataIntegrity = null;
      localCTDataIntegrity = (CTDataIntegrity)get_store().find_element_user(DATAINTEGRITY$2, 0);
      if (localCTDataIntegrity == null) {
        return null;
      }
      return localCTDataIntegrity;
    }
  }
  
  public void setDataIntegrity(CTDataIntegrity paramCTDataIntegrity)
  {
    synchronized (monitor())
    {
      check_orphaned();
      CTDataIntegrity localCTDataIntegrity = null;
      localCTDataIntegrity = (CTDataIntegrity)get_store().find_element_user(DATAINTEGRITY$2, 0);
      if (localCTDataIntegrity == null) {
        localCTDataIntegrity = (CTDataIntegrity)get_store().add_element_user(DATAINTEGRITY$2);
      }
      localCTDataIntegrity.set(paramCTDataIntegrity);
    }
  }
  
  public CTDataIntegrity addNewDataIntegrity()
  {
    synchronized (monitor())
    {
      check_orphaned();
      CTDataIntegrity localCTDataIntegrity = null;
      localCTDataIntegrity = (CTDataIntegrity)get_store().add_element_user(DATAINTEGRITY$2);
      return localCTDataIntegrity;
    }
  }
  
  public CTKeyEncryptors getKeyEncryptors()
  {
    synchronized (monitor())
    {
      check_orphaned();
      CTKeyEncryptors localCTKeyEncryptors = null;
      localCTKeyEncryptors = (CTKeyEncryptors)get_store().find_element_user(KEYENCRYPTORS$4, 0);
      if (localCTKeyEncryptors == null) {
        return null;
      }
      return localCTKeyEncryptors;
    }
  }
  
  public void setKeyEncryptors(CTKeyEncryptors paramCTKeyEncryptors)
  {
    synchronized (monitor())
    {
      check_orphaned();
      CTKeyEncryptors localCTKeyEncryptors = null;
      localCTKeyEncryptors = (CTKeyEncryptors)get_store().find_element_user(KEYENCRYPTORS$4, 0);
      if (localCTKeyEncryptors == null) {
        localCTKeyEncryptors = (CTKeyEncryptors)get_store().add_element_user(KEYENCRYPTORS$4);
      }
      localCTKeyEncryptors.set(paramCTKeyEncryptors);
    }
  }
  
  public CTKeyEncryptors addNewKeyEncryptors()
  {
    synchronized (monitor())
    {
      check_orphaned();
      CTKeyEncryptors localCTKeyEncryptors = null;
      localCTKeyEncryptors = (CTKeyEncryptors)get_store().add_element_user(KEYENCRYPTORS$4);
      return localCTKeyEncryptors;
    }
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/encryption/impl/CTEncryptionImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */