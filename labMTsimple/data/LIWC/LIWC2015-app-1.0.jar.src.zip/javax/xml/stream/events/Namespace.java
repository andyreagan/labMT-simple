package javax.xml.stream.events;

public abstract interface Namespace
  extends Attribute
{
  public abstract String getPrefix();
  
  public abstract String getNamespaceURI();
  
  public abstract boolean isDefaultNamespaceDeclaration();
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/javax/xml/stream/events/Namespace.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */