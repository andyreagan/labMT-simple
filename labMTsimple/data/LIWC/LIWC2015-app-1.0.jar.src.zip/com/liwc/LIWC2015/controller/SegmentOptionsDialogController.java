/*     */ package com.liwc.LIWC2015.controller;
/*     */ 
/*     */ import javafx.scene.control.ChoiceBox;
/*     */ 
/*     */ public class SegmentOptionsDialogController extends ModalDialogController implements javafx.fxml.Initializable {
/*     */   @javafx.fxml.FXML
/*     */   private javafx.scene.layout.VBox vBox;
/*     */   private javafx.scene.control.ToggleGroup optionsToggleGroup;
/*     */   @javafx.fxml.FXML
/*     */   private javafx.scene.control.RadioButton doNotSegmentBtn;
/*     */   @javafx.fxml.FXML
/*     */   private javafx.scene.control.RadioButton byNumOfSegmentsBtn;
/*     */   @javafx.fxml.FXML
/*     */   private javafx.scene.control.RadioButton byWordsPerSegmentBtn;
/*     */   @javafx.fxml.FXML
/*     */   private javafx.scene.control.RadioButton bySpecialCharacterBtn;
/*     */   @javafx.fxml.FXML
/*     */   private javafx.scene.control.RadioButton byNumOfCRsBtn;
/*     */   @javafx.fxml.FXML
/*     */   private javafx.scene.control.TextField byNumOfSegmentsText;
/*     */   @javafx.fxml.FXML
/*     */   private javafx.scene.control.TextField byWordsPerSegmentText;
/*     */   @javafx.fxml.FXML
/*     */   private javafx.scene.control.TextField bySpecialCharacterText;
/*     */   @javafx.fxml.FXML
/*     */   private ChoiceBox<String> bySpecialCharacterChoice;
/*     */   @javafx.fxml.FXML
/*     */   private ChoiceBox<Integer> byNumOfCRsChoice;
/*     */   
/*  30 */   public SegmentOptionsDialogController() { this.optionsToggleGroup = new javafx.scene.control.ToggleGroup(); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void initialize(java.net.URL location, java.util.ResourceBundle resources)
/*     */   {
/*  64 */     this.doNotSegmentBtn.setToggleGroup(this.optionsToggleGroup);
/*  65 */     this.byNumOfSegmentsBtn.setToggleGroup(this.optionsToggleGroup);
/*  66 */     this.byWordsPerSegmentBtn.setToggleGroup(this.optionsToggleGroup);
/*  67 */     this.bySpecialCharacterBtn.setToggleGroup(this.optionsToggleGroup);
/*  68 */     this.byNumOfCRsBtn.setToggleGroup(this.optionsToggleGroup);
/*     */     
/*  70 */     NumericTextFieldValidator validator = new NumericTextFieldValidator(null);
/*  71 */     this.byNumOfSegmentsText.visibleProperty().bind(this.byNumOfSegmentsBtn.selectedProperty());
/*  72 */     this.byNumOfSegmentsText.textProperty().addListener(validator);
/*  73 */     this.byWordsPerSegmentText.visibleProperty().bind(this.byWordsPerSegmentBtn.selectedProperty());
/*  74 */     this.byWordsPerSegmentText.textProperty().addListener(validator);
/*  75 */     this.bySpecialCharacterChoice.visibleProperty().bind(this.bySpecialCharacterBtn.selectedProperty());
/*  76 */     this.bySpecialCharacterChoice.getItems().addAll(new String[] { "¶", ".", ":", ";", "Custom" });
/*  77 */     this.bySpecialCharacterText.visibleProperty().bind(this.bySpecialCharacterBtn.selectedProperty());
/*  78 */     this.bySpecialCharacterText.disableProperty().bind(this.bySpecialCharacterChoice.getSelectionModel().selectedIndexProperty().isNotEqualTo(this.bySpecialCharacterChoice.getItems().size() - 1));
/*  79 */     this.byNumOfCRsChoice.visibleProperty().bind(this.byNumOfCRsBtn.selectedProperty());
/*  80 */     this.byNumOfCRsChoice.getItems().addAll(new Integer[] { Integer.valueOf(1), Integer.valueOf(2), Integer.valueOf(3) });
/*     */   }
/*     */   
/*     */   public void onCancel() {
/*  84 */     this.stage.close();
/*     */   }
/*     */   
/*     */   public void onOK() {
/*  88 */     com.liwc.LIWC2015.LiwcPreferences prefs = this.app.getLiwcPreferences();
/*  89 */     prefs.getSegmentOptions().setType(this.optionsToggleGroup.getToggles().indexOf(this.optionsToggleGroup.getSelectedToggle()));
/*  90 */     String text = this.byNumOfSegmentsText.getText();
/*  91 */     prefs.getSegmentOptions().setNumberOfSegments(Integer.valueOf(text.isEmpty() ? 1 : Integer.parseInt(text)));
/*  92 */     text = this.byWordsPerSegmentText.getText();
/*  93 */     prefs.getSegmentOptions().setWordsPerSegment(Integer.valueOf(text.isEmpty() ? 1 : Integer.parseInt(text)));
/*     */     
/*  95 */     if ((this.bySpecialCharacterChoice.getSelectionModel().getSelectedIndex() == this.bySpecialCharacterChoice.getItems().size() - 1) && 
/*  96 */       (this.bySpecialCharacterText.getText().length() > 0)) {
/*  97 */       prefs.getSegmentOptions().setSpecialCharacters("custom." + this.bySpecialCharacterText.getText());
/*     */     }
/*  99 */     else if (this.bySpecialCharacterChoice.getSelectionModel().getSelectedIndex() == this.bySpecialCharacterChoice.getItems().size() - 1) {
/* 100 */       prefs.getSegmentOptions().setSpecialCharacters((String)this.bySpecialCharacterChoice.getItems().get(0));
/*     */     } else {
/* 102 */       prefs.getSegmentOptions().setSpecialCharacters((String)this.bySpecialCharacterChoice.getSelectionModel().getSelectedItem());
/*     */     }
/* 104 */     prefs.getSegmentOptions().setNumberOfCarriageReturns((Integer)this.byNumOfCRsChoice.getValue());
/* 105 */     this.app.getWelcomeScreenModel().setSegmentOptions(WelcomeScreenController.buildSegmentOptionsString(prefs.getSegmentOptions()));
/* 106 */     this.stage.close();
/*     */   }
/*     */   
/*     */   private static class NumericTextFieldValidator implements javafx.beans.value.ChangeListener<String>
/*     */   {
/*     */     public void changed(javafx.beans.value.ObservableValue<? extends String> observable, String oldValue, String newValue) {
/* 112 */       if (!newValue.isEmpty()) {
/*     */         try {
/* 114 */           Integer.parseInt(newValue);
/*     */         } catch (NumberFormatException e) {
/* 116 */           ((javafx.beans.property.StringProperty)observable).setValue(oldValue);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public javafx.stage.Stage initStage(com.liwc.LIWC2015.App app, Object... args) throws Exception
/*     */   {
/* 124 */     javafx.scene.Scene newScene = new javafx.scene.Scene(this.vBox);
/* 125 */     javafx.stage.Stage stage = new javafx.stage.Stage();
/* 126 */     stage.setScene(newScene);
/* 127 */     stage.setResizable(false);
/* 128 */     stage.initModality(javafx.stage.Modality.APPLICATION_MODAL);
/* 129 */     if (!com.liwc.LIWC2015.Utils.isMac())
/* 130 */       stage.initStyle(javafx.stage.StageStyle.UTILITY);
/* 131 */     stage.initOwner(null);
/* 132 */     stage.setTitle("Segments");
/*     */     
/* 134 */     com.liwc.LIWC2015.LiwcPreferences prefs = app.getLiwcPreferences();
/* 135 */     this.optionsToggleGroup.selectToggle((javafx.scene.control.Toggle)this.optionsToggleGroup.getToggles().get(prefs.getSegmentOptions().getType()));
/* 136 */     this.byNumOfSegmentsText.setText(prefs.getSegmentOptions().getNumberOfSegments().toString());
/* 137 */     this.byWordsPerSegmentText.setText(prefs.getSegmentOptions().getWordsPerSegment().toString());
/*     */     
/* 139 */     if (prefs.getSegmentOptions().getSpecialCharacters().startsWith("custom.")) {
/* 140 */       String customText = prefs.getSegmentOptions().getSpecialCharacters().replace("custom.", "");
/* 141 */       this.bySpecialCharacterText.setText(customText);
/* 142 */       this.bySpecialCharacterChoice.getSelectionModel().select(this.bySpecialCharacterChoice.getItems().size() - 1);
/*     */     }
/* 144 */     else if (this.bySpecialCharacterChoice.getItems().contains(prefs.getSegmentOptions().getSpecialCharacters())) {
/* 145 */       this.bySpecialCharacterChoice.getSelectionModel().select(prefs.getSegmentOptions().getSpecialCharacters());
/*     */     } else {
/* 147 */       this.bySpecialCharacterChoice.getSelectionModel().select(0);
/*     */     }
/*     */     
/* 150 */     this.byNumOfCRsChoice.setValue(prefs.getSegmentOptions().getNumberOfCarriageReturns());
/*     */     
/* 152 */     return stage;
/*     */   }
/*     */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/SegmentOptionsDialogController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */