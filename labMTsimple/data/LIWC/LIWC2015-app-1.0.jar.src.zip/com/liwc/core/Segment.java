package com.liwc.core;

import com.liwc.core.dictionary.IDictionary;
import com.liwc.core.math.Math;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Segment
{
  private transient IDictionary a;
  private int[] b;
  private int[] c;
  private HashMap d = new HashMap();
  private int e = 0;
  private int f = 0;
  private int g = 0;
  private int h = 0;
  private int i = 0;
  private int j = 0;
  
  public Segment(IDictionary paramIDictionary)
  {
    this.a = paramIDictionary;
  }
  
  public Segment(Segment paramSegment)
  {
    this.a = paramSegment.a;
    this.d = ((HashMap)paramSegment.getCategories().clone());
    this.e = paramSegment.getWordsCount();
    this.f = paramSegment.getDictionaryWordsCount();
    this.g = paramSegment.getWordsLongerThan6LettersCount();
    this.h = paramSegment.getSentencesCount();
    this.i = paramSegment.getNumbersCount();
    this.j = paramSegment.getPunctuationMarksCount();
  }
  
  public HashMap getCategories()
  {
    return this.d;
  }
  
  public int getWordsCount()
  {
    return this.e;
  }
  
  public void incWordsCount()
  {
    this.e += 1;
  }
  
  public int getDictionaryWordsCount()
  {
    return this.f;
  }
  
  public void incDictionaryWordsCount()
  {
    this.f += 1;
  }
  
  public int getWordsLongerThan6LettersCount()
  {
    return this.g;
  }
  
  public void incWordsLongerThan6LettersCount()
  {
    this.g += 1;
  }
  
  public int getSentencesCount()
  {
    return this.h;
  }
  
  public void incSentencesCount()
  {
    this.h += 1;
  }
  
  public float getWordsPerSentence()
  {
    if (this.h == 0) {
      return 0.0F;
    }
    return this.e / this.h;
  }
  
  public int getNumbersCount()
  {
    return this.i;
  }
  
  public void incNumbersCount()
  {
    this.i += 1;
    this.e += 1;
  }
  
  public int getPunctuationMarksCount()
  {
    return this.j;
  }
  
  public void incPunctuationMarksCount()
  {
    this.j += 1;
  }
  
  public float getAnalytic()
  {
    Segment localSegment = this;
    float f1;
    return Math.getPercentileFromZScore(f1 = ((f1 = 30.0F + (localSegment.a("article") + localSegment.a("prep") - localSegment.a("pronoun") - localSegment.a("auxverb") - localSegment.a("negate") - localSegment.a("conj") - localSegment.a("adverb")) / localSegment.getWordsCount() * 100.0F) - 9.5F) / 14.0F);
  }
  
  public float getClout()
  {
    Segment localSegment = this;
    float f1;
    return Math.getPercentileFromZScore(f1 = ((f1 = 10.0F + (localSegment.a("we") + localSegment.a("you") + localSegment.a("social") - localSegment.a("i") - localSegment.a("swear") - localSegment.a("negate") - localSegment.a("differ")) / localSegment.getWordsCount() * 100.0F) - 10.0F) / 10.0F);
  }
  
  public float getAuthentic()
  {
    Segment localSegment = this;
    float f1;
    return Math.getPercentileFromZScore(f1 = ((f1 = (a("i") + localSegment.a("insight") + localSegment.a("differ") + localSegment.a("relativ") - localSegment.a("discrep") - localSegment.a("shehe")) / localSegment.getWordsCount() * 100.0F) - 21.0F) / 6.0F);
  }
  
  public float getTone()
  {
    Segment localSegment = this;
    float f1;
    return Math.getPercentileFromZScore(f1 = ((f1 = (a("posemo") - localSegment.a("negemo")) / localSegment.getWordsCount() * 100.0F) - 1.3F) / 2.0F);
  }
  
  public Segment merge(Segment paramSegment)
  {
    return mergeImpl(paramSegment);
  }
  
  public int getCategoryValue(int paramInt)
  {
    if (this.d == null)
    {
      for (int k = 0; k < this.b.length; k++) {
        if (this.b[k] == paramInt) {
          return this.c[k];
        }
      }
      return 0;
    }
    return ((Integer)this.d.getOrDefault(Integer.valueOf(paramInt), Integer.valueOf(0))).intValue();
  }
  
  public void optimize()
  {
    this.b = new int[this.d.size()];
    this.c = new int[this.d.size()];
    int k = 0;
    Iterator localIterator = this.d.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      this.b[k] = ((Integer)localEntry.getKey()).intValue();
      this.c[k] = ((Integer)localEntry.getValue()).intValue();
      k++;
    }
    this.d.clear();
    this.d = null;
  }
  
  private float a(String paramString)
  {
    Iterator localIterator = this.a.getCategoriesPlain().entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry;
      if (((localEntry = (Map.Entry)localIterator.next()).getValue() != null) && (((String)localEntry.getValue()).toLowerCase().equals(paramString.toLowerCase()))) {
        return getCategoryValue(((Integer)localEntry.getKey()).intValue());
      }
    }
    return 0.0F;
  }
  
  public Segment mergeImpl(Segment paramSegment)
  {
    Segment localSegment = new Segment(this);
    Iterator localIterator = paramSegment.d.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      Integer localInteger;
      if ((localInteger = (Integer)localSegment.d.get(localEntry.getKey())) == null) {
        localSegment.d.put(localEntry.getKey(), localEntry.getValue());
      } else {
        localSegment.d.put(localEntry.getKey(), Integer.valueOf(((Integer)localEntry.getValue()).intValue() + localInteger.intValue()));
      }
    }
    localSegment.e += paramSegment.e;
    localSegment.f += paramSegment.f;
    localSegment.g += paramSegment.g;
    localSegment.h += paramSegment.h;
    localSegment.i += paramSegment.i;
    localSegment.j += paramSegment.j;
    return localSegment;
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/core/Segment.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */