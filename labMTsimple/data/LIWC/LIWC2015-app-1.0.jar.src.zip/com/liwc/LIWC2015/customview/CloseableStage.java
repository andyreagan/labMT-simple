package com.liwc.LIWC2015.customview;

import javafx.stage.Stage;

public class CloseableStage
  extends Stage
  implements ICloseable
{}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/customview/CloseableStage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */