package com.liwc.core.text;

import java.io.InputStream;
import java.nio.charset.Charset;
import org.apache.commons.io.ByteOrderMark;

public class TxtFile
  extends RawText
{
  public TxtFile(InputStream paramInputStream)
  {
    this(paramInputStream, Charset.defaultCharset());
  }
  
  public TxtFile(InputStream paramInputStream, Charset paramCharset)
  {
    super(paramCharset);
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/core/text/TxtFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */