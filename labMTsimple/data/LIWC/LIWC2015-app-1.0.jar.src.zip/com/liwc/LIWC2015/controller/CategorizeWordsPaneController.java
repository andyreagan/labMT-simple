/*     */ package com.liwc.LIWC2015.controller;
/*     */ 
/*     */ import com.liwc.LIWC2015.App;
/*     */ import com.liwc.LIWC2015.LiwcPreferences;
/*     */ import com.liwc.LIWC2015.LiwcPreferences.Categories;
/*     */ import com.liwc.LIWC2015.customview.ResultPane;
/*     */ import com.liwc.LIWC2015.model.WordCategories;
/*     */ import com.liwc.core.dictionary.IDictionary;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javafx.beans.property.SimpleBooleanProperty;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.scene.control.TableCell;
/*     */ import javafx.scene.control.TableColumn;
/*     */ import javafx.scene.control.TableColumn.CellDataFeatures;
/*     */ import javafx.scene.control.TableView;
/*     */ import javafx.util.Callback;
/*     */ 
/*     */ public class CategorizeWordsPaneController extends SaveablePaneController
/*     */ {
/*     */   public static final String word = "word";
/*     */   private ObservableList<WordCategories> data;
/*     */   
/*     */   public CategorizeWordsPaneController(App app)
/*     */   {
/*  30 */     super(app);
/*     */   }
/*     */   
/*     */   public void close()
/*     */   {
/*  35 */     this.resultPane = null;
/*  36 */     this.data.clear();
/*  37 */     this.data = null;
/*     */   }
/*     */   
/*     */   public void build(ObservableList<WordCategories> data, File file) {
/*  41 */     this.data = data;
/*  42 */     this.resultPane = this.app.newResultPane(this, com.liwc.LIWC2015.Utils.getFilenameWithoutExtension(file));
/*  43 */     TableView tableView = this.resultPane.getTableView();
/*  44 */     tableView.getSelectionModel().setSelectionMode(javafx.scene.control.SelectionMode.MULTIPLE);
/*  45 */     tableView.setEditable(false);
/*  46 */     List<TableColumn> columns = new ArrayList();
/*  47 */     TableColumn column = new TableColumn("Word");
/*  48 */     column.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory("word"));
/*  49 */     columns.add(column);
/*     */     
/*  51 */     for (Map.Entry<Integer, String> entry : this.app.getActiveDictionary().getCategoriesPlain().entrySet()) {
/*  52 */       if ((((Integer)entry.getKey()).intValue() >= 0) && (this.app.getLiwcPreferences().getCategories().showParam((String)entry.getValue()))) {
/*  53 */         columns.add(newCategoryColumn((String)entry.getValue(), ((Integer)entry.getKey()).intValue()));
/*     */       }
/*     */     }
/*  56 */     column = new TableColumn();
/*  57 */     column.setPrefWidth(columns.size());
/*  58 */     columns.add(column);
/*     */     
/*  60 */     tableView.getColumns().addAll(columns);
/*  61 */     tableView.setItems(data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean showValue(String paramName)
/*     */   {
/*  70 */     return true;
/*     */   }
/*     */   
/*     */   private static TableColumn newCategoryColumn(String name, int categoryIndex) {
/*  74 */     TableColumn<WordCategories, Boolean> tableColumn = new TableColumn(name);
/*  75 */     tableColumn.setStyle("-fx-alignment: CENTER;");
/*  76 */     tableColumn.setCellValueFactory(new Callback()
/*     */     {
/*     */       public ObservableValue<Boolean> call(TableColumn.CellDataFeatures<WordCategories, Boolean> param) {
/*  79 */         return new SimpleBooleanProperty(((WordCategories)param.getValue()).hasCategory(this.val$categoryIndex));
/*     */       }
/*  81 */     });
/*  82 */     tableColumn.setCellFactory(new Callback()
/*     */     {
/*     */       public TableCell<WordCategories, Boolean> call(TableColumn<WordCategories, Boolean> param) {
/*  85 */         new TableCell()
/*     */         {
/*     */           protected void updateItem(Boolean item, boolean empty) {
/*  88 */             super.updateItem(item, empty);
/*  89 */             if ((item == null) || (empty) || (!item.booleanValue())) {
/*  90 */               setText("");
/*     */             } else {
/*  92 */               setText("X");
/*     */             }
/*     */           }
/*     */         };
/*     */       }
/*  97 */     });
/*  98 */     return tableColumn;
/*     */   }
/*     */   
/*     */   protected CancelableTask getSaveTask(File fileToSave)
/*     */   {
/* 103 */     return new SaveTask(this, fileToSave, null);
/*     */   }
/*     */   
/*     */   private static class SaveTask extends CancelableTask<Void>
/*     */   {
/*     */     private File file;
/*     */     private CategorizeWordsPaneController controller;
/*     */     
/*     */     private SaveTask(CategorizeWordsPaneController controller, File file) {
/* 112 */       this.controller = controller;
/* 113 */       this.file = file;
/*     */     }
/*     */     
/*     */     protected Void call() throws Exception
/*     */     {
/* 118 */       updateMessage("Saving results...");
/* 119 */       updateProgress(0L, this.controller.data.size());
/* 120 */       App app = this.controller.app;
/* 121 */       TableView tableView = this.controller.resultPane.getTableView();
/* 122 */       ObservableList<WordCategories> data = this.controller.data;
/* 123 */       FileSaver fileSaver = FileSaver.getFileSaver(this.file, app.getLiwcPreferences());
/* 124 */       int nrOfCols = tableView.getColumns().size();
/* 125 */       for (int i = 0; i < nrOfCols; i++) {
/* 126 */         TableColumn column = (TableColumn)tableView.getColumns().get(i);
/* 127 */         fileSaver.saveValue(column.getText(), i == nrOfCols - 1, data.size() == 0);
/*     */       }
/* 129 */       for (int i = 0; i < data.size(); i++) {
/* 130 */         WordCategories cats = (WordCategories)data.get(i);
/* 131 */         boolean lastInTable = i == data.size() - 1;
/* 132 */         List<Object> rowData = new ArrayList();
/* 133 */         rowData.add(cats.getWord());
/* 134 */         for (Map.Entry<Integer, String> entry : app.getActiveDictionary().getCategoriesPlain().entrySet()) {
/* 135 */           if ((((Integer)entry.getKey()).intValue() >= 0) && (app.getLiwcPreferences().getCategories().showParam((String)entry.getValue())))
/* 136 */             rowData.add(cats.hasCategory(((Integer)entry.getKey()).intValue()) ? "X" : "");
/*     */         }
/* 138 */         for (int j = 0; j < rowData.size(); j++) {
/* 139 */           fileSaver.saveValue(rowData.get(j), j == rowData.size() - 1, lastInTable);
/*     */         }
/* 141 */         updateProgress(i + 1, this.controller.data.size());
/*     */       }
/* 143 */       fileSaver.close();
/* 144 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/CategorizeWordsPaneController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */