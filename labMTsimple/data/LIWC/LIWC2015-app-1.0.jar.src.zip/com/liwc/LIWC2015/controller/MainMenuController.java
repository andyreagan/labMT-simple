/*     */ package com.liwc.LIWC2015.controller;
/*     */ 
/*     */ import com.liwc.LIWC2015.App;
/*     */ import com.liwc.LIWC2015.LiwcPreferences;
/*     */ import com.liwc.LIWC2015.LiwcPreferences.Categories;
/*     */ import com.liwc.LIWC2015.LiwcPreferences.ExternalDictionaries;
/*     */ import com.liwc.LIWC2015.Utils;
/*     */ import com.liwc.LIWC2015.customview.DirectoryChooserWrapper;
/*     */ import com.liwc.LIWC2015.customview.FileChooserWrapper;
/*     */ import com.liwc.LIWC2015.customview.LIWCAlert;
/*     */ import com.liwc.LIWC2015.customview.ResultPane;
/*     */ import com.liwc.LIWC2015.model.Dictionaries;
/*     */ import com.liwc.LIWC2015.model.Dictionary;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.ResourceBundle;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.SimpleBooleanProperty;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.event.ActionEvent;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.fxml.FXML;
/*     */ import javafx.scene.control.Alert.AlertType;
/*     */ import javafx.scene.control.Label;
/*     */ import javafx.scene.control.Menu;
/*     */ import javafx.scene.control.MenuBar;
/*     */ import javafx.scene.control.MenuItem;
/*     */ import javafx.scene.control.RadioMenuItem;
/*     */ import javafx.scene.control.SeparatorMenuItem;
/*     */ import javafx.scene.layout.VBox;
/*     */ import javafx.stage.FileChooser;
/*     */ import org.slf4j.Logger;
/*     */ 
/*     */ public class MainMenuController implements javafx.fxml.Initializable
/*     */ {
/*  40 */   private static Logger logger = org.slf4j.LoggerFactory.getLogger(MainMenuController.class);
/*     */   @FXML
/*     */   private MenuBar menuBar;
/*     */   @FXML
/*     */   private Menu menuDictionaries;
/*     */   @FXML
/*     */   private MenuItem loadNewDictionaryItem;
/*     */   @FXML
/*     */   private MenuItem menuItemFileSave;
/*     */   @FXML
/*     */   private MenuItem menuItemFileClose;
/*     */   @FXML
/*  52 */   private SeparatorMenuItem intExtSeparator = new SeparatorMenuItem();
/*     */   
/*     */   private App app;
/*     */   
/*  56 */   private javafx.scene.control.ToggleGroup dictionariesToggleGroup = new javafx.scene.control.ToggleGroup();
/*  57 */   private RadioMenuItem currentDictionaryItem = null;
/*  58 */   private BooleanProperty saveDisabled = new SimpleBooleanProperty(true);
/*  59 */   private BooleanProperty closeDisabled = new SimpleBooleanProperty(true);
/*  60 */   private BooleanProperty disableMenu = new SimpleBooleanProperty(false);
/*     */   
/*     */   public static MenuItem getMenuItem(Menu menu, String id) {
/*  63 */     ObservableList<MenuItem> items = menu.getItems();
/*  64 */     for (MenuItem item : items)
/*  65 */       if (id.equals(item.getId()))
/*  66 */         return item;
/*  67 */     return null;
/*     */   }
/*     */   
/*     */   public static Menu getMenu(MenuBar menuBar, String id) {
/*  71 */     ObservableList<Menu> menus = menuBar.getMenus();
/*  72 */     for (Menu menu : menus)
/*  73 */       if (id.equals(menu.getId()))
/*  74 */         return menu;
/*  75 */     return null;
/*     */   }
/*     */   
/*     */   public void initialize(java.net.URL location, ResourceBundle resources)
/*     */   {
/*  80 */     this.menuItemFileSave.disableProperty().bind(this.saveDisabled.or(this.disableMenu));
/*  81 */     this.menuItemFileClose.disableProperty().bind(this.closeDisabled.or(this.disableMenu));
/*  82 */     for (Menu menu : this.menuBar.getMenus()) {
/*  83 */       for (MenuItem menuItem : menu.getItems()) {
/*  84 */         if ((menuItem != this.menuItemFileClose) && (menuItem != this.menuItemFileSave))
/*  85 */           menuItem.disableProperty().bind(this.disableMenu);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void setApp(App app) {
/*  91 */     this.app = app;
/*     */   }
/*     */   
/*     */   public void updateMenu(boolean disableMenu) {
/*  95 */     this.disableMenu.setValue(Boolean.valueOf(disableMenu));
/*  96 */     ResultPane pane = this.app.getActiveResultPane();
/*  97 */     if (pane == null) {
/*  98 */       this.saveDisabled.setValue(Boolean.valueOf(true));
/*  99 */       this.closeDisabled.setValue(Boolean.valueOf(true));
/*     */     } else {
/* 101 */       this.saveDisabled.setValue(Boolean.valueOf(!(pane.getController() instanceof SaveablePaneController)));
/* 102 */       this.closeDisabled.setValue(Boolean.valueOf(false));
/*     */     }
/*     */   }
/*     */   
/*     */   public void onShowDictionaries() {
/* 107 */     checkExternalDictionariesAvailability();
/* 108 */     this.menuDictionaries.getItems().remove(5, this.menuDictionaries.getItems().size());
/* 109 */     initDictionariesMenu();
/*     */   }
/*     */   
/*     */   public void onAnalyzeText() {
/* 113 */     new TextAnalyzer(this.app).run(0);
/*     */   }
/*     */   
/*     */   public void onAnalyzeTextInFolder() {
/* 117 */     new TextAnalyzer(this.app).run(1);
/*     */   }
/*     */   
/*     */   public void onAnalyzeExcel() {
/* 121 */     new ExcelCsvAnalyzer(this.app).run();
/*     */   }
/*     */   
/*     */   public void onCategorizeWords() {
/* 125 */     new WordCategorizer(this.app).run();
/*     */   }
/*     */   
/*     */   public void onColorCodeWords() {
/* 129 */     new TextColorCoder(this.app).run();
/*     */   }
/*     */   
/*     */   public void onQuit() {
/* 133 */     Utils.closeStage(this.app.getStage());
/*     */   }
/*     */   
/*     */   public void onHelp() {
/* 137 */     this.app.openHelpWindow();
/*     */   }
/*     */   
/*     */   public void onAbout() {
/* 141 */     AboutDialogController.run(this.app, "/com/liwc/LIWC2015/view/AboutDialog.fxml", new Object[0]);
/*     */   }
/*     */   
/*     */   public void onCategories() {
/* 145 */     CategoriesDialogController.run(this.app, "/com/liwc/LIWC2015/view/CategoriesDialog.fxml", new Object[0]);
/*     */   }
/*     */   
/*     */   public void onSegments() {
/* 149 */     SegmentOptionsDialogController.run(this.app, "/com/liwc/LIWC2015/view/SegmentOptionsDialog.fxml", new Object[0]);
/*     */   }
/*     */   
/*     */   public void onDictionaryDetails() throws IOException {
/* 153 */     VBox box = new VBox();
/* 154 */     box.setSpacing(4.0D);
/* 155 */     Label label = new Label(String.format("Type: %s", new Object[] { this.app.getLiwcPreferences().getDictionaryType() }));
/* 156 */     box.getChildren().add(label);
/* 157 */     label = new Label(this.app.getLiwcPreferences().hasExternalDictionary() ? String.format("Path: %s", new Object[] { this.app.getLiwcPreferences().getDictionaryPath() }) : String.format("Name: %s", new Object[] { this.app.getDictionaries().getDictionary(this.app.getLiwcPreferences().getDictionaryId()).getName() }));
/* 158 */     box.getChildren().add(label);
/* 159 */     LIWCAlert info = new LIWCAlert(this.app, Alert.AlertType.INFORMATION, "Dictionary Details", null, null);
/* 160 */     info.getDialogPane().setContent(box);
/* 161 */     this.app.setModalIsOpen(true);
/* 162 */     info.showAndWait();
/* 163 */     this.app.setModalIsOpen(false);
/*     */   }
/*     */   
/*     */   public void onSave() {
/* 167 */     if (this.app.getActiveResultPane() != null)
/* 168 */       this.app.getActiveResultPane().save();
/*     */   }
/*     */   
/*     */   public void onClose() {
/* 172 */     if (this.app.getActiveResultPane() != null)
/* 173 */       this.app.getActiveResultPane().close();
/*     */   }
/*     */   
/*     */   public void onSettings() {
/* 177 */     SettingsDialogController.run(this.app, "/com/liwc/LIWC2015/view/SettingsDialog.fxml", new Object[0]);
/*     */   }
/*     */   
/*     */   public void onDeactivate() {
/* 181 */     this.app.deactivate();
/*     */   }
/*     */   
/*     */   public void onExportInternalDictionaries() {
/* 185 */     DirectoryChooserWrapper wr = new DirectoryChooserWrapper();
/* 186 */     javafx.stage.DirectoryChooser directoryChooser = wr.getDirectoryChooser();
/* 187 */     directoryChooser.setTitle("Select Folder to Export Dictionaries");
/* 188 */     this.app.setModalIsOpen(true);
/* 189 */     Utils.setInitialFolder(directoryChooser, this.app.getLiwcPreferences().getLastVisitedFolder());
/* 190 */     File folder = wr.showDialog();
/* 191 */     this.app.setModalIsOpen(false);
/* 192 */     boolean exported = false;
/* 193 */     if (folder != null) {
/* 194 */       for (Dictionary dic : this.app.getDictionaries().getDictionaries()) {
/*     */         try {
/* 196 */           InputStream is = App.class.getResourceAsStream(Dictionaries.DictionariesPackage + dic.getRefExport());
/* 197 */           if (is != null) {
/* 198 */             File file = new File(folder.getAbsolutePath() + File.separator + dic.getRefExport());
/* 199 */             if (!file.exists()) {
/* 200 */               FileOutputStream fos = new FileOutputStream(file);
/* 201 */               byte[] buf = new byte[65536];
/*     */               for (;;) {
/* 203 */                 int len = is.read(buf, 0, 65536);
/* 204 */                 if (len <= 0) break;
/* 205 */                 fos.write(buf, 0, len);
/*     */               }
/*     */               
/*     */ 
/* 209 */               fos.close();
/*     */             }
/* 211 */             is.close();
/* 212 */             exported = true;
/*     */           }
/*     */         } catch (IOException e) {
/* 215 */           logger.error(e.getLocalizedMessage(), e);
/* 216 */           Utils.showException(this.app, e);
/*     */         }
/*     */       }
/*     */     }
/* 220 */     if (exported) {
/* 221 */       Utils.showAlert(this.app, Alert.AlertType.INFORMATION, "LIWC2015", null, String.format("Internal dictionaries have been exported to folder \"%s\".", new Object[] { folder.getAbsolutePath() }));
/*     */     }
/*     */   }
/*     */   
/*     */   private void onGetMoreDictionaries()
/*     */   {
/* 227 */     this.app.getHostServices().showDocument("http://dictionaries.liwc.net");
/*     */   }
/*     */   
/*     */   private void initDictionariesMenu() {
/* 231 */     Dictionaries dictionaries = this.app.getDictionaries();
/* 232 */     this.loadNewDictionaryItem.setOnAction(new EventHandler()
/*     */     {
/*     */       public void handle(ActionEvent event) {
/* 235 */         com.liwc.core.dictionary.IDictionary dictionary = null;
/* 236 */         File file = null;
/*     */         try {
/* 238 */           FileChooserWrapper wr = new FileChooserWrapper();
/* 239 */           FileChooser fileChooser = wr.getFileChooser();
/* 240 */           javafx.stage.FileChooser.ExtensionFilter extFilter = new javafx.stage.FileChooser.ExtensionFilter("LIWC Dictionary files (*.dic)", new String[] { "*.dic" });
/* 241 */           fileChooser.getExtensionFilters().add(extFilter);
/* 242 */           fileChooser.setTitle("Select Dictionary");
/* 243 */           Utils.setInitialFolder(fileChooser, MainMenuController.this.app.getLiwcPreferences().getLastVisitedFolder());
/* 244 */           MainMenuController.this.app.setModalIsOpen(true);
/* 245 */           file = wr.showOpenDialog();
/* 246 */           MainMenuController.this.app.setModalIsOpen(false);
/* 247 */           dictionary = MainMenuController.this.app.setExtActiveDictionary(file.getAbsolutePath());
/*     */         } catch (Exception e) {
/* 249 */           MainMenuController.logger.error(e.getLocalizedMessage(), e);
/*     */         }
/* 251 */         if (dictionary != null) {
/* 252 */           Utils.showAlert(MainMenuController.this.app, Alert.AlertType.INFORMATION, "LIWC2015", null, String.format("Dictionary \"%s\" has been successfully loaded. If you make any changes to the dictionary file, you will need to load the dictionary file again.", new Object[] { file.getName() }));
/* 253 */           MainMenuController.this.app.getLiwcPreferences().setLastVisitedFolder(file.getParent());
/* 254 */           if (!MainMenuController.this.app.getLiwcPreferences().getExternalDictionaries().getExternalDictionaries().contains(file.getAbsolutePath()))
/* 255 */             MainMenuController.this.app.getLiwcPreferences().getExternalDictionaries().getExternalDictionaries().add(file.getAbsolutePath());
/* 256 */           RadioMenuItem item = (RadioMenuItem)MainMenuController.getMenuItem(MainMenuController.this.menuDictionaries, file.getAbsolutePath());
/* 257 */           if ((item == null) || (item != MainMenuController.this.currentDictionaryItem))
/*     */           {
/*     */ 
/* 260 */             if (item == null) {
/* 261 */               item = MainMenuController.this.addDictionaryMenuItem(file.getName(), file.getAbsolutePath(), false);
/*     */             }
/* 263 */             if (item != null) {
/* 264 */               MainMenuController.this.currentDictionaryItem = item;
/* 265 */               MainMenuController.this.app.getLiwcPreferences().getCategories().setSelectAll(true);
/* 266 */               item.setSelected(true);
/*     */             }
/*     */           }
/* 269 */           MainMenuController.this.app.getWelcomeScreenModel().setAllCategoriesOn(WelcomeScreenController.buildCategoriesString(MainMenuController.this.app.getLiwcPreferences().getCategories(), dictionary));
/*     */         }
/*     */       }
/*     */     });
/*     */     
/* 274 */     for (Iterator localIterator = dictionaries.getDictionaries().iterator(); localIterator.hasNext();) { dictionary = (Dictionary)localIterator.next();
/* 275 */       addDictionaryMenuItem(dictionary.getName(), dictionary.getId(), true);
/*     */     }
/*     */     
/*     */     Dictionary dictionary;
/* 279 */     boolean hasExternalDictionaries = false;
/* 280 */     for (String externalDictionary : this.app.getLiwcPreferences().getExternalDictionaries().getExternalDictionaries()) {
/* 281 */       File file = new File(externalDictionary);
/* 282 */       if (file.exists()) {
/* 283 */         hasExternalDictionaries = true;
/* 284 */         break;
/*     */       }
/*     */     }
/* 287 */     if (hasExternalDictionaries) {
/* 288 */       this.menuDictionaries.getItems().add(this.intExtSeparator);
/* 289 */       for (String externalDictionary : this.app.getLiwcPreferences().getExternalDictionaries().getExternalDictionaries()) {
/* 290 */         File file = new File(externalDictionary);
/* 291 */         if (file.exists()) {
/* 292 */           addDictionaryMenuItem(file.getName(), file.getAbsolutePath(), false);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 297 */     SeparatorMenuItem sep = new SeparatorMenuItem();
/* 298 */     this.menuDictionaries.getItems().add(sep);
/* 299 */     MenuItem getMoreDictionariesItem = new MenuItem("Get More Dictionaries");
/* 300 */     getMoreDictionariesItem.setOnAction(new EventHandler()
/*     */     {
/*     */       public void handle(ActionEvent event) {
/* 303 */         MainMenuController.this.onGetMoreDictionaries();
/*     */       }
/* 305 */     });
/* 306 */     this.menuDictionaries.getItems().add(getMoreDictionariesItem);
/*     */     
/* 308 */     RadioMenuItem menuItem = (RadioMenuItem)getMenuItem(this.menuDictionaries, this.app.getLiwcPreferences().hasExternalDictionary() ? this.app.getLiwcPreferences().getDictionaryPath() : this.app.getLiwcPreferences().getDictionaryId());
/* 309 */     if (menuItem != null) {
/* 310 */       menuItem.setSelected(true);
/* 311 */       this.currentDictionaryItem = menuItem;
/*     */     }
/*     */   }
/*     */   
/*     */   private final void checkExternalDictionariesAvailability() {
/* 316 */     LiwcPreferences.ExternalDictionaries externalDictionaries = this.app.getLiwcPreferences().getExternalDictionaries();
/* 317 */     for (int i = externalDictionaries.getExternalDictionaries().size() - 1; i >= 0; i--) {
/* 318 */       if (!new File((String)externalDictionaries.getExternalDictionaries().get(i)).exists()) {
/* 319 */         externalDictionaries.getExternalDictionaries().remove(i);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private RadioMenuItem addDictionaryMenuItem(String itemName, String itemId, final boolean internal)
/*     */   {
/* 326 */     RadioMenuItem item = new RadioMenuItem(itemName);
/* 327 */     item.setMnemonicParsing(false);
/* 328 */     item.disableProperty().bind(this.disableMenu);
/* 329 */     item.setUserData(itemId);
/* 330 */     item.setId(itemId);
/* 331 */     item.setToggleGroup(this.dictionariesToggleGroup);
/* 332 */     item.setOnAction(new EventHandler()
/*     */     {
/*     */       public void handle(ActionEvent event) {
/* 335 */         com.liwc.core.dictionary.IDictionary dictionary = null;
/* 336 */         RadioMenuItem item = (RadioMenuItem)event.getSource();
/* 337 */         if (item == MainMenuController.this.currentDictionaryItem)
/* 338 */           return;
/*     */         try {
/* 340 */           String userData = (String)item.getUserData();
/* 341 */           if (internal) {
/* 342 */             dictionary = MainMenuController.this.app.setIntActiveDictionary(userData);
/*     */           } else
/* 344 */             dictionary = MainMenuController.this.app.setExtActiveDictionary(userData);
/*     */         } catch (Exception e) {
/* 346 */           MainMenuController.logger.error(e.getLocalizedMessage(), e);
/*     */         }
/* 348 */         if (dictionary != null) {
/* 349 */           MainMenuController.this.currentDictionaryItem = item;
/* 350 */           MainMenuController.this.app.getLiwcPreferences().getCategories().setSelectAll(true);
/* 351 */           MainMenuController.this.app.getWelcomeScreenModel().setAllCategoriesOn(WelcomeScreenController.buildCategoriesString(MainMenuController.this.app.getLiwcPreferences().getCategories(), dictionary));
/*     */         } else {
/* 353 */           MainMenuController.this.currentDictionaryItem.setSelected(true);
/*     */         }
/*     */       }
/* 356 */     });
/* 357 */     this.menuDictionaries.getItems().add(item);
/* 358 */     return item;
/*     */   }
/*     */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/MainMenuController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */