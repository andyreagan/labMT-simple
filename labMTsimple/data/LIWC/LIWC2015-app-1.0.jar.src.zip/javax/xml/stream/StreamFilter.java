package javax.xml.stream;

public abstract interface StreamFilter
{
  public abstract boolean accept(XMLStreamReader paramXMLStreamReader);
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/javax/xml/stream/StreamFilter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */