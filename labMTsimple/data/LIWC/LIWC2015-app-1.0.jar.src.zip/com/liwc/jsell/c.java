package com.liwc.jsell;

import java.util.ArrayList;

final class c
  extends ArrayList
{
  c()
  {
    add("esell.exe");
    add("eWebClient.dll");
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/jsell/c.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */