package com.liwc.core.text;

public class TextToken
{
  public static final int TokenTypeUnknown = 0;
  public static final int TokenTypeWord = 1;
  public static final int TokenTypeNumber = 2;
  public static final int TokenTypePunctuationMark = 3;
  public static final int TokenTypeDelimiter = 4;
  private int a = 0;
  private String b;
  
  public TextToken(int paramInt, String paramString)
  {
    this.a = paramInt;
    this.b = paramString;
  }
  
  public TextToken(int paramInt1, String paramString, int paramInt2, int paramInt3)
  {
    this.a = paramInt1;
    this.b = paramString.substring(paramInt2, paramInt3);
  }
  
  public int getTokenType()
  {
    return this.a;
  }
  
  public String getTokenValue()
  {
    return this.b;
  }
  
  public boolean isWord()
  {
    return this.a == 1;
  }
  
  public boolean isPunctuationMark()
  {
    return this.a == 3;
  }
  
  public boolean isDelimiter()
  {
    return this.a == 4;
  }
  
  public boolean isLineEnding()
  {
    return (isDelimiter()) && ((this.b.equals("\r")) || (this.b.equals("\n")));
  }
  
  public boolean isNumber()
  {
    return this.a == 2;
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/core/text/TextToken.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */