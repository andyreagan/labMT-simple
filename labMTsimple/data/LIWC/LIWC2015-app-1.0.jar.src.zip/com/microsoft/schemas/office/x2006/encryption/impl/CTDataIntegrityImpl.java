package com.microsoft.schemas.office.x2006.encryption.impl;

import com.microsoft.schemas.office.x2006.encryption.CTDataIntegrity;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SimpleValue;
import org.apache.xmlbeans.XmlBase64Binary;
import org.apache.xmlbeans.impl.values.TypeStore;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;

public class CTDataIntegrityImpl
  extends XmlComplexContentImpl
  implements CTDataIntegrity
{
  private static final QName ENCRYPTEDHMACKEY$0 = new QName("", "encryptedHmacKey");
  private static final QName ENCRYPTEDHMACVALUE$2 = new QName("", "encryptedHmacValue");
  
  public CTDataIntegrityImpl(SchemaType paramSchemaType)
  {
    super(paramSchemaType);
  }
  
  public byte[] getEncryptedHmacKey()
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(ENCRYPTEDHMACKEY$0);
      if (localSimpleValue == null) {
        return null;
      }
      return localSimpleValue.getByteArrayValue();
    }
  }
  
  public XmlBase64Binary xgetEncryptedHmacKey()
  {
    synchronized (monitor())
    {
      check_orphaned();
      XmlBase64Binary localXmlBase64Binary = null;
      localXmlBase64Binary = (XmlBase64Binary)get_store().find_attribute_user(ENCRYPTEDHMACKEY$0);
      return localXmlBase64Binary;
    }
  }
  
  public void setEncryptedHmacKey(byte[] paramArrayOfByte)
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(ENCRYPTEDHMACKEY$0);
      if (localSimpleValue == null) {
        localSimpleValue = (SimpleValue)get_store().add_attribute_user(ENCRYPTEDHMACKEY$0);
      }
      localSimpleValue.setByteArrayValue(paramArrayOfByte);
    }
  }
  
  public void xsetEncryptedHmacKey(XmlBase64Binary paramXmlBase64Binary)
  {
    synchronized (monitor())
    {
      check_orphaned();
      XmlBase64Binary localXmlBase64Binary = null;
      localXmlBase64Binary = (XmlBase64Binary)get_store().find_attribute_user(ENCRYPTEDHMACKEY$0);
      if (localXmlBase64Binary == null) {
        localXmlBase64Binary = (XmlBase64Binary)get_store().add_attribute_user(ENCRYPTEDHMACKEY$0);
      }
      localXmlBase64Binary.set(paramXmlBase64Binary);
    }
  }
  
  public byte[] getEncryptedHmacValue()
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(ENCRYPTEDHMACVALUE$2);
      if (localSimpleValue == null) {
        return null;
      }
      return localSimpleValue.getByteArrayValue();
    }
  }
  
  public XmlBase64Binary xgetEncryptedHmacValue()
  {
    synchronized (monitor())
    {
      check_orphaned();
      XmlBase64Binary localXmlBase64Binary = null;
      localXmlBase64Binary = (XmlBase64Binary)get_store().find_attribute_user(ENCRYPTEDHMACVALUE$2);
      return localXmlBase64Binary;
    }
  }
  
  public void setEncryptedHmacValue(byte[] paramArrayOfByte)
  {
    synchronized (monitor())
    {
      check_orphaned();
      SimpleValue localSimpleValue = null;
      localSimpleValue = (SimpleValue)get_store().find_attribute_user(ENCRYPTEDHMACVALUE$2);
      if (localSimpleValue == null) {
        localSimpleValue = (SimpleValue)get_store().add_attribute_user(ENCRYPTEDHMACVALUE$2);
      }
      localSimpleValue.setByteArrayValue(paramArrayOfByte);
    }
  }
  
  public void xsetEncryptedHmacValue(XmlBase64Binary paramXmlBase64Binary)
  {
    synchronized (monitor())
    {
      check_orphaned();
      XmlBase64Binary localXmlBase64Binary = null;
      localXmlBase64Binary = (XmlBase64Binary)get_store().find_attribute_user(ENCRYPTEDHMACVALUE$2);
      if (localXmlBase64Binary == null) {
        localXmlBase64Binary = (XmlBase64Binary)get_store().add_attribute_user(ENCRYPTEDHMACVALUE$2);
      }
      localXmlBase64Binary.set(paramXmlBase64Binary);
    }
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/encryption/impl/CTDataIntegrityImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */