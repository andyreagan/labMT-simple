package com.liwc.core.text;

final class a
{
  private int a = 0;
  
  a(TextParser paramTextParser)
  {
    this(paramTextParser, 0);
  }
  
  private a(TextParser paramTextParser, int paramInt) {}
  
  public final int a()
  {
    return this.a;
  }
  
  public final void a(int paramInt)
  {
    this.a = paramInt;
  }
  
  public final void b()
  {
    this.a += 1;
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/core/text/a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */