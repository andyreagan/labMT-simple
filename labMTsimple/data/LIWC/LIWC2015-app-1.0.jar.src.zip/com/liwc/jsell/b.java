package com.liwc.jsell;

import java.util.ArrayList;

final class b
  extends ArrayList
{
  b()
  {
    add("esell.zip");
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/jsell/b.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */