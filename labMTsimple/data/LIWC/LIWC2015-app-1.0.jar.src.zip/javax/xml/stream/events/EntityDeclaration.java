package javax.xml.stream.events;

public abstract interface EntityDeclaration
  extends XMLEvent
{
  public abstract String getPublicId();
  
  public abstract String getSystemId();
  
  public abstract String getName();
  
  public abstract String getNotationName();
  
  public abstract String getReplacementText();
  
  public abstract String getBaseURI();
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/javax/xml/stream/events/EntityDeclaration.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */