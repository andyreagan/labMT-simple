/*     */ package com.liwc.LIWC2015;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.nio.charset.Charset;
/*     */ import java.text.DateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import javax.xml.bind.JAXBContext;
/*     */ import javax.xml.bind.JAXBException;
/*     */ import javax.xml.bind.Marshaller;
/*     */ import javax.xml.bind.Unmarshaller;
/*     */ import javax.xml.bind.annotation.XmlAttribute;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.XmlRootElement;
/*     */ import javax.xml.bind.annotation.XmlTransient;
/*     */ import org.apache.commons.io.Charsets;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ @XmlRootElement
/*     */ public class LiwcPreferences
/*     */ {
/*  25 */   private static Logger logger = LoggerFactory.getLogger(LiwcPreferences.class);
/*     */   
/*  27 */   private boolean showWelcomeScreen = true;
/*  28 */   private SegmentOptions segmentOptions = new SegmentOptions();
/*  29 */   private String plainTextEncoding = Charsets.UTF_8.name();
/*  30 */   private String lastVisitedFolder = "";
/*  31 */   private String localeName = Locale.US.toString();
/*  32 */   private Categories categories = new Categories();
/*  33 */   private String serialNumber = "";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  41 */   private int csvDelimiter = 0;
/*  42 */   private char csvQuoteCharacter = '"';
/*  43 */   private char csvEscapeCharacter = '\000';
/*  44 */   private ExternalDictionaries externalDictionaries = new ExternalDictionaries();
/*  45 */   private String lastSaveResultFormat = ".txt";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  53 */   private String currentDictionary = "internal.LIWC2015";
/*     */   
/*     */ 
/*     */ 
/*     */   public static LiwcPreferences load()
/*     */   {
/*     */     try
/*     */     {
/*  61 */       File file = new File(Utils.getPreferencesPath());
/*  62 */       JAXBContext jaxbContext = JAXBContext.newInstance(new Class[] { LiwcPreferences.class });
/*  63 */       Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
/*  64 */       return (LiwcPreferences)jaxbUnmarshaller.unmarshal(file);
/*     */     }
/*     */     catch (JAXBException e) {
/*  67 */       logger.error(e.getLocalizedMessage(), e); }
/*  68 */     return new LiwcPreferences();
/*     */   }
/*     */   
/*     */   public static void save(LiwcPreferences prefs)
/*     */   {
/*     */     try {
/*  74 */       new File(Utils.getAppSettingsFolder()).mkdirs();
/*  75 */       File file = new File(Utils.getPreferencesPath());
/*  76 */       JAXBContext jaxbContext = JAXBContext.newInstance(new Class[] { LiwcPreferences.class });
/*  77 */       Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
/*  78 */       jaxbMarshaller.setProperty("jaxb.formatted.output", Boolean.valueOf(true));
/*  79 */       jaxbMarshaller.marshal(prefs, file);
/*     */     } catch (JAXBException e) {
/*  81 */       logger.error(e.getLocalizedMessage(), e);
/*     */     }
/*     */   }
/*     */   
/*     */   @XmlElement
/*     */   public boolean getShowWelcomeScreen() {
/*  87 */     return this.showWelcomeScreen;
/*     */   }
/*     */   
/*     */   public void setShowWelcomeScreen(boolean showWelcomeScreen) {
/*  91 */     this.showWelcomeScreen = showWelcomeScreen;
/*     */   }
/*     */   
/*     */   @XmlElement
/*     */   public String getCurrentDictionary() {
/*  96 */     return this.currentDictionary;
/*     */   }
/*     */   
/*     */   public void setCurrentDictionary(String currentDictionary) {
/* 100 */     this.currentDictionary = currentDictionary;
/*     */   }
/*     */   
/*     */   @XmlElement
/*     */   public SegmentOptions getSegmentOptions() {
/* 105 */     return this.segmentOptions;
/*     */   }
/*     */   
/*     */   public void setSegmentOptions(SegmentOptions segmentOptions) {
/* 109 */     this.segmentOptions = segmentOptions;
/*     */   }
/*     */   
/*     */   @XmlElement
/*     */   public String getPlainTextEncoding() {
/* 114 */     return this.plainTextEncoding;
/*     */   }
/*     */   
/*     */   public void setPlainTextEncoding(String plainTextEncoding) {
/* 118 */     this.plainTextEncoding = plainTextEncoding;
/*     */   }
/*     */   
/*     */   @XmlElement
/*     */   public String getLastVisitedFolder() {
/* 123 */     return this.lastVisitedFolder;
/*     */   }
/*     */   
/*     */   public void setLastVisitedFolder(String lastVisitedFolder) {
/* 127 */     if (lastVisitedFolder == null)
/* 128 */       lastVisitedFolder = "";
/* 129 */     this.lastVisitedFolder = lastVisitedFolder;
/*     */   }
/*     */   
/*     */   @XmlElement
/*     */   public Categories getCategories() {
/* 134 */     return this.categories;
/*     */   }
/*     */   
/*     */   public void setCategories(Categories categories) {
/* 138 */     this.categories = categories;
/*     */   }
/*     */   
/*     */   @XmlElement
/*     */   public String getLocaleName() {
/* 143 */     return this.localeName;
/*     */   }
/*     */   
/*     */   public void setLocaleName(String localeName) {
/* 147 */     this.localeName = localeName;
/*     */   }
/*     */   
/*     */   @XmlTransient
/*     */   public Locale getLocale() {
/* 152 */     Locale[] locales = DateFormat.getAvailableLocales();
/* 153 */     for (Locale locale : locales) {
/* 154 */       if (locale.toString().equalsIgnoreCase(getLocaleName())) {
/* 155 */         return locale;
/*     */       }
/*     */     }
/* 158 */     return Locale.US;
/*     */   }
/*     */   
/*     */   public void setLocale(Locale locale) {
/* 162 */     setLocaleName(locale.toString());
/*     */   }
/*     */   
/*     */   @XmlElement
/*     */   public String getSerialNumber() {
/* 167 */     return this.serialNumber;
/*     */   }
/*     */   
/*     */   public void setSerialNumber(String serialNumber) {
/* 171 */     this.serialNumber = serialNumber;
/*     */   }
/*     */   
/*     */   @XmlElement
/*     */   public int getCsvDelimiter() {
/* 176 */     return this.csvDelimiter;
/*     */   }
/*     */   
/*     */   public void setCsvDelimiter(int csvDelimiter) {
/* 180 */     this.csvDelimiter = csvDelimiter;
/*     */   }
/*     */   
/*     */   @XmlElement
/*     */   public char getCsvQuoteCharacter() {
/* 185 */     return this.csvQuoteCharacter;
/*     */   }
/*     */   
/*     */   public void setCsvQuoteCharacter(char csvQuoteCharacter) {
/* 189 */     this.csvQuoteCharacter = csvQuoteCharacter;
/*     */   }
/*     */   
/*     */   @XmlElement
/*     */   public char getCsvEscapeCharacter() {
/* 194 */     return this.csvEscapeCharacter;
/*     */   }
/*     */   
/*     */   public void setCsvEscapeCharacter(char csvEscapeCharacter) {
/* 198 */     this.csvEscapeCharacter = csvEscapeCharacter;
/*     */   }
/*     */   
/*     */   @XmlElement
/*     */   public ExternalDictionaries getExternalDictionaries() {
/* 203 */     return this.externalDictionaries;
/*     */   }
/*     */   
/*     */   public void setExternalDictionaries(ExternalDictionaries externalDictionaries) {
/* 207 */     this.externalDictionaries = externalDictionaries;
/*     */   }
/*     */   
/*     */   @XmlElement
/*     */   public String getLastSaveResultFormat() {
/* 212 */     return this.lastSaveResultFormat;
/*     */   }
/*     */   
/*     */   public void setLastSaveResultFormat(String lastSaveResultFormat) {
/* 216 */     this.lastSaveResultFormat = lastSaveResultFormat;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getDictionaryType()
/*     */   {
/* 223 */     String[] s = getCurrentDictionary().split("\\.");
/* 224 */     if (s.length > 0)
/* 225 */       return s[0];
/* 226 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getDictionaryPath()
/*     */   {
/* 233 */     if (getDictionaryType().equals("external")) {
/* 234 */       return getCurrentDictionary().replaceAll("external\\.", "");
/*     */     }
/* 236 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getDictionaryId()
/*     */   {
/* 243 */     if (getDictionaryType().equals("internal")) {
/* 244 */       String[] s = getCurrentDictionary().split("\\.");
/* 245 */       if (s.length > 1)
/* 246 */         return s[1];
/*     */     }
/* 248 */     return "";
/*     */   }
/*     */   
/*     */   public boolean hasExternalDictionary() {
/* 252 */     return "external".equals(getDictionaryType());
/*     */   }
/*     */   
/*     */   public boolean hasInternalDictionary() {
/* 256 */     return "internal".equals(getDictionaryType());
/*     */   }
/*     */   
/*     */   public void setExternalDictionary(String path) {
/* 260 */     setCurrentDictionary("external." + path);
/*     */   }
/*     */   
/*     */   public void setInternalDictionary(String dictionaryId) {
/* 264 */     setCurrentDictionary("internal." + dictionaryId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class SegmentOptions
/*     */   {
/* 276 */     private int type = 0;
/*     */     
/* 278 */     private Integer numberOfSegments = Integer.valueOf(1);
/*     */     
/* 280 */     private Integer wordsPerSegment = Integer.valueOf(1000);
/*     */     
/* 282 */     private String specialCharacters = "¶";
/*     */     
/* 284 */     private Integer numberOfCarriageReturns = Integer.valueOf(1);
/*     */     
/*     */     @XmlAttribute
/*     */     public int getType() {
/* 288 */       if ((this.type < 0) || (this.type > 4))
/* 289 */         this.type = 0;
/* 290 */       return this.type;
/*     */     }
/*     */     
/*     */     public void setType(int type) {
/* 294 */       this.type = type;
/*     */     }
/*     */     
/*     */     @XmlAttribute
/*     */     public Integer getNumberOfSegments() {
/* 299 */       if (this.numberOfSegments.intValue() < 1)
/* 300 */         this.numberOfSegments = Integer.valueOf(1);
/* 301 */       return this.numberOfSegments;
/*     */     }
/*     */     
/*     */     public void setNumberOfSegments(Integer numberOfSegments) {
/* 305 */       this.numberOfSegments = numberOfSegments;
/*     */     }
/*     */     
/*     */     @XmlAttribute
/*     */     public Integer getWordsPerSegment() {
/* 310 */       if (this.wordsPerSegment.intValue() < 1)
/* 311 */         this.wordsPerSegment = Integer.valueOf(1);
/* 312 */       return this.wordsPerSegment;
/*     */     }
/*     */     
/*     */     public void setWordsPerSegment(Integer wordsPerSegment) {
/* 316 */       this.wordsPerSegment = wordsPerSegment;
/*     */     }
/*     */     
/*     */     @XmlAttribute
/*     */     public String getSpecialCharacters() {
/* 321 */       return this.specialCharacters;
/*     */     }
/*     */     
/*     */     public void setSpecialCharacters(String specialCharacters) {
/* 325 */       this.specialCharacters = specialCharacters;
/*     */     }
/*     */     
/*     */     @XmlAttribute
/*     */     public Integer getNumberOfCarriageReturns() {
/* 330 */       if (this.numberOfCarriageReturns.intValue() < 1)
/* 331 */         this.numberOfCarriageReturns = Integer.valueOf(1);
/* 332 */       if (this.numberOfCarriageReturns.intValue() > 3)
/* 333 */         this.numberOfCarriageReturns = Integer.valueOf(3);
/* 334 */       return this.numberOfCarriageReturns;
/*     */     }
/*     */     
/*     */     public void setNumberOfCarriageReturns(Integer numberOfCarriageReturns) {
/* 338 */       this.numberOfCarriageReturns = numberOfCarriageReturns;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class Categories
/*     */   {
/* 344 */     private boolean selectAll = true;
/* 345 */     private List<String> categories = new ArrayList();
/* 346 */     private boolean showWc = true;
/* 347 */     private boolean showWps = true;
/* 348 */     private boolean showSixltr = true;
/* 349 */     private boolean showDic = true;
/* 350 */     private boolean showAnalytic = true;
/* 351 */     private boolean showClout = true;
/* 352 */     private boolean showAuthentic = true;
/* 353 */     private boolean showTone = true;
/*     */     
/*     */     @XmlAttribute
/*     */     public boolean getSelectAll() {
/* 357 */       return this.selectAll;
/*     */     }
/*     */     
/*     */     public void setSelectAll(boolean selectAll) {
/* 361 */       this.selectAll = selectAll;
/*     */     }
/*     */     
/*     */     @XmlElement(name="category")
/*     */     public List<String> getCategories() {
/* 366 */       return this.categories;
/*     */     }
/*     */     
/*     */     public void setCategories(List<String> categories) {
/* 370 */       this.categories = categories;
/*     */     }
/*     */     
/*     */     @XmlAttribute
/*     */     public boolean getShowWc() {
/* 375 */       return this.showWc;
/*     */     }
/*     */     
/*     */     public void setShowWc(boolean showWc) {
/* 379 */       this.showWc = showWc;
/*     */     }
/*     */     
/*     */     @XmlAttribute
/*     */     public boolean getShowWps() {
/* 384 */       return this.showWps;
/*     */     }
/*     */     
/*     */     public void setShowWps(boolean showWps) {
/* 388 */       this.showWps = showWps;
/*     */     }
/*     */     
/*     */     @XmlAttribute
/*     */     public boolean getShowSixltr() {
/* 393 */       return this.showSixltr;
/*     */     }
/*     */     
/*     */     public void setShowSixltr(boolean showSixltr) {
/* 397 */       this.showSixltr = showSixltr;
/*     */     }
/*     */     
/*     */     @XmlAttribute
/*     */     public boolean getShowDic() {
/* 402 */       return this.showDic;
/*     */     }
/*     */     
/*     */     public void setShowDic(boolean showDic) {
/* 406 */       this.showDic = showDic;
/*     */     }
/*     */     
/*     */     @XmlAttribute
/*     */     public boolean getShowAnalytic() {
/* 411 */       return this.showAnalytic;
/*     */     }
/*     */     
/*     */     public void setShowAnalytic(boolean showAnalytic) {
/* 415 */       this.showAnalytic = showAnalytic;
/*     */     }
/*     */     
/*     */     @XmlAttribute
/*     */     public boolean getShowClout() {
/* 420 */       return this.showClout;
/*     */     }
/*     */     
/*     */     public void setShowClout(boolean showClout) {
/* 424 */       this.showClout = showClout;
/*     */     }
/*     */     
/*     */     @XmlAttribute
/*     */     public boolean getShowAuthentic() {
/* 429 */       return this.showAuthentic;
/*     */     }
/*     */     
/*     */     public void setShowAuthentic(boolean showAuthentic) {
/* 433 */       this.showAuthentic = showAuthentic;
/*     */     }
/*     */     
/*     */     @XmlAttribute
/*     */     public boolean getShowTone() {
/* 438 */       return this.showTone;
/*     */     }
/*     */     
/*     */     public void setShowTone(boolean showTone) {
/* 442 */       this.showTone = showTone;
/*     */     }
/*     */     
/*     */     public boolean showParam(String paramName) {
/* 446 */       if (paramName.equals("WC"))
/* 447 */         return getShowWc();
/* 448 */       if (paramName.equals("WPS"))
/* 449 */         return getShowWps();
/* 450 */       if (paramName.equals("Sixltr"))
/* 451 */         return getShowSixltr();
/* 452 */       if (paramName.equals("Dic"))
/* 453 */         return getShowDic();
/* 454 */       if (paramName.equals("Analytic"))
/* 455 */         return getShowAnalytic();
/* 456 */       if (paramName.equals("Clout"))
/* 457 */         return getShowClout();
/* 458 */       if (paramName.equals("Authentic"))
/* 459 */         return getShowAuthentic();
/* 460 */       if (paramName.equals("Tone")) {
/* 461 */         return getShowTone();
/*     */       }
/* 463 */       return (this.selectAll) || (this.categories.contains(paramName));
/*     */     }
/*     */   }
/*     */   
/*     */   public static class ExternalDictionaries
/*     */   {
/* 469 */     private List<String> externalDictionaries = new ArrayList();
/*     */     
/*     */     @XmlElement(name="externalDictionary")
/*     */     public List<String> getExternalDictionaries() {
/* 473 */       return this.externalDictionaries;
/*     */     }
/*     */     
/*     */     public void setExternalDictionaries(List<String> externalDictionaries) {
/* 477 */       this.externalDictionaries = externalDictionaries;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/LiwcPreferences.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */