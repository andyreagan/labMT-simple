/*    */ package com.liwc.LIWC2015.controller;
/*    */ 
/*    */ import com.liwc.LIWC2015.App;
/*    */ import com.liwc.LIWC2015.LiwcPreferences;
/*    */ import com.liwc.LIWC2015.Utils;
/*    */ import com.liwc.LIWC2015.customview.ExceptionDialog;
/*    */ import com.liwc.LIWC2015.customview.FileChooserWrapper;
/*    */ import com.liwc.LIWC2015.model.WordCategories;
/*    */ import com.liwc.core.LanguageSettings;
/*    */ import com.liwc.core.TextProcessor;
/*    */ import com.liwc.core.text.IText;
/*    */ import com.liwc.core.text.TextFactory;
/*    */ import com.liwc.core.text.TextParser;
/*    */ import java.io.File;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import javafx.collections.FXCollections;
/*    */ import javafx.collections.ObservableList;
/*    */ import javafx.stage.FileChooser;
/*    */ import javafx.stage.FileChooser.ExtensionFilter;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ 
/*    */ public class WordCategorizer
/*    */ {
/* 28 */   private static Logger logger = LoggerFactory.getLogger(WordCategorizer.class);
/*    */   private App app;
/*    */   
/*    */   public WordCategorizer(App app)
/*    */   {
/* 33 */     this.app = app;
/*    */   }
/*    */   
/*    */   public void run() {
/* 37 */     FileChooserWrapper wr = new FileChooserWrapper();
/* 38 */     FileChooser fileChooser = wr.getFileChooser();
/* 39 */     fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("All Text Documents (*.txt, *.doc, *.docx, *.rtf, *.pdf)", new String[] { "*.txt", "*.doc", "*.docx", "*.rtf", "*.pdf" }));
/* 40 */     fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text Files (*.txt)", new String[] { "*.txt" }));
/* 41 */     fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Word Documents (*.doc, *.docx)", new String[] { "*.doc", "*.docx" }));
/* 42 */     fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("RTF Documents (*.rtf)", new String[] { "*.rtf" }));
/* 43 */     fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF Documents (*.pdf)", new String[] { "*.pdf" }));
/* 44 */     fileChooser.setTitle("Select Text File");
/* 45 */     Utils.setInitialFolder(fileChooser, this.app.getLiwcPreferences().getLastVisitedFolder());
/* 46 */     this.app.setModalIsOpen(true);
/* 47 */     File file = wr.showOpenDialog();
/* 48 */     this.app.setModalIsOpen(false);
/* 49 */     if (file != null) {
/*    */       try {
/* 51 */         this.app.getLiwcPreferences().setLastVisitedFolder(file.getParent());
/* 52 */         WordCategorizerTask task = new WordCategorizerTask(this.app, file, null);
/* 53 */         ProgressDialogController.run(this.app, "/com/liwc/LIWC2015/view/ProgressDialog.fxml", new Object[] { task, Boolean.valueOf(false) });
/* 54 */         task.get();
/* 55 */         ObservableList<WordCategories> result = (ObservableList)task.get();
/* 56 */         CategorizeWordsPaneController controller = new CategorizeWordsPaneController(this.app);
/* 57 */         controller.build(result, file);
/*    */       } catch (Exception e) {
/* 59 */         logger.error(e.getLocalizedMessage(), e);
/* 60 */         this.app.setModalIsOpen(true);
/* 61 */         new ExceptionDialog(this.app, e).showAndWait();
/* 62 */         this.app.setModalIsOpen(false);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   private static class WordCategorizerTask extends CancelableTask<ObservableList<WordCategories>>
/*    */   {
/*    */     private App app;
/*    */     private File file;
/*    */     
/*    */     private WordCategorizerTask(App app, File file) {
/* 73 */       this.app = app;
/* 74 */       this.file = file;
/*    */     }
/*    */     
/*    */     protected ObservableList<WordCategories> call() throws Exception
/*    */     {
/* 79 */       updateMessage("Processing...");
/* 80 */       TextParser parser = new TextParser(this.app.getActiveDictionary(), new LanguageSettings(this.app.getLiwcPreferences().getLocale()));
/* 81 */       TextProcessor textProcessor = Utils.getTextProcessor(this.app, false);
/* 82 */       IText text = TextFactory.getText(this.file);
/* 83 */       ObservableList<WordCategories> result = FXCollections.observableArrayList();
/* 84 */       for (Map.Entry<String, List<Integer>> entry : textProcessor.getWordsByCategories(text, parser).entrySet()) {
/* 85 */         result.add(new WordCategories((String)entry.getKey(), (List)entry.getValue()));
/*    */       }
/* 87 */       text.close();
/* 88 */       return result;
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/WordCategorizer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */