package com.microsoft.schemas.office.x2006.digsig;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.SchemaTypeSystem;
import org.apache.xmlbeans.XmlAnyURI;
import org.apache.xmlbeans.XmlBase64Binary;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlInt;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.XmlString;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public abstract interface CTSignatureInfoV1
  extends XmlObject
{
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CTSignatureInfoV1.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0B482D0B338CC9641C1543C3510577FE").resolveHandle("ctsignatureinfov13a5ftype");
  
  public abstract String getSetupID();
  
  public abstract STUniqueIdentifierWithBraces xgetSetupID();
  
  public abstract void setSetupID(String paramString);
  
  public abstract void xsetSetupID(STUniqueIdentifierWithBraces paramSTUniqueIdentifierWithBraces);
  
  public abstract String getSignatureText();
  
  public abstract STSignatureText xgetSignatureText();
  
  public abstract void setSignatureText(String paramString);
  
  public abstract void xsetSignatureText(STSignatureText paramSTSignatureText);
  
  public abstract byte[] getSignatureImage();
  
  public abstract XmlBase64Binary xgetSignatureImage();
  
  public abstract void setSignatureImage(byte[] paramArrayOfByte);
  
  public abstract void xsetSignatureImage(XmlBase64Binary paramXmlBase64Binary);
  
  public abstract String getSignatureComments();
  
  public abstract STSignatureComments xgetSignatureComments();
  
  public abstract void setSignatureComments(String paramString);
  
  public abstract void xsetSignatureComments(STSignatureComments paramSTSignatureComments);
  
  public abstract String getWindowsVersion();
  
  public abstract STVersion xgetWindowsVersion();
  
  public abstract void setWindowsVersion(String paramString);
  
  public abstract void xsetWindowsVersion(STVersion paramSTVersion);
  
  public abstract String getOfficeVersion();
  
  public abstract STVersion xgetOfficeVersion();
  
  public abstract void setOfficeVersion(String paramString);
  
  public abstract void xsetOfficeVersion(STVersion paramSTVersion);
  
  public abstract String getApplicationVersion();
  
  public abstract STVersion xgetApplicationVersion();
  
  public abstract void setApplicationVersion(String paramString);
  
  public abstract void xsetApplicationVersion(STVersion paramSTVersion);
  
  public abstract int getMonitors();
  
  public abstract STPositiveInteger xgetMonitors();
  
  public abstract void setMonitors(int paramInt);
  
  public abstract void xsetMonitors(STPositiveInteger paramSTPositiveInteger);
  
  public abstract int getHorizontalResolution();
  
  public abstract STPositiveInteger xgetHorizontalResolution();
  
  public abstract void setHorizontalResolution(int paramInt);
  
  public abstract void xsetHorizontalResolution(STPositiveInteger paramSTPositiveInteger);
  
  public abstract int getVerticalResolution();
  
  public abstract STPositiveInteger xgetVerticalResolution();
  
  public abstract void setVerticalResolution(int paramInt);
  
  public abstract void xsetVerticalResolution(STPositiveInteger paramSTPositiveInteger);
  
  public abstract int getColorDepth();
  
  public abstract STPositiveInteger xgetColorDepth();
  
  public abstract void setColorDepth(int paramInt);
  
  public abstract void xsetColorDepth(STPositiveInteger paramSTPositiveInteger);
  
  public abstract String getSignatureProviderId();
  
  public abstract STUniqueIdentifierWithBraces xgetSignatureProviderId();
  
  public abstract void setSignatureProviderId(String paramString);
  
  public abstract void xsetSignatureProviderId(STUniqueIdentifierWithBraces paramSTUniqueIdentifierWithBraces);
  
  public abstract String getSignatureProviderUrl();
  
  public abstract STSignatureProviderUrl xgetSignatureProviderUrl();
  
  public abstract void setSignatureProviderUrl(String paramString);
  
  public abstract void xsetSignatureProviderUrl(STSignatureProviderUrl paramSTSignatureProviderUrl);
  
  public abstract int getSignatureProviderDetails();
  
  public abstract XmlInt xgetSignatureProviderDetails();
  
  public abstract void setSignatureProviderDetails(int paramInt);
  
  public abstract void xsetSignatureProviderDetails(XmlInt paramXmlInt);
  
  public abstract int getSignatureType();
  
  public abstract STSignatureType xgetSignatureType();
  
  public abstract void setSignatureType(int paramInt);
  
  public abstract void xsetSignatureType(STSignatureType paramSTSignatureType);
  
  public abstract String getDelegateSuggestedSigner();
  
  public abstract XmlString xgetDelegateSuggestedSigner();
  
  public abstract boolean isSetDelegateSuggestedSigner();
  
  public abstract void setDelegateSuggestedSigner(String paramString);
  
  public abstract void xsetDelegateSuggestedSigner(XmlString paramXmlString);
  
  public abstract void unsetDelegateSuggestedSigner();
  
  public abstract String getDelegateSuggestedSigner2();
  
  public abstract XmlString xgetDelegateSuggestedSigner2();
  
  public abstract boolean isSetDelegateSuggestedSigner2();
  
  public abstract void setDelegateSuggestedSigner2(String paramString);
  
  public abstract void xsetDelegateSuggestedSigner2(XmlString paramXmlString);
  
  public abstract void unsetDelegateSuggestedSigner2();
  
  public abstract String getDelegateSuggestedSignerEmail();
  
  public abstract XmlString xgetDelegateSuggestedSignerEmail();
  
  public abstract boolean isSetDelegateSuggestedSignerEmail();
  
  public abstract void setDelegateSuggestedSignerEmail(String paramString);
  
  public abstract void xsetDelegateSuggestedSignerEmail(XmlString paramXmlString);
  
  public abstract void unsetDelegateSuggestedSignerEmail();
  
  public abstract String getManifestHashAlgorithm();
  
  public abstract XmlAnyURI xgetManifestHashAlgorithm();
  
  public abstract boolean isSetManifestHashAlgorithm();
  
  public abstract void setManifestHashAlgorithm(String paramString);
  
  public abstract void xsetManifestHashAlgorithm(XmlAnyURI paramXmlAnyURI);
  
  public abstract void unsetManifestHashAlgorithm();
  
  public static final class Factory
  {
    public static CTSignatureInfoV1 newInstance()
    {
      return (CTSignatureInfoV1)XmlBeans.getContextTypeLoader().newInstance(CTSignatureInfoV1.type, null);
    }
    
    public static CTSignatureInfoV1 newInstance(XmlOptions paramXmlOptions)
    {
      return (CTSignatureInfoV1)XmlBeans.getContextTypeLoader().newInstance(CTSignatureInfoV1.type, paramXmlOptions);
    }
    
    public static CTSignatureInfoV1 parse(String paramString)
      throws XmlException
    {
      return (CTSignatureInfoV1)XmlBeans.getContextTypeLoader().parse(paramString, CTSignatureInfoV1.type, null);
    }
    
    public static CTSignatureInfoV1 parse(String paramString, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (CTSignatureInfoV1)XmlBeans.getContextTypeLoader().parse(paramString, CTSignatureInfoV1.type, paramXmlOptions);
    }
    
    public static CTSignatureInfoV1 parse(File paramFile)
      throws XmlException, IOException
    {
      return (CTSignatureInfoV1)XmlBeans.getContextTypeLoader().parse(paramFile, CTSignatureInfoV1.type, null);
    }
    
    public static CTSignatureInfoV1 parse(File paramFile, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTSignatureInfoV1)XmlBeans.getContextTypeLoader().parse(paramFile, CTSignatureInfoV1.type, paramXmlOptions);
    }
    
    public static CTSignatureInfoV1 parse(URL paramURL)
      throws XmlException, IOException
    {
      return (CTSignatureInfoV1)XmlBeans.getContextTypeLoader().parse(paramURL, CTSignatureInfoV1.type, null);
    }
    
    public static CTSignatureInfoV1 parse(URL paramURL, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTSignatureInfoV1)XmlBeans.getContextTypeLoader().parse(paramURL, CTSignatureInfoV1.type, paramXmlOptions);
    }
    
    public static CTSignatureInfoV1 parse(InputStream paramInputStream)
      throws XmlException, IOException
    {
      return (CTSignatureInfoV1)XmlBeans.getContextTypeLoader().parse(paramInputStream, CTSignatureInfoV1.type, null);
    }
    
    public static CTSignatureInfoV1 parse(InputStream paramInputStream, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTSignatureInfoV1)XmlBeans.getContextTypeLoader().parse(paramInputStream, CTSignatureInfoV1.type, paramXmlOptions);
    }
    
    public static CTSignatureInfoV1 parse(Reader paramReader)
      throws XmlException, IOException
    {
      return (CTSignatureInfoV1)XmlBeans.getContextTypeLoader().parse(paramReader, CTSignatureInfoV1.type, null);
    }
    
    public static CTSignatureInfoV1 parse(Reader paramReader, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTSignatureInfoV1)XmlBeans.getContextTypeLoader().parse(paramReader, CTSignatureInfoV1.type, paramXmlOptions);
    }
    
    public static CTSignatureInfoV1 parse(XMLStreamReader paramXMLStreamReader)
      throws XmlException
    {
      return (CTSignatureInfoV1)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, CTSignatureInfoV1.type, null);
    }
    
    public static CTSignatureInfoV1 parse(XMLStreamReader paramXMLStreamReader, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (CTSignatureInfoV1)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, CTSignatureInfoV1.type, paramXmlOptions);
    }
    
    public static CTSignatureInfoV1 parse(Node paramNode)
      throws XmlException
    {
      return (CTSignatureInfoV1)XmlBeans.getContextTypeLoader().parse(paramNode, CTSignatureInfoV1.type, null);
    }
    
    public static CTSignatureInfoV1 parse(Node paramNode, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (CTSignatureInfoV1)XmlBeans.getContextTypeLoader().parse(paramNode, CTSignatureInfoV1.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static CTSignatureInfoV1 parse(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return (CTSignatureInfoV1)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, CTSignatureInfoV1.type, null);
    }
    
    /**
     * @deprecated
     */
    public static CTSignatureInfoV1 parse(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return (CTSignatureInfoV1)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, CTSignatureInfoV1.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, CTSignatureInfoV1.type, null);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, CTSignatureInfoV1.type, paramXmlOptions);
    }
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/digsig/CTSignatureInfoV1.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */