package com.liwc.core.text;

import java.util.List;

public abstract interface IText
{
  public abstract List readText(TextParser paramTextParser);
  
  public abstract void close();
  
  public abstract int getWordsCount(boolean paramBoolean);
  
  public abstract String getText();
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/core/text/IText.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */