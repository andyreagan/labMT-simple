package com.liwc.jsell;

import java.io.File;

final class f
  implements i
{
  f(ESellerate paramESellerate, String paramString) {}
  
  public final Process a(File paramFile)
  {
    return Runtime.getRuntime().exec(new String[] { paramFile.getAbsolutePath(), "deactivateSerialNumber", this.a, ESellerate.a(this.b) ? "1" : "0" });
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/jsell/f.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */