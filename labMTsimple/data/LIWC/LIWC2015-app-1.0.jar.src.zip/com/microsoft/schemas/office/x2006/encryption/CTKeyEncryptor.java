package com.microsoft.schemas.office.x2006.encryption;

import com.microsoft.schemas.office.x2006.keyEncryptor.certificate.CTCertificateKeyEncryptor;
import com.microsoft.schemas.office.x2006.keyEncryptor.password.CTPasswordKeyEncryptor;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.SchemaTypeSystem;
import org.apache.xmlbeans.StringEnumAbstractBase;
import org.apache.xmlbeans.StringEnumAbstractBase.Table;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.XmlToken;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public abstract interface CTKeyEncryptor
  extends XmlObject
{
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CTKeyEncryptor.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0B482D0B338CC9641C1543C3510577FE").resolveHandle("ctkeyencryptor1205type");
  
  public abstract CTPasswordKeyEncryptor getEncryptedPasswordKey();
  
  public abstract boolean isSetEncryptedPasswordKey();
  
  public abstract void setEncryptedPasswordKey(CTPasswordKeyEncryptor paramCTPasswordKeyEncryptor);
  
  public abstract CTPasswordKeyEncryptor addNewEncryptedPasswordKey();
  
  public abstract void unsetEncryptedPasswordKey();
  
  public abstract CTCertificateKeyEncryptor getEncryptedCertificateKey();
  
  public abstract boolean isSetEncryptedCertificateKey();
  
  public abstract void setEncryptedCertificateKey(CTCertificateKeyEncryptor paramCTCertificateKeyEncryptor);
  
  public abstract CTCertificateKeyEncryptor addNewEncryptedCertificateKey();
  
  public abstract void unsetEncryptedCertificateKey();
  
  public abstract CTKeyEncryptor.Uri.Enum getUri();
  
  public abstract Uri xgetUri();
  
  public abstract boolean isSetUri();
  
  public abstract void setUri(CTKeyEncryptor.Uri.Enum paramEnum);
  
  public abstract void xsetUri(Uri paramUri);
  
  public abstract void unsetUri();
  
  public static final class Factory
  {
    public static CTKeyEncryptor newInstance()
    {
      return (CTKeyEncryptor)XmlBeans.getContextTypeLoader().newInstance(CTKeyEncryptor.type, null);
    }
    
    public static CTKeyEncryptor newInstance(XmlOptions paramXmlOptions)
    {
      return (CTKeyEncryptor)XmlBeans.getContextTypeLoader().newInstance(CTKeyEncryptor.type, paramXmlOptions);
    }
    
    public static CTKeyEncryptor parse(String paramString)
      throws XmlException
    {
      return (CTKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramString, CTKeyEncryptor.type, null);
    }
    
    public static CTKeyEncryptor parse(String paramString, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (CTKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramString, CTKeyEncryptor.type, paramXmlOptions);
    }
    
    public static CTKeyEncryptor parse(File paramFile)
      throws XmlException, IOException
    {
      return (CTKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramFile, CTKeyEncryptor.type, null);
    }
    
    public static CTKeyEncryptor parse(File paramFile, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramFile, CTKeyEncryptor.type, paramXmlOptions);
    }
    
    public static CTKeyEncryptor parse(URL paramURL)
      throws XmlException, IOException
    {
      return (CTKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramURL, CTKeyEncryptor.type, null);
    }
    
    public static CTKeyEncryptor parse(URL paramURL, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramURL, CTKeyEncryptor.type, paramXmlOptions);
    }
    
    public static CTKeyEncryptor parse(InputStream paramInputStream)
      throws XmlException, IOException
    {
      return (CTKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramInputStream, CTKeyEncryptor.type, null);
    }
    
    public static CTKeyEncryptor parse(InputStream paramInputStream, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramInputStream, CTKeyEncryptor.type, paramXmlOptions);
    }
    
    public static CTKeyEncryptor parse(Reader paramReader)
      throws XmlException, IOException
    {
      return (CTKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramReader, CTKeyEncryptor.type, null);
    }
    
    public static CTKeyEncryptor parse(Reader paramReader, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramReader, CTKeyEncryptor.type, paramXmlOptions);
    }
    
    public static CTKeyEncryptor parse(XMLStreamReader paramXMLStreamReader)
      throws XmlException
    {
      return (CTKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, CTKeyEncryptor.type, null);
    }
    
    public static CTKeyEncryptor parse(XMLStreamReader paramXMLStreamReader, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (CTKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, CTKeyEncryptor.type, paramXmlOptions);
    }
    
    public static CTKeyEncryptor parse(Node paramNode)
      throws XmlException
    {
      return (CTKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramNode, CTKeyEncryptor.type, null);
    }
    
    public static CTKeyEncryptor parse(Node paramNode, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (CTKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramNode, CTKeyEncryptor.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static CTKeyEncryptor parse(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return (CTKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, CTKeyEncryptor.type, null);
    }
    
    /**
     * @deprecated
     */
    public static CTKeyEncryptor parse(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return (CTKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, CTKeyEncryptor.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, CTKeyEncryptor.type, null);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, CTKeyEncryptor.type, paramXmlOptions);
    }
  }
  
  public static abstract interface Uri
    extends XmlToken
  {
    public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(Uri.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0B482D0B338CC9641C1543C3510577FE").resolveHandle("uribad9attrtype");
    public static final Enum HTTP_SCHEMAS_MICROSOFT_COM_OFFICE_2006_KEY_ENCRYPTOR_PASSWORD = Enum.forString("http://schemas.microsoft.com/office/2006/keyEncryptor/password");
    public static final Enum HTTP_SCHEMAS_MICROSOFT_COM_OFFICE_2006_KEY_ENCRYPTOR_CERTIFICATE = Enum.forString("http://schemas.microsoft.com/office/2006/keyEncryptor/certificate");
    public static final int INT_HTTP_SCHEMAS_MICROSOFT_COM_OFFICE_2006_KEY_ENCRYPTOR_PASSWORD = 1;
    public static final int INT_HTTP_SCHEMAS_MICROSOFT_COM_OFFICE_2006_KEY_ENCRYPTOR_CERTIFICATE = 2;
    
    public abstract StringEnumAbstractBase enumValue();
    
    public abstract void set(StringEnumAbstractBase paramStringEnumAbstractBase);
    
    public static final class Factory
    {
      public static CTKeyEncryptor.Uri newValue(Object paramObject)
      {
        return (CTKeyEncryptor.Uri)CTKeyEncryptor.Uri.type.newValue(paramObject);
      }
      
      public static CTKeyEncryptor.Uri newInstance()
      {
        return (CTKeyEncryptor.Uri)XmlBeans.getContextTypeLoader().newInstance(CTKeyEncryptor.Uri.type, null);
      }
      
      public static CTKeyEncryptor.Uri newInstance(XmlOptions paramXmlOptions)
      {
        return (CTKeyEncryptor.Uri)XmlBeans.getContextTypeLoader().newInstance(CTKeyEncryptor.Uri.type, paramXmlOptions);
      }
    }
    
    public static final class Enum
      extends StringEnumAbstractBase
    {
      static final int INT_HTTP_SCHEMAS_MICROSOFT_COM_OFFICE_2006_KEY_ENCRYPTOR_PASSWORD = 1;
      static final int INT_HTTP_SCHEMAS_MICROSOFT_COM_OFFICE_2006_KEY_ENCRYPTOR_CERTIFICATE = 2;
      public static final StringEnumAbstractBase.Table table = new StringEnumAbstractBase.Table(new Enum[] { new Enum("http://schemas.microsoft.com/office/2006/keyEncryptor/password", 1), new Enum("http://schemas.microsoft.com/office/2006/keyEncryptor/certificate", 2) });
      private static final long serialVersionUID = 1L;
      
      public static Enum forString(String paramString)
      {
        return (Enum)table.forString(paramString);
      }
      
      public static Enum forInt(int paramInt)
      {
        return (Enum)table.forInt(paramInt);
      }
      
      private Enum(String paramString, int paramInt)
      {
        super(paramInt);
      }
      
      private Object readResolve()
      {
        return forInt(intValue());
      }
    }
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/encryption/CTKeyEncryptor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */