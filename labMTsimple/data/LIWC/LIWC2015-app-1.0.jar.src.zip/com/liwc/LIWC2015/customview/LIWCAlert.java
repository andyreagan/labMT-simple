/*    */ package com.liwc.LIWC2015.customview;
/*    */ 
/*    */ import com.liwc.LIWC2015.App;
/*    */ import com.liwc.LIWC2015.Utils;
/*    */ import javafx.beans.NamedArg;
/*    */ import javafx.scene.control.Alert;
/*    */ import javafx.scene.control.Alert.AlertType;
/*    */ import javafx.stage.StageStyle;
/*    */ 
/*    */ public class LIWCAlert extends Alert
/*    */ {
/*    */   private App app;
/*    */   
/*    */   public LIWCAlert(App app, @NamedArg("alertType") Alert.AlertType alertType, String title, String headerText, String contentText)
/*    */   {
/* 16 */     super(alertType);
/* 17 */     this.app = app;
/* 18 */     initOwner(null);
/* 19 */     initModality(javafx.stage.Modality.APPLICATION_MODAL);
/* 20 */     if (!Utils.isMac())
/* 21 */       initStyle(StageStyle.UTILITY);
/* 22 */     setTitle(title);
/* 23 */     setHeaderText(headerText);
/* 24 */     setContentText(contentText);
/*    */   }
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/customview/LIWCAlert.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */