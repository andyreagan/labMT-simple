/*     */ package com.liwc.LIWC2015.controller;
/*     */ 
/*     */ import com.liwc.LIWC2015.App;
/*     */ import com.liwc.LIWC2015.LiwcPreferences;
/*     */ import com.liwc.LIWC2015.Utils;
/*     */ import com.liwc.LIWC2015.customview.ExceptionDialog;
/*     */ import com.liwc.LIWC2015.customview.FileChooserWrapper;
/*     */ import com.liwc.LIWC2015.model.DataSegment;
/*     */ import com.liwc.LIWC2015.model.ExcelRowSegment;
/*     */ import com.liwc.LIWC2015.model.ExcelRowSegment.Cell;
/*     */ import com.liwc.core.LanguageSettings;
/*     */ import com.liwc.core.Segment;
/*     */ import com.liwc.core.TextProcessor;
/*     */ import com.liwc.core.text.RawText;
/*     */ import com.liwc.core.text.TextParser;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.scene.control.TablePosition;
/*     */ import javafx.stage.FileChooser;
/*     */ import javafx.stage.FileChooser.ExtensionFilter;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExcelCsvAnalyzer
/*     */ {
/*  35 */   private static final Logger logger = LoggerFactory.getLogger(ExcelCsvAnalyzer.class);
/*     */   private App app;
/*     */   
/*     */   public ExcelCsvAnalyzer(App app)
/*     */   {
/*  40 */     this.app = app;
/*     */   }
/*     */   
/*     */   public void run() {
/*  44 */     FileChooserWrapper wr = new FileChooserWrapper();
/*  45 */     FileChooser fileChooser = wr.getFileChooser();
/*  46 */     fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Excel or CSV Files (*.xls, *.xlsx, *.csv)", new String[] { "*.xls", "*.xlsx", "*.csv" }));
/*  47 */     fileChooser.setTitle("Select Excel or CSV File");
/*  48 */     Utils.setInitialFolder(fileChooser, this.app.getLiwcPreferences().getLastVisitedFolder());
/*  49 */     this.app.setModalIsOpen(true);
/*  50 */     File file = wr.showOpenDialog();
/*  51 */     this.app.setModalIsOpen(false);
/*  52 */     ExcelCsvPreviewDialogController controller = null;
/*  53 */     if (file != null) {
/*     */       try {
/*  55 */         this.app.getLiwcPreferences().setLastVisitedFolder(file.getParent());
/*  56 */         controller = (ExcelCsvPreviewDialogController)ExcelCsvPreviewDialogController.run(this.app, "/com/liwc/LIWC2015/view/ExcelPreviewDialog.fxml", new Object[] { file });
/*     */       } catch (Exception e) {
/*  58 */         logger.error(e.getLocalizedMessage(), e);
/*  59 */         this.app.setModalIsOpen(true);
/*  60 */         new ExceptionDialog(this.app, e).showAndWait();
/*  61 */         this.app.setModalIsOpen(false);
/*     */       }
/*     */     }
/*  64 */     if ((controller != null) && (controller.isAnalyzeClicked())) {
/*     */       try {
/*  66 */         ExcelAnalyzerTask task = new ExcelAnalyzerTask(this.app, controller.getData(), controller.getSelectedCells(), null);
/*  67 */         ProgressDialogController.run(this.app, "/com/liwc/LIWC2015/view/ProgressDialog.fxml", new Object[] { task, Boolean.valueOf(true) });
/*  68 */         ObservableList<DataSegment> data = (ObservableList)task.get();
/*  69 */         AnalyzeTextPaneController analyzeTextPaneController = new AnalyzeTextPaneController(this.app);
/*  70 */         analyzeTextPaneController.buildFromExcelRowSegments(data, file, controller.getColumnWidths());
/*     */       } catch (Exception e) {
/*  72 */         logger.error(e.getLocalizedMessage(), e);
/*  73 */         this.app.setModalIsOpen(true);
/*  74 */         new ExceptionDialog(this.app, e).showAndWait();
/*  75 */         this.app.setModalIsOpen(false);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static String getColumnName(int index) {
/*  81 */     if (index < 26) {
/*  82 */       return new String(new char[] { (char)(65 + index) });
/*     */     }
/*  84 */     return new String(new char[] { (char)(65 + index / 26 - 1), (char)(65 + index % 26) });
/*     */   }
/*     */   
/*     */   public static int getColumnIndex(String name)
/*     */   {
/*  89 */     if (name.length() == 1) {
/*  90 */       return name.charAt(0) - 'A';
/*     */     }
/*  92 */     return (name.charAt(0) - 'A' + 1) * 26 + name.charAt(1) - 65;
/*     */   }
/*     */   
/*     */   private static class ExcelAnalyzerTask
/*     */     extends CancelableTask<ObservableList<DataSegment>>
/*     */   {
/*  98 */     private List<List<ExcelRowSegment.Cell>> sourceData = new ArrayList();
/*     */     private List<TablePosition> selectedCells;
/*     */     private App app;
/*     */     
/*     */     private ExcelAnalyzerTask(App app, ObservableList<List<String>> sourceData, List<TablePosition> selectedCells)
/*     */     {
/* 104 */       this.app = app;
/* 105 */       for (List<String> row : sourceData) {
/* 106 */         List<ExcelRowSegment.Cell> row1 = new ArrayList();
/* 107 */         for (String cell : row) {
/* 108 */           ExcelRowSegment.Cell cell1 = new ExcelRowSegment.Cell(cell);
/* 109 */           row1.add(cell1);
/*     */         }
/* 111 */         this.sourceData.add(row1);
/*     */       }
/* 113 */       for (TablePosition tp : selectedCells) {
/* 114 */         ExcelRowSegment.Cell cell = (ExcelRowSegment.Cell)((List)this.sourceData.get(tp.getRow())).get(tp.getColumn());
/* 115 */         cell.setSelected(true);
/*     */       }
/* 117 */       this.selectedCells = selectedCells;
/*     */     }
/*     */     
/*     */     protected ObservableList<DataSegment> call() throws Exception
/*     */     {
/* 122 */       ObservableList<DataSegment> data = FXCollections.observableArrayList();
/* 123 */       updateMessage("Processing...");
/* 124 */       updateProgress(0L, 1L);
/* 125 */       TextParser textParser = new TextParser(this.app.getActiveDictionary(), new LanguageSettings(this.app.getLiwcPreferences().getLocale()));
/* 126 */       TextProcessor textProcessor = Utils.getTextProcessor(this.app, false);
/* 127 */       for (int i = 0; i < this.sourceData.size(); i++) {
/* 128 */         data.add(new ExcelRowSegment((List)this.sourceData.get(i)));
/*     */       }
/* 130 */       for (int i = 0; i < this.selectedCells.size(); i++) {
/* 131 */         if (this.cancelRequested.get()) {
/*     */           break;
/*     */         }
/* 134 */         TablePosition tp = (TablePosition)this.selectedCells.get(i);
/* 135 */         String cellValue = ((ExcelRowSegment.Cell)((List)this.sourceData.get(tp.getRow())).get(tp.getColumn())).getValue();
/* 136 */         RawText text = new RawText(cellValue);
/* 137 */         List<Segment> segments = textProcessor.processText(text, textParser);
/* 138 */         if (segments.size() == 0)
/* 139 */           segments.add(new Segment(this.app.getActiveDictionary()));
/* 140 */         for (Segment segment : segments) {
/* 141 */           DataSegment dataSegment = (DataSegment)data.get(tp.getRow());
/* 142 */           if (dataSegment == null) {
/* 143 */             dataSegment = new ExcelRowSegment((List)this.sourceData.get(tp.getRow()));
/* 144 */             data.set(tp.getRow(), dataSegment);
/*     */           }
/* 146 */           ((ExcelRowSegment)dataSegment).addSegment(segment);
/*     */         }
/* 148 */         text.close();
/* 149 */         updateProgress(i + 1, this.selectedCells.size());
/*     */       }
/* 151 */       for (DataSegment dataSegment : data) {
/* 152 */         if (dataSegment.getSegment() != null)
/* 153 */           dataSegment.getSegment().optimize();
/*     */       }
/* 155 */       return data;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/ExcelCsvAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */