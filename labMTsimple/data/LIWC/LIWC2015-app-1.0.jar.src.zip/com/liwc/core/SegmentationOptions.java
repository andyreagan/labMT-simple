package com.liwc.core;

import java.util.regex.Pattern;

public class SegmentationOptions
{
  public static final int None = 0;
  public static final int BySegmentsNumber = 1;
  public static final int ByWords = 2;
  public static final int ByCustomDelimiter = 3;
  public static final int ByCustomPattern = 4;
  private int a = 0;
  private int b;
  private int c;
  private String d;
  private Pattern e;
  
  private SegmentationOptions(int paramInt1, int paramInt2)
  {
    this.a = paramInt1;
    switch (paramInt1)
    {
    case 1: 
      this.b = paramInt2;
      return;
    case 2: 
      this.c = paramInt2;
      return;
    }
    this.a = 0;
  }
  
  private SegmentationOptions(int paramInt, String paramString)
  {
    this.a = 3;
    this.d = paramString;
  }
  
  private SegmentationOptions(int paramInt, Pattern paramPattern)
  {
    this.a = 4;
    this.e = paramPattern;
  }
  
  public static SegmentationOptions noSegmentation()
  {
    return new SegmentationOptions(0, 0);
  }
  
  public static SegmentationOptions segmentationByNumber(int paramInt)
  {
    return new SegmentationOptions(1, paramInt);
  }
  
  public static SegmentationOptions segmentationByWords(int paramInt)
  {
    return new SegmentationOptions(2, paramInt);
  }
  
  public static SegmentationOptions segmentationByCustomDelimiter(String paramString)
  {
    return new SegmentationOptions(3, paramString);
  }
  
  public static SegmentationOptions segmentationByCustomPattern(Pattern paramPattern)
  {
    return new SegmentationOptions(4, paramPattern);
  }
  
  public int getType()
  {
    return this.a;
  }
  
  public int getNumberOfSegments()
  {
    return this.b;
  }
  
  public int getWords()
  {
    return this.c;
  }
  
  public String getCustomDelimiter()
  {
    return this.d;
  }
  
  public Pattern getCustomPattern()
  {
    return this.e;
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/core/SegmentationOptions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */