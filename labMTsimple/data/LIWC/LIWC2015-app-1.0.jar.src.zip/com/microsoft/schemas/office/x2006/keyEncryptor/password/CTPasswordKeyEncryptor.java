package com.microsoft.schemas.office.x2006.keyEncryptor.password;

import com.microsoft.schemas.office.x2006.encryption.STBlockSize;
import com.microsoft.schemas.office.x2006.encryption.STCipherAlgorithm;
import com.microsoft.schemas.office.x2006.encryption.STCipherAlgorithm.Enum;
import com.microsoft.schemas.office.x2006.encryption.STCipherChaining;
import com.microsoft.schemas.office.x2006.encryption.STCipherChaining.Enum;
import com.microsoft.schemas.office.x2006.encryption.STHashAlgorithm;
import com.microsoft.schemas.office.x2006.encryption.STHashAlgorithm.Enum;
import com.microsoft.schemas.office.x2006.encryption.STHashSize;
import com.microsoft.schemas.office.x2006.encryption.STKeyBits;
import com.microsoft.schemas.office.x2006.encryption.STSaltSize;
import com.microsoft.schemas.office.x2006.encryption.STSpinCount;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.SchemaTypeSystem;
import org.apache.xmlbeans.XmlBase64Binary;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public abstract interface CTPasswordKeyEncryptor
  extends XmlObject
{
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CTPasswordKeyEncryptor.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0B482D0B338CC9641C1543C3510577FE").resolveHandle("ctpasswordkeyencryptorde24type");
  
  public abstract int getSaltSize();
  
  public abstract STSaltSize xgetSaltSize();
  
  public abstract void setSaltSize(int paramInt);
  
  public abstract void xsetSaltSize(STSaltSize paramSTSaltSize);
  
  public abstract int getBlockSize();
  
  public abstract STBlockSize xgetBlockSize();
  
  public abstract void setBlockSize(int paramInt);
  
  public abstract void xsetBlockSize(STBlockSize paramSTBlockSize);
  
  public abstract long getKeyBits();
  
  public abstract STKeyBits xgetKeyBits();
  
  public abstract void setKeyBits(long paramLong);
  
  public abstract void xsetKeyBits(STKeyBits paramSTKeyBits);
  
  public abstract int getHashSize();
  
  public abstract STHashSize xgetHashSize();
  
  public abstract void setHashSize(int paramInt);
  
  public abstract void xsetHashSize(STHashSize paramSTHashSize);
  
  public abstract STCipherAlgorithm.Enum getCipherAlgorithm();
  
  public abstract STCipherAlgorithm xgetCipherAlgorithm();
  
  public abstract void setCipherAlgorithm(STCipherAlgorithm.Enum paramEnum);
  
  public abstract void xsetCipherAlgorithm(STCipherAlgorithm paramSTCipherAlgorithm);
  
  public abstract STCipherChaining.Enum getCipherChaining();
  
  public abstract STCipherChaining xgetCipherChaining();
  
  public abstract void setCipherChaining(STCipherChaining.Enum paramEnum);
  
  public abstract void xsetCipherChaining(STCipherChaining paramSTCipherChaining);
  
  public abstract STHashAlgorithm.Enum getHashAlgorithm();
  
  public abstract STHashAlgorithm xgetHashAlgorithm();
  
  public abstract void setHashAlgorithm(STHashAlgorithm.Enum paramEnum);
  
  public abstract void xsetHashAlgorithm(STHashAlgorithm paramSTHashAlgorithm);
  
  public abstract byte[] getSaltValue();
  
  public abstract XmlBase64Binary xgetSaltValue();
  
  public abstract void setSaltValue(byte[] paramArrayOfByte);
  
  public abstract void xsetSaltValue(XmlBase64Binary paramXmlBase64Binary);
  
  public abstract int getSpinCount();
  
  public abstract STSpinCount xgetSpinCount();
  
  public abstract void setSpinCount(int paramInt);
  
  public abstract void xsetSpinCount(STSpinCount paramSTSpinCount);
  
  public abstract byte[] getEncryptedVerifierHashInput();
  
  public abstract XmlBase64Binary xgetEncryptedVerifierHashInput();
  
  public abstract void setEncryptedVerifierHashInput(byte[] paramArrayOfByte);
  
  public abstract void xsetEncryptedVerifierHashInput(XmlBase64Binary paramXmlBase64Binary);
  
  public abstract byte[] getEncryptedVerifierHashValue();
  
  public abstract XmlBase64Binary xgetEncryptedVerifierHashValue();
  
  public abstract void setEncryptedVerifierHashValue(byte[] paramArrayOfByte);
  
  public abstract void xsetEncryptedVerifierHashValue(XmlBase64Binary paramXmlBase64Binary);
  
  public abstract byte[] getEncryptedKeyValue();
  
  public abstract XmlBase64Binary xgetEncryptedKeyValue();
  
  public abstract void setEncryptedKeyValue(byte[] paramArrayOfByte);
  
  public abstract void xsetEncryptedKeyValue(XmlBase64Binary paramXmlBase64Binary);
  
  public static final class Factory
  {
    public static CTPasswordKeyEncryptor newInstance()
    {
      return (CTPasswordKeyEncryptor)XmlBeans.getContextTypeLoader().newInstance(CTPasswordKeyEncryptor.type, null);
    }
    
    public static CTPasswordKeyEncryptor newInstance(XmlOptions paramXmlOptions)
    {
      return (CTPasswordKeyEncryptor)XmlBeans.getContextTypeLoader().newInstance(CTPasswordKeyEncryptor.type, paramXmlOptions);
    }
    
    public static CTPasswordKeyEncryptor parse(String paramString)
      throws XmlException
    {
      return (CTPasswordKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramString, CTPasswordKeyEncryptor.type, null);
    }
    
    public static CTPasswordKeyEncryptor parse(String paramString, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (CTPasswordKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramString, CTPasswordKeyEncryptor.type, paramXmlOptions);
    }
    
    public static CTPasswordKeyEncryptor parse(File paramFile)
      throws XmlException, IOException
    {
      return (CTPasswordKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramFile, CTPasswordKeyEncryptor.type, null);
    }
    
    public static CTPasswordKeyEncryptor parse(File paramFile, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTPasswordKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramFile, CTPasswordKeyEncryptor.type, paramXmlOptions);
    }
    
    public static CTPasswordKeyEncryptor parse(URL paramURL)
      throws XmlException, IOException
    {
      return (CTPasswordKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramURL, CTPasswordKeyEncryptor.type, null);
    }
    
    public static CTPasswordKeyEncryptor parse(URL paramURL, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTPasswordKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramURL, CTPasswordKeyEncryptor.type, paramXmlOptions);
    }
    
    public static CTPasswordKeyEncryptor parse(InputStream paramInputStream)
      throws XmlException, IOException
    {
      return (CTPasswordKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramInputStream, CTPasswordKeyEncryptor.type, null);
    }
    
    public static CTPasswordKeyEncryptor parse(InputStream paramInputStream, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTPasswordKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramInputStream, CTPasswordKeyEncryptor.type, paramXmlOptions);
    }
    
    public static CTPasswordKeyEncryptor parse(Reader paramReader)
      throws XmlException, IOException
    {
      return (CTPasswordKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramReader, CTPasswordKeyEncryptor.type, null);
    }
    
    public static CTPasswordKeyEncryptor parse(Reader paramReader, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTPasswordKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramReader, CTPasswordKeyEncryptor.type, paramXmlOptions);
    }
    
    public static CTPasswordKeyEncryptor parse(XMLStreamReader paramXMLStreamReader)
      throws XmlException
    {
      return (CTPasswordKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, CTPasswordKeyEncryptor.type, null);
    }
    
    public static CTPasswordKeyEncryptor parse(XMLStreamReader paramXMLStreamReader, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (CTPasswordKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, CTPasswordKeyEncryptor.type, paramXmlOptions);
    }
    
    public static CTPasswordKeyEncryptor parse(Node paramNode)
      throws XmlException
    {
      return (CTPasswordKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramNode, CTPasswordKeyEncryptor.type, null);
    }
    
    public static CTPasswordKeyEncryptor parse(Node paramNode, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (CTPasswordKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramNode, CTPasswordKeyEncryptor.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static CTPasswordKeyEncryptor parse(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return (CTPasswordKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, CTPasswordKeyEncryptor.type, null);
    }
    
    /**
     * @deprecated
     */
    public static CTPasswordKeyEncryptor parse(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return (CTPasswordKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, CTPasswordKeyEncryptor.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, CTPasswordKeyEncryptor.type, null);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, CTPasswordKeyEncryptor.type, paramXmlOptions);
    }
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/keyEncryptor/password/CTPasswordKeyEncryptor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */