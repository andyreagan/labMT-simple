package com.microsoft.schemas.office.x2006.digsig;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.SchemaTypeSystem;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public abstract interface SignatureInfoV1Document
  extends XmlObject
{
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(SignatureInfoV1Document.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0B482D0B338CC9641C1543C3510577FE").resolveHandle("signatureinfov14a6bdoctype");
  
  public abstract CTSignatureInfoV1 getSignatureInfoV1();
  
  public abstract void setSignatureInfoV1(CTSignatureInfoV1 paramCTSignatureInfoV1);
  
  public abstract CTSignatureInfoV1 addNewSignatureInfoV1();
  
  public static final class Factory
  {
    public static SignatureInfoV1Document newInstance()
    {
      return (SignatureInfoV1Document)XmlBeans.getContextTypeLoader().newInstance(SignatureInfoV1Document.type, null);
    }
    
    public static SignatureInfoV1Document newInstance(XmlOptions paramXmlOptions)
    {
      return (SignatureInfoV1Document)XmlBeans.getContextTypeLoader().newInstance(SignatureInfoV1Document.type, paramXmlOptions);
    }
    
    public static SignatureInfoV1Document parse(String paramString)
      throws XmlException
    {
      return (SignatureInfoV1Document)XmlBeans.getContextTypeLoader().parse(paramString, SignatureInfoV1Document.type, null);
    }
    
    public static SignatureInfoV1Document parse(String paramString, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (SignatureInfoV1Document)XmlBeans.getContextTypeLoader().parse(paramString, SignatureInfoV1Document.type, paramXmlOptions);
    }
    
    public static SignatureInfoV1Document parse(File paramFile)
      throws XmlException, IOException
    {
      return (SignatureInfoV1Document)XmlBeans.getContextTypeLoader().parse(paramFile, SignatureInfoV1Document.type, null);
    }
    
    public static SignatureInfoV1Document parse(File paramFile, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (SignatureInfoV1Document)XmlBeans.getContextTypeLoader().parse(paramFile, SignatureInfoV1Document.type, paramXmlOptions);
    }
    
    public static SignatureInfoV1Document parse(URL paramURL)
      throws XmlException, IOException
    {
      return (SignatureInfoV1Document)XmlBeans.getContextTypeLoader().parse(paramURL, SignatureInfoV1Document.type, null);
    }
    
    public static SignatureInfoV1Document parse(URL paramURL, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (SignatureInfoV1Document)XmlBeans.getContextTypeLoader().parse(paramURL, SignatureInfoV1Document.type, paramXmlOptions);
    }
    
    public static SignatureInfoV1Document parse(InputStream paramInputStream)
      throws XmlException, IOException
    {
      return (SignatureInfoV1Document)XmlBeans.getContextTypeLoader().parse(paramInputStream, SignatureInfoV1Document.type, null);
    }
    
    public static SignatureInfoV1Document parse(InputStream paramInputStream, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (SignatureInfoV1Document)XmlBeans.getContextTypeLoader().parse(paramInputStream, SignatureInfoV1Document.type, paramXmlOptions);
    }
    
    public static SignatureInfoV1Document parse(Reader paramReader)
      throws XmlException, IOException
    {
      return (SignatureInfoV1Document)XmlBeans.getContextTypeLoader().parse(paramReader, SignatureInfoV1Document.type, null);
    }
    
    public static SignatureInfoV1Document parse(Reader paramReader, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (SignatureInfoV1Document)XmlBeans.getContextTypeLoader().parse(paramReader, SignatureInfoV1Document.type, paramXmlOptions);
    }
    
    public static SignatureInfoV1Document parse(XMLStreamReader paramXMLStreamReader)
      throws XmlException
    {
      return (SignatureInfoV1Document)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, SignatureInfoV1Document.type, null);
    }
    
    public static SignatureInfoV1Document parse(XMLStreamReader paramXMLStreamReader, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (SignatureInfoV1Document)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, SignatureInfoV1Document.type, paramXmlOptions);
    }
    
    public static SignatureInfoV1Document parse(Node paramNode)
      throws XmlException
    {
      return (SignatureInfoV1Document)XmlBeans.getContextTypeLoader().parse(paramNode, SignatureInfoV1Document.type, null);
    }
    
    public static SignatureInfoV1Document parse(Node paramNode, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (SignatureInfoV1Document)XmlBeans.getContextTypeLoader().parse(paramNode, SignatureInfoV1Document.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static SignatureInfoV1Document parse(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return (SignatureInfoV1Document)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, SignatureInfoV1Document.type, null);
    }
    
    /**
     * @deprecated
     */
    public static SignatureInfoV1Document parse(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return (SignatureInfoV1Document)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, SignatureInfoV1Document.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, SignatureInfoV1Document.type, null);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, SignatureInfoV1Document.type, paramXmlOptions);
    }
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/digsig/SignatureInfoV1Document.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */