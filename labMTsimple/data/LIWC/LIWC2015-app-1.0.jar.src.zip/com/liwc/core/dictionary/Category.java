package com.liwc.core.dictionary;

import java.util.ArrayList;
import java.util.List;

public class Category
{
  private int a;
  private String b;
  private String c;
  private List d;
  
  public Category(int paramInt, String paramString1, String paramString2)
  {
    this.a = paramInt;
    this.b = paramString1;
    this.c = paramString2;
  }
  
  public Category(int paramInt, String paramString)
  {
    this(paramInt, paramString, null);
  }
  
  public void addKid(Category paramCategory)
  {
    if (this.d == null) {
      this.d = new ArrayList();
    }
    this.d.add(paramCategory);
  }
  
  public List getKids()
  {
    return this.d;
  }
  
  public int getId()
  {
    return this.a;
  }
  
  public String getName()
  {
    return this.b;
  }
  
  public String getDescription()
  {
    return this.c;
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/core/dictionary/Category.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */