/*     */ package com.liwc.LIWC2015.controller;
/*     */ 
/*     */ import com.liwc.LIWC2015.App;
/*     */ import com.liwc.LIWC2015.LiwcPreferences;
/*     */ import com.liwc.LIWC2015.LiwcPreferences.Categories;
/*     */ import com.liwc.core.dictionary.Category;
/*     */ import com.liwc.core.dictionary.IDictionary;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.ResourceBundle;
/*     */ import javafx.beans.property.BooleanProperty;
/*     */ import javafx.beans.property.DoubleProperty;
/*     */ import javafx.beans.property.ReadOnlyDoubleProperty;
/*     */ import javafx.beans.value.ChangeListener;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.fxml.FXML;
/*     */ import javafx.geometry.Insets;
/*     */ import javafx.scene.Node;
/*     */ import javafx.scene.Scene;
/*     */ import javafx.scene.control.CheckBox;
/*     */ import javafx.scene.control.Label;
/*     */ import javafx.scene.control.ScrollPane;
/*     */ import javafx.scene.layout.HBox;
/*     */ import javafx.scene.layout.VBox;
/*     */ import javafx.scene.text.Font;
/*     */ import javafx.scene.text.FontWeight;
/*     */ import javafx.stage.Modality;
/*     */ import javafx.stage.Stage;
/*     */ 
/*     */ public class CategoriesDialogController extends ModalDialogController implements javafx.fxml.Initializable
/*     */ {
/*     */   @FXML
/*     */   private VBox vBox;
/*     */   @FXML
/*     */   private VBox leftBox;
/*     */   @FXML
/*     */   private VBox rightBox;
/*     */   @FXML
/*     */   private VBox commonBox;
/*     */   @FXML
/*     */   private ScrollPane scrollPane;
/*     */   @FXML
/*     */   private HBox punctuationMarksBox;
/*     */   @FXML
/*     */   private HBox genericsBox;
/*  50 */   private List<CheckBox> boxes = new ArrayList();
/*     */   
/*     */   public void initialize(URL location, ResourceBundle resources)
/*     */   {
/*  54 */     this.commonBox.prefWidthProperty().bind(this.scrollPane.widthProperty().subtract(16));
/*     */   }
/*     */   
/*     */   public void onCancel() {
/*  58 */     this.stage.close();
/*     */   }
/*     */   
/*     */   public void onOK() {
/*  62 */     this.app.getLiwcPreferences().getCategories().setSelectAll(false);
/*  63 */     this.app.getLiwcPreferences().getCategories().setCategories(new ArrayList());
/*  64 */     for (CheckBox box : this.boxes) {
/*  65 */       if (box.getUserData().equals("WC")) {
/*  66 */         this.app.getLiwcPreferences().getCategories().setShowWc(box.isSelected());
/*  67 */       } else if (box.getUserData().equals("WPS")) {
/*  68 */         this.app.getLiwcPreferences().getCategories().setShowWps(box.isSelected());
/*  69 */       } else if (box.getUserData().equals("Sixltr")) {
/*  70 */         this.app.getLiwcPreferences().getCategories().setShowSixltr(box.isSelected());
/*  71 */       } else if (box.getUserData().equals("Dic")) {
/*  72 */         this.app.getLiwcPreferences().getCategories().setShowDic(box.isSelected());
/*  73 */       } else if (box.getUserData().equals("Analytic")) {
/*  74 */         this.app.getLiwcPreferences().getCategories().setShowAnalytic(box.isSelected());
/*  75 */       } else if (box.getUserData().equals("Clout")) {
/*  76 */         this.app.getLiwcPreferences().getCategories().setShowClout(box.isSelected());
/*  77 */       } else if (box.getUserData().equals("Authentic")) {
/*  78 */         this.app.getLiwcPreferences().getCategories().setShowAuthentic(box.isSelected());
/*  79 */       } else if (box.getUserData().equals("Tone")) {
/*  80 */         this.app.getLiwcPreferences().getCategories().setShowTone(box.isSelected());
/*  81 */       } else if (box.isSelected())
/*  82 */         this.app.getLiwcPreferences().getCategories().getCategories().add((String)box.getUserData());
/*     */     }
/*  84 */     this.app.getWelcomeScreenModel().setAllCategoriesOn(WelcomeScreenController.buildCategoriesString(this.app.getLiwcPreferences().getCategories(), this.app.getActiveDictionary()));
/*  85 */     this.stage.close();
/*     */   }
/*     */   
/*     */   public void onSelectAll() {
/*  89 */     for (CheckBox box : this.boxes) {
/*  90 */       box.setSelected(!box.isDisabled());
/*     */     }
/*     */   }
/*     */   
/*     */   public void onSelectNone() {
/*  95 */     for (CheckBox box : this.boxes) {
/*  96 */       box.setSelected(false);
/*     */     }
/*     */   }
/*     */   
/*     */   public Stage initStage(App app, Object... args) throws Exception
/*     */   {
/* 102 */     Scene newScene = new Scene(this.vBox);
/* 103 */     Stage stage = new Stage();
/* 104 */     stage.setScene(newScene);
/* 105 */     stage.setResizable(false);
/* 106 */     stage.initModality(Modality.APPLICATION_MODAL);
/* 107 */     if (!com.liwc.LIWC2015.Utils.isMac())
/* 108 */       stage.initStyle(javafx.stage.StageStyle.UTILITY);
/* 109 */     stage.initOwner(null);
/* 110 */     stage.setTitle("Categories");
/*     */     
/* 112 */     IDictionary dictionary = app.getActiveDictionary();
/* 113 */     boolean plainCategoriesStructure = dictionary.getCategoriesPlain().size() == dictionary.getCategoriesTree().size();
/* 114 */     List<Category> categories = dictionary.getCategoriesTree();
/* 115 */     List<VBox> vBoxes = new ArrayList();
/* 116 */     for (Iterator localIterator = categories.iterator(); localIterator.hasNext();) { cat = (Category)localIterator.next();
/* 117 */       vBoxes.add(getCategoriesBox(cat, plainCategoriesStructure)); }
/*     */     Category cat;
/* 119 */     int checkBoxesTotal = 0;
/* 120 */     for (VBox b : vBoxes) {
/* 121 */       checkBoxesTotal += b.getChildren().size();
/*     */     }
/*     */     
/* 124 */     if (plainCategoriesStructure) {
/* 125 */       this.leftBox.setSpacing(4.0D);
/* 126 */       this.rightBox.setSpacing(4.0D);
/*     */     }
/*     */     
/* 129 */     int leftSize = 0;
/* 130 */     int rightSize = checkBoxesTotal;
/* 131 */     for (int i = 0; 
/* 132 */         i < vBoxes.size(); i++) {
/* 133 */       int ls = leftSize + ((VBox)vBoxes.get(i)).getChildren().size();
/* 134 */       int rs = checkBoxesTotal - ls;
/* 135 */       if (Math.abs(leftSize - rightSize) < Math.abs(ls - rs)) {
/*     */         break;
/*     */       }
/* 138 */       leftSize = ls;
/* 139 */       rightSize = rs;
/*     */     }
/*     */     
/* 142 */     this.leftBox.getChildren().addAll(vBoxes.subList(0, i));
/* 143 */     this.rightBox.getChildren().addAll(vBoxes.subList(i, vBoxes.size()));
/*     */     
/* 145 */     this.punctuationMarksBox.getChildren().addAll(new Node[] { getPunctuationsMarksBox() });
/* 146 */     this.genericsBox.getChildren().addAll(new Node[] { getGenericsBox() });
/*     */     
/* 148 */     return stage;
/*     */   }
/*     */   
/*     */   private VBox getCategoriesBox(final Category category, boolean plainCategoriesStructure)
/*     */   {
/* 153 */     VBox vBox = new VBox();
/* 154 */     vBox.setSpacing(4.0D);
/* 155 */     this.boxes.addAll(getCategoriesCheckBoxes(new ArrayList() {}, 0, vBox, plainCategoriesStructure));
/*     */     
/*     */ 
/* 158 */     return vBox;
/*     */   }
/*     */   
/*     */   private VBox getPunctuationsMarksBox() {
/* 162 */     VBox vBox = new VBox();
/* 163 */     vBox.setSpacing(4.0D);
/* 164 */     this.boxes.addAll(getPunctuationMarksCheckBoxes(vBox));
/* 165 */     return vBox;
/*     */   }
/*     */   
/*     */   private VBox getGenericsBox() {
/* 169 */     VBox vBox = new VBox();
/* 170 */     vBox.setSpacing(4.0D);
/* 171 */     this.boxes.addAll(getGenericCheckBoxes(vBox));
/* 172 */     return vBox;
/*     */   }
/*     */   
/*     */   private List<CheckBox> getCategoriesCheckBoxes(List<Category> categories, int level, VBox addTo, boolean plainCategoriesStructure) {
/* 176 */     List<CheckBox> boxes = new ArrayList();
/* 177 */     for (Category cat : categories) {
/* 178 */       VBox vBox = new VBox();
/* 179 */       vBox.setPadding(new Insets(0.0D, 0.0D, 0.0D, level * 24));
/* 180 */       CheckBox cb = new CheckBox();
/* 181 */       if ((level == 0) && (!plainCategoriesStructure)) {
/* 182 */         Font f = Font.font(cb.getFont().getFamily(), FontWeight.BOLD, cb.getFont().getSize());
/* 183 */         cb.setFont(f);
/*     */       }
/* 185 */       boxes.add(cb);
/* 186 */       cb.setText((cat.getDescription() == null) || (cat.getDescription().length() == 0) ? cat.getName() : String.format("%s (%s)", new Object[] { cat.getName(), cat.getDescription() }));
/* 187 */       cb.setUserData(cat.getName());
/* 188 */       cb.setSelected(this.app.getLiwcPreferences().getCategories().showParam(cat.getName()));
/* 189 */       vBox.getChildren().add(cb);
/* 190 */       addTo.getChildren().add(vBox);
/* 191 */       if (cat.getKids() != null) {
/* 192 */         final List<CheckBox> internalBoxes = getCategoriesCheckBoxes(cat.getKids(), level + 1, addTo, plainCategoriesStructure);
/* 193 */         cb.selectedProperty().addListener(new ChangeListener()
/*     */         {
/*     */           public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
/* 196 */             for (CheckBox internalBox : internalBoxes) {
/* 197 */               internalBox.setSelected(((Boolean)observable.getValue()).booleanValue());
/*     */             }
/*     */           }
/* 200 */         });
/* 201 */         boxes.addAll(internalBoxes);
/*     */       }
/*     */     }
/* 204 */     return boxes;
/*     */   }
/*     */   
/*     */   private List<CheckBox> getPunctuationMarksCheckBoxes(VBox addTo) {
/* 208 */     List<CheckBox> boxes = new ArrayList();
/* 209 */     VBox box = new VBox();
/* 210 */     box.setPadding(new Insets(0.0D, 0.0D, 0.0D, 0.0D));
/* 211 */     CheckBox cb = new CheckBox();
/* 212 */     Font f = Font.font(cb.getFont().getFamily(), FontWeight.BOLD, cb.getFont().getSize());
/* 213 */     cb.setFont(f);
/* 214 */     boxes.add(cb);
/* 215 */     cb.setText("Punctuation marks");
/* 216 */     cb.setUserData("AllPunc");
/* 217 */     cb.setSelected((this.app.getLiwcPreferences().getCategories().getSelectAll()) || (this.app.getLiwcPreferences().getCategories().getCategories().contains("AllPunc")));
/* 218 */     box.getChildren().add(cb);
/* 219 */     addTo.getChildren().add(box);
/* 220 */     final List<CheckBox> internalBoxes = new ArrayList();
/* 221 */     for (String pm : IDictionary.PunctuationMarksCategories.values()) {
/* 222 */       box = new VBox();
/* 223 */       box.setPadding(new Insets(0.0D, 0.0D, 0.0D, 24.0D));
/* 224 */       cb = new CheckBox();
/* 225 */       internalBoxes.add(cb);
/* 226 */       cb.setText(pm);
/* 227 */       cb.setUserData(pm);
/* 228 */       cb.setSelected(this.app.getLiwcPreferences().getCategories().showParam(pm));
/* 229 */       box.getChildren().add(cb);
/* 230 */       addTo.getChildren().add(box);
/*     */     }
/* 232 */     ((CheckBox)boxes.get(0)).selectedProperty().addListener(new ChangeListener()
/*     */     {
/*     */       public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
/* 235 */         for (CheckBox internalBox : internalBoxes) {
/* 236 */           internalBox.setSelected(((Boolean)observable.getValue()).booleanValue());
/*     */         }
/*     */       }
/* 239 */     });
/* 240 */     boxes.addAll(internalBoxes);
/* 241 */     return boxes;
/*     */   }
/*     */   
/*     */   private List<CheckBox> getGenericCheckBoxes(VBox addTo) {
/* 245 */     List<CheckBox> boxes = new ArrayList();
/* 246 */     VBox box = new VBox();
/* 247 */     box.setPadding(new Insets(0.0D, 0.0D, 0.0D, 0.0D));
/* 248 */     Label label = new Label("Summary Dimensions");
/* 249 */     Font f = Font.font(label.getFont().getFamily(), FontWeight.BOLD, label.getFont().getSize());
/* 250 */     label.setFont(f);
/* 251 */     box.getChildren().add(label);
/* 252 */     addTo.getChildren().add(box);
/*     */     
/* 254 */     LiwcPreferences.Categories categories = this.app.getLiwcPreferences().getCategories();
/* 255 */     addTo.getChildren().addAll(new Node[] { getSingleGenericBox("WC", "Total words count", categories.showParam("WC"), false, boxes) });
/* 256 */     boolean disabled = !"LIWC2015".equals(this.app.getLiwcPreferences().getDictionaryId());
/* 257 */     addTo.getChildren().addAll(new Node[] { getSingleGenericBox("Analytic", null, categories.showParam("Analytic"), disabled, boxes) });
/* 258 */     addTo.getChildren().addAll(new Node[] { getSingleGenericBox("Clout", null, categories.showParam("Clout"), disabled, boxes) });
/* 259 */     addTo.getChildren().addAll(new Node[] { getSingleGenericBox("Authentic", null, categories.showParam("Authentic"), disabled, boxes) });
/* 260 */     addTo.getChildren().addAll(new Node[] { getSingleGenericBox("Tone", null, categories.showParam("Tone"), disabled, boxes) });
/* 261 */     addTo.getChildren().addAll(new Node[] { getSingleGenericBox("WPS", "Words per sentence", categories.showParam("WPS"), false, boxes) });
/* 262 */     addTo.getChildren().addAll(new Node[] { getSingleGenericBox("Sixltr", "Words longer than 6 letters", categories.showParam("Sixltr"), false, boxes) });
/* 263 */     addTo.getChildren().addAll(new Node[] { getSingleGenericBox("Dic", "Dictionary words count", categories.showParam("Dic"), false, boxes) });
/*     */     
/* 265 */     return boxes;
/*     */   }
/*     */   
/*     */   private VBox getSingleGenericBox(String id, String name, boolean selected, boolean disabled, List<CheckBox> boxes) {
/* 269 */     VBox box = new VBox();
/* 270 */     box.setPadding(new Insets(0.0D, 0.0D, 0.0D, 24.0D));
/*     */     
/* 272 */     CheckBox cb = new CheckBox();
/* 273 */     cb.setText(id + (name == null ? "" : new StringBuilder().append(" (").append(name).append(")").toString()));
/* 274 */     cb.setUserData(id);
/* 275 */     cb.setSelected(selected);
/* 276 */     cb.setDisable(disabled);
/*     */     
/* 278 */     boxes.add(cb);
/* 279 */     box.getChildren().add(cb);
/*     */     
/* 281 */     return box;
/*     */   }
/*     */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/CategoriesDialogController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */