/*     */ package com.liwc.LIWC2015.controller;
/*     */ 
/*     */ import com.liwc.LIWC2015.App;
/*     */ import com.liwc.LIWC2015.LiwcPreferences;
/*     */ import com.liwc.LIWC2015.Utils;
/*     */ import com.liwc.LIWC2015.customview.DirectoryChooserWrapper;
/*     */ import com.liwc.LIWC2015.customview.ExceptionDialog;
/*     */ import com.liwc.LIWC2015.customview.FileChooserWrapper;
/*     */ import com.liwc.LIWC2015.customview.LIWCAlert;
/*     */ import com.liwc.LIWC2015.model.DataSegment;
/*     */ import com.liwc.LIWC2015.model.TextFileSegment;
/*     */ import com.liwc.core.LanguageSettings;
/*     */ import com.liwc.core.Segment;
/*     */ import com.liwc.core.TextProcessor;
/*     */ import com.liwc.core.text.IText;
/*     */ import com.liwc.core.text.TextFactory;
/*     */ import com.liwc.core.text.TextParser;
/*     */ import java.io.File;
/*     */ import java.io.FileFilter;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import javafx.collections.FXCollections;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.scene.control.Alert.AlertType;
/*     */ import javafx.scene.control.ButtonType;
/*     */ import javafx.stage.DirectoryChooser;
/*     */ import javafx.stage.FileChooser;
/*     */ import javafx.stage.FileChooser.ExtensionFilter;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ public class TextAnalyzer
/*     */ {
/*     */   public static final int AnalyzeText = 0;
/*     */   public static final int AnalyzeTextInFolder = 1;
/*     */   public static final int AnalyzeTextInFolderRecursively = 2;
/*  41 */   private static final Logger logger = LoggerFactory.getLogger(TextAnalyzer.class);
/*     */   private App app;
/*     */   
/*     */   public TextAnalyzer(App app)
/*     */   {
/*  46 */     this.app = app;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void run(int type)
/*     */   {
/*  54 */     String initialFolder = this.app.getLiwcPreferences().getLastVisitedFolder();
/*     */     
/*  56 */     List<File> files = null;
/*  57 */     File folder = null;
/*  58 */     switch (type) {
/*     */     case 0: 
/*  60 */       FileChooserWrapper wr = new FileChooserWrapper();
/*  61 */       FileChooser fileChooser = wr.getFileChooser();
/*  62 */       fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("All Text Documents (*.txt, *.doc, *.docx, *.rtf, *.pdf)", new String[] { "*.txt", "*.doc", "*.docx", "*.rtf", "*.pdf" }));
/*  63 */       fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text Files (*.txt)", new String[] { "*.txt" }));
/*  64 */       fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Word Documents (*.doc, *.docx)", new String[] { "*.doc", "*.docx" }));
/*  65 */       fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("RTF Documents (*.rtf)", new String[] { "*.rtf" }));
/*  66 */       fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PDF Documents (*.pdf)", new String[] { "*.pdf" }));
/*  67 */       fileChooser.setTitle("Select Text Files");
/*  68 */       Utils.setInitialFolder(fileChooser, initialFolder);
/*  69 */       this.app.setModalIsOpen(true);
/*  70 */       files = wr.showOpenMultipleDialog();
/*  71 */       this.app.setModalIsOpen(false);
/*     */       
/*  73 */       break;
/*     */     case 1: 
/*  75 */       DirectoryChooserWrapper wr = new DirectoryChooserWrapper();
/*  76 */       DirectoryChooser directoryChooser = wr.getDirectoryChooser();
/*  77 */       directoryChooser.setTitle("Select Text Files Folder");
/*  78 */       this.app.setModalIsOpen(true);
/*  79 */       Utils.setInitialFolder(directoryChooser, initialFolder);
/*  80 */       folder = wr.showDialog();
/*  81 */       this.app.setModalIsOpen(false);
/*  82 */       if (folder != null) {
/*  83 */         files = new ArrayList();
/*  84 */         files.add(folder);
/*     */       }
/*     */       
/*  87 */       break;
/*     */     }
/*     */     
/*     */     
/*     */ 
/*     */ 
/*  93 */     if (files != null) {
/*     */       try {
/*  95 */         if (files.size() > 0)
/*  96 */           this.app.getLiwcPreferences().setLastVisitedFolder(((File)files.get(0)).getParent());
/*  97 */         if (type == 1) {
/*  98 */           LIWCAlert confirm = new LIWCAlert(this.app, Alert.AlertType.CONFIRMATION, "LIWC2015", null, "Do you want to include subfolders?");
/*  99 */           ButtonType yesBtn = new ButtonType("Yes");
/* 100 */           ButtonType noBtn = new ButtonType("No");
/* 101 */           confirm.getButtonTypes().setAll(new ButtonType[] { yesBtn, noBtn });
/* 102 */           this.app.setModalIsOpen(true);
/* 103 */           Optional<ButtonType> returned = confirm.showAndWait();
/* 104 */           this.app.setModalIsOpen(false);
/* 105 */           if (returned.get() == yesBtn)
/* 106 */             type = 2;
/*     */         }
/* 108 */         TextAnalyzerTask task = new TextAnalyzerTask(this.app, files, type);
/* 109 */         ProgressDialogController.run(this.app, "/com/liwc/LIWC2015/view/ProgressDialog.fxml", new Object[] { task, Boolean.valueOf(true) });
/* 110 */         TextAnalyzerResult result = (TextAnalyzerResult)task.get();
/* 111 */         AnalyzeTextPaneController analyzeTextPaneController = new AnalyzeTextPaneController(this.app);
/*     */         
/* 113 */         String title = "";
/* 114 */         int fileCounter = result.getFileCounter();
/* 115 */         if (type == 0) {
/* 116 */           title = Utils.getFilenameWithoutExtension((File)files.get(0)) + " - " + Utils.getFilenameWithoutExtension((File)files.get(files.size() - 1)) + " (" + fileCounter + " " + "files" + ")";
/* 117 */         } else if (folder != null) {
/* 118 */           title = folder.getName() + " (" + fileCounter + " " + "files" + ")";
/*     */         }
/* 120 */         analyzeTextPaneController.buildFromTextFileSegments(result.getData(), result.getFileCounter(), title);
/* 121 */         if (task.hasErrors())
/* 122 */           Utils.showAlert(this.app, Alert.AlertType.WARNING, "LIWC2015", null, "Some files have not been processed. Double click on empty grid line to see more info.");
/*     */       } catch (Exception e) {
/* 124 */         logger.error(e.getLocalizedMessage(), e);
/* 125 */         this.app.setModalIsOpen(true);
/* 126 */         new ExceptionDialog(this.app, e).showAndWait();
/* 127 */         this.app.setModalIsOpen(false);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static class TextAnalyzerResult {
/* 133 */     private ObservableList<DataSegment> data = FXCollections.observableArrayList();
/* 134 */     private File firstFile = null;
/* 135 */     private File lastFile = null;
/* 136 */     private int fileCounter = 0;
/*     */     
/*     */ 
/*     */ 
/*     */     public ObservableList<DataSegment> getData()
/*     */     {
/* 142 */       return this.data;
/*     */     }
/*     */     
/*     */     public File getFirstFile() {
/* 146 */       return this.firstFile;
/*     */     }
/*     */     
/*     */     public void setFirstFile(File firstFile) {
/* 150 */       this.firstFile = firstFile;
/*     */     }
/*     */     
/*     */     public File getLastFile() {
/* 154 */       return this.lastFile;
/*     */     }
/*     */     
/*     */     public void setLastFile(File lastFile) {
/* 158 */       this.lastFile = lastFile;
/*     */     }
/*     */     
/*     */     public int getFileCounter() {
/* 162 */       return this.fileCounter;
/*     */     }
/*     */     
/*     */     public void setFileCounter(int fileCounter) {
/* 166 */       this.fileCounter = fileCounter;
/*     */     }
/*     */     
/*     */     public void incFileCounter() {
/* 170 */       this.fileCounter += 1;
/*     */     }
/*     */   }
/*     */   
/*     */   static class TextAnalyzerTask extends CancelableTask<TextAnalyzer.TextAnalyzerResult>
/*     */   {
/*     */     private App app;
/*     */     private List<File> files;
/*     */     private int type;
/* 179 */     private boolean hasErrors = false;
/*     */     
/*     */     public TextAnalyzerTask(App app, List<File> files, int type) {
/* 182 */       this.files = files;
/* 183 */       this.app = app;
/* 184 */       this.type = type;
/*     */     }
/*     */     
/*     */     protected TextAnalyzer.TextAnalyzerResult call() throws Exception
/*     */     {
/* 189 */       if ((this.type == 1) || (this.type == 2)) {
/* 190 */         updateProgress(0L, 1L);
/* 191 */         File folder = (File)this.files.get(0);
/* 192 */         this.files.clear();
/* 193 */         readFolder(folder, this.files, this.type == 2);
/*     */       }
/* 195 */       updateProgress(0L, this.files.size());
/* 196 */       TextAnalyzer.TextAnalyzerResult result = new TextAnalyzer.TextAnalyzerResult(null);
/* 197 */       TextParser parser = new TextParser(this.app.getActiveDictionary(), new LanguageSettings(this.app.getLiwcPreferences().getLocale()));
/* 198 */       TextProcessor processor = Utils.getTextProcessor(this.app, true);
/* 199 */       for (int i = 0; i < this.files.size(); i++) {
/* 200 */         if (this.cancelRequested.get()) {
/*     */           break;
/*     */         }
/* 203 */         File file = (File)this.files.get(i);
/* 204 */         updateMessage(String.format("Processing: %s (%d of %d)", new Object[] { file.getName(), Integer.valueOf(i + 1), Integer.valueOf(this.files.size()) }));
/*     */         try {
/* 206 */           IText text = TextFactory.getText(file, Charset.forName(this.app.getLiwcPreferences().getPlainTextEncoding()));
/* 207 */           List<Segment> segments = processor.processText(text, parser);
/* 208 */           for (int j = 0; j < segments.size(); j++) {
/* 209 */             Segment segment = (Segment)segments.get(j);
/* 210 */             segment.optimize();
/* 211 */             result.getData().add(new TextFileSegment(file.getName(), j + 1, segment));
/*     */           }
/* 213 */           text.close();
/*     */         } catch (Exception e) {
/* 215 */           if (this.files.size() == 1) {
/* 216 */             throw e;
/*     */           }
/* 218 */           this.hasErrors = true;
/* 219 */           result.getData().add(new TextFileSegment(file.getName(), e));
/*     */         }
/*     */         
/* 222 */         updateProgress(i + 1, this.files.size());
/* 223 */         if (result.getFirstFile() == null)
/* 224 */           result.setFirstFile(file);
/* 225 */         result.setLastFile(file);
/* 226 */         result.incFileCounter();
/*     */       }
/* 228 */       return result;
/*     */     }
/*     */     
/*     */     private void readFolder(File folder, List<File> result, boolean recursively) {
/* 232 */       if (this.cancelRequested.get())
/* 233 */         return;
/* 234 */       updateMessage(String.format("Reading folders: %s.", new Object[] { folder.getAbsolutePath() }));
/* 235 */       File[] files = null;
/*     */       try {
/* 237 */         files = folder.listFiles(new FileFilter()
/*     */         {
/*     */           public boolean accept(File pathname) {
/* 240 */             if (pathname.isDirectory())
/* 241 */               return true;
/* 242 */             String name = pathname.getName().toLowerCase();
/* 243 */             if ((name.endsWith(".doc")) || (name.endsWith(".docx")) || (name.endsWith(".txt")) || (name.endsWith(".rtf")) || (name.endsWith(".pdf")))
/* 244 */               return true;
/* 245 */             return false;
/*     */           }
/*     */         });
/*     */       }
/*     */       catch (Exception localException) {}
/*     */       
/* 251 */       if (files != null) {
/* 252 */         for (File file : files) {
/* 253 */           if (file.isDirectory()) {
/* 254 */             if (recursively)
/* 255 */               readFolder(file, result, recursively);
/*     */           } else {
/* 257 */             result.add(file);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean hasErrors() {
/* 264 */       return this.hasErrors;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/TextAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */