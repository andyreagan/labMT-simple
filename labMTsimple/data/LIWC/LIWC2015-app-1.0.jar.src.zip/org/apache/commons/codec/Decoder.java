package org.apache.commons.codec;

public abstract interface Decoder
{
  public abstract Object decode(Object paramObject)
    throws DecoderException;
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/org/apache/commons/codec/Decoder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */