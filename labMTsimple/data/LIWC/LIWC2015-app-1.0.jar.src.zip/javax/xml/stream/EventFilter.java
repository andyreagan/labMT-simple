package javax.xml.stream;

import javax.xml.stream.events.XMLEvent;

public abstract interface EventFilter
{
  public abstract boolean accept(XMLEvent paramXMLEvent);
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/javax/xml/stream/EventFilter.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */