package com.liwc.core.text;

import java.io.IOException;
import java.io.InputStream;
import org.apache.pdfbox.cos.COSDocument;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;

public class PdfFile
  extends RawText
{
  public PdfFile(InputStream paramInputStream)
  {
    this(paramInputStream, 0, 0);
  }
  
  public PdfFile(InputStream paramInputStream, int paramInt1, int paramInt2)
  {
    super(a(paramInputStream, paramInt1, paramInt2));
  }
  
  private static String a(InputStream paramInputStream, int paramInt1, int paramInt2)
  {
    PDDocument localPDDocument = null;
    COSDocument localCOSDocument = null;
    try
    {
      (paramInputStream = new PDFParser(paramInputStream)).parse();
      localCOSDocument = paramInputStream.getDocument();
      localPDDocument = new PDDocument(localCOSDocument);
      paramInputStream = new PDFTextStripper();
      if (paramInt1 != 0) {
        paramInputStream.setStartPage(paramInt1);
      }
      if (paramInt2 != 0) {
        paramInputStream.setEndPage(paramInt2);
      }
      paramInputStream = paramInputStream.getText(localPDDocument);
      localPDDocument.close();
      localCOSDocument.close();
      return paramInputStream;
    }
    catch (IOException paramInputStream)
    {
      if (localPDDocument != null) {
        localPDDocument.close();
      }
      if (localCOSDocument != null) {
        localCOSDocument.close();
      }
      throw paramInputStream;
    }
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/core/text/PdfFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */