package com.microsoft.schemas.office.x2006.encryption.impl;

import com.microsoft.schemas.office.x2006.encryption.STSaltSize;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaIntHolderEx;

public class STSaltSizeImpl
  extends JavaIntHolderEx
  implements STSaltSize
{
  public STSaltSizeImpl(SchemaType paramSchemaType)
  {
    super(paramSchemaType, false);
  }
  
  protected STSaltSizeImpl(SchemaType paramSchemaType, boolean paramBoolean)
  {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/encryption/impl/STSaltSizeImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */