package com.microsoft.schemas.office.x2006.encryption;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.SchemaTypeSystem;
import org.apache.xmlbeans.XmlBase64Binary;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public abstract interface CTKeyData
  extends XmlObject
{
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CTKeyData.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0B482D0B338CC9641C1543C3510577FE").resolveHandle("ctkeydata6bdbtype");
  
  public abstract int getSaltSize();
  
  public abstract STSaltSize xgetSaltSize();
  
  public abstract void setSaltSize(int paramInt);
  
  public abstract void xsetSaltSize(STSaltSize paramSTSaltSize);
  
  public abstract int getBlockSize();
  
  public abstract STBlockSize xgetBlockSize();
  
  public abstract void setBlockSize(int paramInt);
  
  public abstract void xsetBlockSize(STBlockSize paramSTBlockSize);
  
  public abstract long getKeyBits();
  
  public abstract STKeyBits xgetKeyBits();
  
  public abstract void setKeyBits(long paramLong);
  
  public abstract void xsetKeyBits(STKeyBits paramSTKeyBits);
  
  public abstract int getHashSize();
  
  public abstract STHashSize xgetHashSize();
  
  public abstract void setHashSize(int paramInt);
  
  public abstract void xsetHashSize(STHashSize paramSTHashSize);
  
  public abstract STCipherAlgorithm.Enum getCipherAlgorithm();
  
  public abstract STCipherAlgorithm xgetCipherAlgorithm();
  
  public abstract void setCipherAlgorithm(STCipherAlgorithm.Enum paramEnum);
  
  public abstract void xsetCipherAlgorithm(STCipherAlgorithm paramSTCipherAlgorithm);
  
  public abstract STCipherChaining.Enum getCipherChaining();
  
  public abstract STCipherChaining xgetCipherChaining();
  
  public abstract void setCipherChaining(STCipherChaining.Enum paramEnum);
  
  public abstract void xsetCipherChaining(STCipherChaining paramSTCipherChaining);
  
  public abstract STHashAlgorithm.Enum getHashAlgorithm();
  
  public abstract STHashAlgorithm xgetHashAlgorithm();
  
  public abstract void setHashAlgorithm(STHashAlgorithm.Enum paramEnum);
  
  public abstract void xsetHashAlgorithm(STHashAlgorithm paramSTHashAlgorithm);
  
  public abstract byte[] getSaltValue();
  
  public abstract XmlBase64Binary xgetSaltValue();
  
  public abstract void setSaltValue(byte[] paramArrayOfByte);
  
  public abstract void xsetSaltValue(XmlBase64Binary paramXmlBase64Binary);
  
  public static final class Factory
  {
    public static CTKeyData newInstance()
    {
      return (CTKeyData)XmlBeans.getContextTypeLoader().newInstance(CTKeyData.type, null);
    }
    
    public static CTKeyData newInstance(XmlOptions paramXmlOptions)
    {
      return (CTKeyData)XmlBeans.getContextTypeLoader().newInstance(CTKeyData.type, paramXmlOptions);
    }
    
    public static CTKeyData parse(String paramString)
      throws XmlException
    {
      return (CTKeyData)XmlBeans.getContextTypeLoader().parse(paramString, CTKeyData.type, null);
    }
    
    public static CTKeyData parse(String paramString, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (CTKeyData)XmlBeans.getContextTypeLoader().parse(paramString, CTKeyData.type, paramXmlOptions);
    }
    
    public static CTKeyData parse(File paramFile)
      throws XmlException, IOException
    {
      return (CTKeyData)XmlBeans.getContextTypeLoader().parse(paramFile, CTKeyData.type, null);
    }
    
    public static CTKeyData parse(File paramFile, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTKeyData)XmlBeans.getContextTypeLoader().parse(paramFile, CTKeyData.type, paramXmlOptions);
    }
    
    public static CTKeyData parse(URL paramURL)
      throws XmlException, IOException
    {
      return (CTKeyData)XmlBeans.getContextTypeLoader().parse(paramURL, CTKeyData.type, null);
    }
    
    public static CTKeyData parse(URL paramURL, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTKeyData)XmlBeans.getContextTypeLoader().parse(paramURL, CTKeyData.type, paramXmlOptions);
    }
    
    public static CTKeyData parse(InputStream paramInputStream)
      throws XmlException, IOException
    {
      return (CTKeyData)XmlBeans.getContextTypeLoader().parse(paramInputStream, CTKeyData.type, null);
    }
    
    public static CTKeyData parse(InputStream paramInputStream, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTKeyData)XmlBeans.getContextTypeLoader().parse(paramInputStream, CTKeyData.type, paramXmlOptions);
    }
    
    public static CTKeyData parse(Reader paramReader)
      throws XmlException, IOException
    {
      return (CTKeyData)XmlBeans.getContextTypeLoader().parse(paramReader, CTKeyData.type, null);
    }
    
    public static CTKeyData parse(Reader paramReader, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTKeyData)XmlBeans.getContextTypeLoader().parse(paramReader, CTKeyData.type, paramXmlOptions);
    }
    
    public static CTKeyData parse(XMLStreamReader paramXMLStreamReader)
      throws XmlException
    {
      return (CTKeyData)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, CTKeyData.type, null);
    }
    
    public static CTKeyData parse(XMLStreamReader paramXMLStreamReader, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (CTKeyData)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, CTKeyData.type, paramXmlOptions);
    }
    
    public static CTKeyData parse(Node paramNode)
      throws XmlException
    {
      return (CTKeyData)XmlBeans.getContextTypeLoader().parse(paramNode, CTKeyData.type, null);
    }
    
    public static CTKeyData parse(Node paramNode, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (CTKeyData)XmlBeans.getContextTypeLoader().parse(paramNode, CTKeyData.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static CTKeyData parse(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return (CTKeyData)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, CTKeyData.type, null);
    }
    
    /**
     * @deprecated
     */
    public static CTKeyData parse(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return (CTKeyData)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, CTKeyData.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, CTKeyData.type, null);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, CTKeyData.type, paramXmlOptions);
    }
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/encryption/CTKeyData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */