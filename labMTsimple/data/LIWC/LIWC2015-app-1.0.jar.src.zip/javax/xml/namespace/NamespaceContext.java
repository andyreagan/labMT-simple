package javax.xml.namespace;

import java.util.Iterator;

public abstract interface NamespaceContext
{
  public abstract String getNamespaceURI(String paramString);
  
  public abstract String getPrefix(String paramString);
  
  public abstract Iterator getPrefixes(String paramString);
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/javax/xml/namespace/NamespaceContext.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */