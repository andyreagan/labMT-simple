/*     */ package com.liwc.LIWC2015.controller;
/*     */ 
/*     */ import com.liwc.LIWC2015.App;
/*     */ import com.liwc.LIWC2015.LiwcPreferences;
/*     */ import com.liwc.LIWC2015.LiwcPreferences.Categories;
/*     */ import com.liwc.LIWC2015.customview.ResultPane;
/*     */ import com.liwc.LIWC2015.model.DataSegment;
/*     */ import com.liwc.LIWC2015.model.ExcelRowSegment;
/*     */ import com.liwc.LIWC2015.model.ExcelRowSegment.Cell;
/*     */ import com.liwc.LIWC2015.model.TextFileSegment;
/*     */ import com.liwc.core.dictionary.IDictionary;
/*     */ import java.io.File;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javafx.beans.value.ObservableValue;
/*     */ import javafx.collections.ObservableList;
/*     */ import javafx.scene.control.TableCell;
/*     */ import javafx.scene.control.TableColumn;
/*     */ import javafx.scene.control.TableColumn.CellDataFeatures;
/*     */ import javafx.scene.control.TableRow;
/*     */ import javafx.scene.control.TableView;
/*     */ import javafx.scene.control.cell.PropertyValueFactory;
/*     */ import javafx.scene.input.MouseEvent;
/*     */ import javafx.scene.text.Font;
/*     */ import javafx.util.Callback;
/*     */ 
/*     */ public class AnalyzeTextPaneController extends SaveablePaneController
/*     */ {
/*     */   public static final String Filename = "fileName";
/*     */   public static final String SegmentIndex = "segmentIndex";
/*     */   public static final String WordsCount = "wordsCount";
/*     */   public static final String WordsPerSentence = "wordsPerSentence";
/*     */   public static final String SixLettersWords = "sixLettersWords";
/*     */   public static final String DictWords = "dictWords";
/*     */   public static final String PunctMarks = "punctMarks";
/*     */   public static final String Analytic = "analytic";
/*     */   public static final String Clout = "clout";
/*     */   public static final String Authentic = "authentic";
/*     */   public static final String Tone = "tone";
/*  45 */   private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(AnalyzeTextPaneController.class);
/*     */   
/*  47 */   private DecimalFormat decimalFormat = new DecimalFormat("0.00");
/*     */   private ObservableList<DataSegment> data;
/*     */   
/*     */   public AnalyzeTextPaneController(App app)
/*     */   {
/*  52 */     super(app);
/*     */   }
/*     */   
/*     */   public void buildFromTextFileSegments(ObservableList<DataSegment> data, int fileCounter, String title) {
/*  56 */     this.data = data;
/*  57 */     if (fileCounter > 0) {
/*  58 */       this.resultPane = this.app.newResultPane(this, title);
/*  59 */       TableView tableView = this.resultPane.getTableView();
/*  60 */       tableView.setEditable(false);
/*  61 */       tableView.getSelectionModel().setSelectionMode(javafx.scene.control.SelectionMode.MULTIPLE);
/*  62 */       List<TableColumn> columns = new ArrayList();
/*  63 */       TableColumn<TextFileSegment, String> column = new TableColumn("Filename");
/*  64 */       column.setCellValueFactory(new PropertyValueFactory("fileName"));
/*  65 */       columns.add(column);
/*     */       
/*  67 */       tableView.setRowFactory(new Callback()
/*     */       {
/*     */         public TableRow call(TableView param) {
/*  70 */           final TableRow<TextFileSegment> row = new TableRow();
/*  71 */           row.setOnMouseClicked(new javafx.event.EventHandler()
/*     */           {
/*     */             public void handle(MouseEvent event) {
/*  74 */               if ((event.getClickCount() == 2) && (!row.isEmpty())) {
/*  75 */                 TextFileSegment rowData = (TextFileSegment)row.getItem();
/*  76 */                 if (rowData.getException() != null) {
/*  77 */                   com.liwc.LIWC2015.Utils.showAlert(AnalyzeTextPaneController.this.app, javafx.scene.control.Alert.AlertType.ERROR, "LIWC2015", null, rowData.getException().getLocalizedMessage());
/*     */                 }
/*     */                 
/*     */               }
/*     */             }
/*  82 */           });
/*  83 */           return row;
/*     */         }
/*  85 */       });
/*  86 */       column = new TableColumn("Segment");
/*  87 */       column.setStyle("-fx-alignment: CENTER-RIGHT;");
/*  88 */       column.setCellValueFactory(new PropertyValueFactory("segmentIndex"));
/*  89 */       columns.add(column);
/*  90 */       addCommonColumns(columns);
/*  91 */       tableView.getColumns().addAll(columns);
/*  92 */       tableView.setItems(getData());
/*     */     }
/*     */   }
/*     */   
/*     */   public void buildFromExcelRowSegments(ObservableList<DataSegment> data, File file, List<Float> columnWidths) {
/*  97 */     this.data = data;
/*  98 */     this.resultPane = this.app.newResultPane(this, com.liwc.LIWC2015.Utils.getFilenameWithoutExtension(file));
/*  99 */     this.resultPane.setController(this);
/* 100 */     TableView tableView = this.resultPane.getTableView();
/* 101 */     tableView.getSelectionModel().setSelectionMode(javafx.scene.control.SelectionMode.MULTIPLE);
/* 102 */     tableView.setEditable(false);
/* 103 */     List<TableColumn> columns = new ArrayList();
/* 104 */     List<ExcelRowSegment.Cell> excelRow = ((ExcelRowSegment)data.get(0)).getExcelRow();
/* 105 */     for (int i = 0; i < excelRow.size(); i++) {
/* 106 */       final int i1 = i;
/* 107 */       TableColumn<DataSegment, ExcelRowSegment.Cell> column = new TableColumn(String.format("Source (%s)", new Object[] { ExcelCsvAnalyzer.getColumnName(i) }));
/* 108 */       column.setCellValueFactory(new Callback()
/*     */       {
/*     */         public ObservableValue<ExcelRowSegment.Cell> call(TableColumn.CellDataFeatures<DataSegment, ExcelRowSegment.Cell> param) {
/* 111 */           return new javafx.beans.property.SimpleObjectProperty(((ExcelRowSegment)param.getValue()).getExcelRow().get(i1));
/*     */         }
/* 113 */       });
/* 114 */       column.setCellFactory(new Callback()
/*     */       {
/*     */         public TableCell<DataSegment, ExcelRowSegment.Cell> call(TableColumn<DataSegment, ExcelRowSegment.Cell> param) {
/* 117 */           new TableCell()
/*     */           {
/*     */             protected void updateItem(Object item, boolean empty) {
/* 120 */               super.updateItem(item, empty);
/* 121 */               ExcelRowSegment.Cell cell = (ExcelRowSegment.Cell)item;
/* 122 */               if (cell != null) {
/* 123 */                 setText(cell.getValue());
/* 124 */                 Font f = Font.font(getFont().getFamily(), cell.isSelected() ? javafx.scene.text.FontWeight.BOLD : javafx.scene.text.FontWeight.NORMAL, getFont().getSize());
/* 125 */                 setFont(f);
/*     */               } else {
/* 127 */                 setText("");
/*     */               }
/*     */             }
/*     */           };
/*     */         }
/*     */       });
/* 133 */       if (columnWidths != null) {
/* 134 */         Float columnWidth = (Float)columnWidths.get(i);
/* 135 */         if (columnWidth != null)
/* 136 */           column.setPrefWidth(((Float)columnWidths.get(i)).floatValue());
/*     */       }
/* 138 */       columns.add(column);
/*     */     }
/* 140 */     addCommonColumns(columns);
/* 141 */     tableView.setItems(getData());
/* 142 */     tableView.getColumns().addAll(columns);
/*     */   }
/*     */   
/*     */   public void close()
/*     */   {
/* 147 */     this.resultPane = null;
/* 148 */     this.data.clear();
/* 149 */     this.data = null;
/*     */   }
/*     */   
/*     */   protected CancelableTask getSaveTask(File fileToSave)
/*     */   {
/* 154 */     return new SaveTask(this, fileToSave, null);
/*     */   }
/*     */   
/*     */   ObservableList<DataSegment> getData() {
/* 158 */     return this.data;
/*     */   }
/*     */   
/*     */   private void addCommonColumns(List<TableColumn> columns) {
/* 162 */     List<String> categories = new ArrayList(this.app.getActiveDictionary().getCategoriesPlain().values());
/* 163 */     categories.addAll(IDictionary.PunctuationMarksCategories.values());
/* 164 */     if (this.app.getLiwcPreferences().getCategories().showParam("WC"))
/* 165 */       columns.add(newGenericColumn("WC", "wordsCount"));
/* 166 */     if (this.app.getLiwcPreferences().getCategories().showParam("Analytic"))
/* 167 */       columns.add(newGenericColumn("Analytic", "analytic"));
/* 168 */     if (this.app.getLiwcPreferences().getCategories().showParam("Clout"))
/* 169 */       columns.add(newGenericColumn("Clout", "clout"));
/* 170 */     if (this.app.getLiwcPreferences().getCategories().showParam("Authentic"))
/* 171 */       columns.add(newGenericColumn("Authentic", "authentic"));
/* 172 */     if (this.app.getLiwcPreferences().getCategories().showParam("Tone"))
/* 173 */       columns.add(newGenericColumn("Tone", "tone"));
/* 174 */     if (this.app.getLiwcPreferences().getCategories().showParam("WPS"))
/* 175 */       columns.add(newGenericColumn("WPS", "wordsPerSentence"));
/* 176 */     if (this.app.getLiwcPreferences().getCategories().showParam("Sixltr"))
/* 177 */       columns.add(newGenericColumn("Sixltr", "sixLettersWords"));
/* 178 */     if (this.app.getLiwcPreferences().getCategories().showParam("Dic"))
/* 179 */       columns.add(newGenericColumn("Dic", "dictWords"));
/* 180 */     Map<Integer, String> map = new LinkedHashMap(this.app.getActiveDictionary().getCategoriesPlain());
/* 181 */     for (Map.Entry<Integer, String> entry : map.entrySet()) {
/* 182 */       if ((((Integer)entry.getKey()).intValue() >= 0) && (this.app.getLiwcPreferences().getCategories().showParam((String)entry.getValue())))
/* 183 */         columns.add(newCategoryColumn((String)entry.getValue(), ((Integer)entry.getKey()).intValue()));
/*     */     }
/* 185 */     if (this.app.getLiwcPreferences().getCategories().showParam("AllPunc"))
/* 186 */       columns.add(newGenericColumn("AllPunc", "punctMarks"));
/* 187 */     map = new LinkedHashMap();
/* 188 */     map.putAll(IDictionary.PunctuationMarksCategories);
/* 189 */     for (Map.Entry<Integer, String> entry : map.entrySet()) {
/* 190 */       if ((((Integer)entry.getKey()).intValue() >= 0) && (this.app.getLiwcPreferences().getCategories().showParam((String)entry.getValue())))
/* 191 */         columns.add(newCategoryColumn((String)entry.getValue(), ((Integer)entry.getKey()).intValue()));
/*     */     }
/* 193 */     TableColumn column = new TableColumn();
/* 194 */     column.setPrefWidth(columns.size());
/* 195 */     columns.add(column);
/*     */   }
/*     */   
/*     */   private TableColumn newCategoryColumn(String name, final int categoryIndex) {
/* 199 */     TableColumn<DataSegment, Number> tableColumn = new TableColumn(name);
/* 200 */     tableColumn.setStyle("-fx-alignment: CENTER-RIGHT;");
/* 201 */     tableColumn.setCellValueFactory(new Callback()
/*     */     {
/*     */       public ObservableValue<Number> call(TableColumn.CellDataFeatures<DataSegment, Number> param) {
/* 204 */         return (param.getValue() == null) || (((DataSegment)param.getValue()).getSegment() == null) ? null : new javafx.beans.property.SimpleFloatProperty(((DataSegment)param.getValue()).getCategoryValue(categoryIndex).floatValue());
/*     */       }
/* 206 */     });
/* 207 */     tableColumn.setCellFactory(new Callback()
/*     */     {
/*     */       public TableCell<DataSegment, Number> call(TableColumn<DataSegment, Number> param) {
/* 210 */         new TableCell()
/*     */         {
/*     */           protected void updateItem(Number item, boolean empty) {
/* 213 */             super.updateItem(item, empty);
/* 214 */             if ((item == null) || (empty)) {
/* 215 */               setText("");
/*     */             } else {
/* 217 */               setText(AnalyzeTextPaneController.this.decimalFormat.format(item));
/*     */             }
/*     */           }
/*     */         };
/*     */       }
/* 222 */     });
/* 223 */     return tableColumn;
/*     */   }
/*     */   
/*     */   private <T> TableColumn newGenericColumn(String name, String property) {
/* 227 */     TableColumn<DataSegment, T> tableColumn = new TableColumn(name);
/* 228 */     tableColumn.setStyle("-fx-alignment: CENTER-RIGHT;");
/* 229 */     tableColumn.setCellValueFactory(new PropertyValueFactory(property));
/* 230 */     tableColumn.setCellFactory(new Callback()
/*     */     {
/*     */       public TableCell<DataSegment, T> call(TableColumn<DataSegment, T> param) {
/* 233 */         new TableCell()
/*     */         {
/*     */           protected void updateItem(T item, boolean empty) {
/* 236 */             super.updateItem(item, empty);
/* 237 */             if ((item == null) || (empty)) {
/* 238 */               setText("");
/* 239 */             } else if ((item instanceof Integer)) {
/* 240 */               setText(item.toString());
/* 241 */             } else if ((item instanceof Number)) {
/* 242 */               setText(AnalyzeTextPaneController.this.decimalFormat.format(item));
/* 243 */             } else if ((item instanceof String)) {
/* 244 */               setText((String)item);
/*     */             }
/*     */           }
/*     */         };
/*     */       }
/* 249 */     });
/* 250 */     return tableColumn;
/*     */   }
/*     */   
/*     */   private static class SaveTask extends CancelableTask<Void>
/*     */   {
/*     */     private File file;
/*     */     private AnalyzeTextPaneController controller;
/*     */     
/*     */     private SaveTask(AnalyzeTextPaneController controller, File file) {
/* 259 */       this.controller = controller;
/* 260 */       this.file = file;
/*     */     }
/*     */     
/*     */     protected Void call() throws Exception
/*     */     {
/* 265 */       updateMessage("Saving results...");
/* 266 */       updateProgress(0L, this.controller.getData().size());
/* 267 */       App app = this.controller.app;
/* 268 */       TableView tableView = this.controller.resultPane.getTableView();
/* 269 */       ObservableList<DataSegment> data = this.controller.getData();
/* 270 */       FileSaver fileSaver = FileSaver.getFileSaver(this.file, app.getLiwcPreferences());
/* 271 */       int nrOfCols = tableView.getColumns().size() - 1;
/* 272 */       for (int i = 0; i < nrOfCols; i++) {
/* 273 */         TableColumn column = (TableColumn)tableView.getColumns().get(i);
/* 274 */         fileSaver.saveValue(column.getText(), i == nrOfCols - 1, data.size() == 0);
/*     */       }
/* 276 */       for (int i = 0; i < data.size(); i++) {
/* 277 */         DataSegment segment = (DataSegment)data.get(i);
/* 278 */         boolean lastInTable = i == data.size() - 1;
/* 279 */         List<Object> rowData = new ArrayList();
/* 280 */         Iterator localIterator; if ((segment instanceof TextFileSegment)) {
/* 281 */           rowData.add(((TextFileSegment)segment).getFileName());
/* 282 */           rowData.add(((TextFileSegment)segment).getSegmentIndex());
/* 283 */         } else if ((segment instanceof ExcelRowSegment)) {
/* 284 */           for (localIterator = ((ExcelRowSegment)segment).getExcelRow().iterator(); localIterator.hasNext();) { cell = (ExcelRowSegment.Cell)localIterator.next();
/* 285 */             rowData.add(cell.getValue());
/*     */           } }
/*     */         ExcelRowSegment.Cell cell;
/* 288 */         if (app.getLiwcPreferences().getCategories().showParam("WC"))
/* 289 */           rowData.add(segment.getWordsCount());
/* 290 */         if (app.getLiwcPreferences().getCategories().showParam("Analytic"))
/* 291 */           rowData.add(segment.getAnalytic());
/* 292 */         if (app.getLiwcPreferences().getCategories().showParam("Clout"))
/* 293 */           rowData.add(segment.getClout());
/* 294 */         if (app.getLiwcPreferences().getCategories().showParam("Authentic"))
/* 295 */           rowData.add(segment.getAuthentic());
/* 296 */         if (app.getLiwcPreferences().getCategories().showParam("Tone"))
/* 297 */           rowData.add(segment.getTone());
/* 298 */         if (app.getLiwcPreferences().getCategories().showParam("WPS"))
/* 299 */           rowData.add(segment.getWordsPerSentence());
/* 300 */         if (app.getLiwcPreferences().getCategories().showParam("Sixltr"))
/* 301 */           rowData.add(segment.getSixLettersWords());
/* 302 */         if (app.getLiwcPreferences().getCategories().showParam("Dic"))
/* 303 */           rowData.add(segment.getDictWords());
/* 304 */         Object map = new LinkedHashMap(app.getActiveDictionary().getCategoriesPlain());
/* 305 */         for (Map.Entry<Integer, String> entry : ((Map)map).entrySet()) {
/* 306 */           if ((((Integer)entry.getKey()).intValue() >= 0) && (app.getLiwcPreferences().getCategories().showParam((String)entry.getValue())))
/* 307 */             rowData.add(segment.getCategoryValue(((Integer)entry.getKey()).intValue()));
/*     */         }
/* 309 */         if (app.getLiwcPreferences().getCategories().showParam("AllPunc"))
/* 310 */           rowData.add(segment.getPunctMarks());
/* 311 */         map = new LinkedHashMap();
/* 312 */         ((Map)map).putAll(IDictionary.PunctuationMarksCategories);
/* 313 */         for (Map.Entry<Integer, String> entry : ((Map)map).entrySet()) {
/* 314 */           if ((((Integer)entry.getKey()).intValue() >= 0) && (app.getLiwcPreferences().getCategories().showParam((String)entry.getValue())))
/* 315 */             rowData.add(segment.getCategoryValue(((Integer)entry.getKey()).intValue()));
/*     */         }
/* 317 */         for (int j = 0; j < rowData.size(); j++) {
/* 318 */           fileSaver.saveValue(rowData.get(j), j == rowData.size() - 1, lastInTable);
/*     */         }
/* 320 */         updateProgress(i + 1, this.controller.getData().size());
/*     */       }
/* 322 */       fileSaver.close();
/* 323 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/AnalyzeTextPaneController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */