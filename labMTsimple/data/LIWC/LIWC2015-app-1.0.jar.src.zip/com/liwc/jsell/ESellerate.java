package com.liwc.jsell;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.xml.bind.DatatypeConverter;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ESellerate
{
  public static final long E_SUCCESS = 0L;
  public static final long E_ENGINE_BAD_SDK_INPUT = 3758096384L;
  public static final long E_ENGINE_SKU_UPDATE_AVAILABLE = 1610612742L;
  public static final long E_ENGINE_SKU_NO_UPDATE_AVAILABLE = 1610612743L;
  public static final long E_ENGINE_INTERNAL_ERROR = 3758096387L;
  public static final long E_ENGINE_PURCHASE_NOTSUCCESSFUL = 3758096388L;
  public static final long E_VALIDATEACTIVATION_MACHINE_MISMATCH = 3758424064L;
  public static final long E_VALIDATEACTIVATION_MACHINE_MATCH = 537198593L;
  public static final long E_ACTIVATION_INVALID_ACTIVATION_KEY = 3758424065L;
  public static final long E_ACTIVATION_UNKNOWN_ACTIVATION_KEY = 3758424066L;
  public static final long E_ACTIVATESN_UNKNOWN_SERVER_ERROR = 3758424067L;
  public static final long E_ACTIVATESN_UNKNOWN_SN = 3758424068L;
  public static final long E_ACTIVATESN_IMPROPER_USAGE = 3758424069L;
  public static final long E_ACTIVATESN_BLACKLISTED_SN = 3758424070L;
  public static final long E_ACTIVATESN_INVALID_ORDER = 3758424071L;
  public static final long E_ACTIVATESN_LIMIT_MET = 3758424072L;
  public static final long E_ACTIVATESN_NOT_UNIQUE = 3758424073L;
  public static final long E_ACTIVATESN_FINALIZATION_ERROR = 3758424074L;
  public static final long E_ACTIVATESN_NO_SN_FROM_SERVER = 3758424075L;
  public static final long E_ACTIVATION_MANUAL_CANCEL = 3758424076L;
  public static final long E_CONFIRMATION_UNEXPECTED_FAILURE = 3770679297L;
  public static final long E_CONFIRMATION_NO_SUCH_SERIAL_NUMBER = 3770830849L;
  public static final long E_CONFIRMATION_BLACKLISTED_SERIAL_NUMBER = 3770830851L;
  public static final long E_CONFIRMATION_INVALID_ORDER = 3770830852L;
  public static final long E_ACTIVATION_UNEXPECTED_FAILURE = 3768582145L;
  public static final long E_ACTIVATION_REQUEST_DENIED = 3768733714L;
  public static final long E_DEACTIVATION_UNEXPECTED_FAILURE = 3771727873L;
  public static final long E_DEACTIVATION_NO_SUCH_SERIAL_NUMBER = 3771879425L;
  public static final long E_DEACTIVATION_BLACKLISTED_SERIAL_NUMBER = 3771879427L;
  public static final long E_DEACTIVATION_INVALID_ORDER = 3771879428L;
  public static final long E_DEACTIVATION_MISSING_ACTIVATION_KEY = 3771879430L;
  public static final long E_DEACTIVATION_MACHINE_MISMATCH = 3771879431L;
  public static final long E_DEACTIVATION_INVALID_ACTIVATION_KEY = 3771879432L;
  public static final long E_DEACTIVATION_NONUNIQUE_SERIAL_NUMBER = 3771879433L;
  public static final long E_DEACTIVATION_NO_SUCH_ACTIVATION_KEY = 3771879440L;
  public static final long E_DEACTIVATION_DEACTIVATION_LIMIT_MET = 3771879441L;
  public static final long E_OS_FUNCTIONALITY_UNSUPPORTED = 3758292992L;
  public static final long E_SDK_LATEST_ENGINE_ALREADY_INSTALLED = 536936448L;
  public static final long E_SDK_INSTALLED_ENGINE = 536936449L;
  public static final long E_SDK_ENGINE_NOT_INSTALLED = 3758161924L;
  public static final long E_SDK_CREATE_ENTRY_ERROR = 3758161925L;
  public static final long E_SDK_ENGINE_CORRUPTED = 3758161926L;
  public static final long E_SDK_ENGINE_RES_ERR = 3758161927L;
  public static final long E_SDK_BAD_PARAMETER = 3758161928L;
  public static final long E_SDK_OBJECT_NOT_FOUND = 3758161929L;
  public static final long E_SDK_SYSTEM_IS_NOT_COMPATIBLE = 3758161936L;
  public static final long E_INET_CONNECTION_FAILURE = 3758227456L;
  public static final long E_INET_SILENT_CONNECTION_FAILURE = 3758227458L;
  public static final long E_INET_DEVICE_CONNECTION_FAILURE = 3758227459L;
  public static final long MAC_E_SDK_CREATE_ENTRY_ERROR = -2001L;
  public static final long MAC_E_SDK_BAD_PARAMETER = -2002L;
  public static final long MAC_E_SDK_ENGINE_NOT_INSTALLED = -2003L;
  public static final long MAC_E_SDK_ENGINE_CORRUPTED = -2005L;
  public static final long MAC_E_SDK_OBJECT_NOT_FOUND = -2007L;
  public static final long MAC_E_SDK_ENGINE_BUSY = -2008L;
  public static final long MAC_E_INET_CONNECTION_FAILURE = -3001L;
  public static final long MAC_E_INET_ESELLERATE_FAILURE = -3002L;
  public static final long MAC_E_INET_DOWNLOAD_ENGINE_FAILURE = -3003L;
  public static final long MAC_E_INET_ESTATE_NOT_FOUND = -3004L;
  public static final long MAC_E_VALIDATEACTIVATION_MACHINE_MATCH = 5000L;
  public static final long MAC_E_VALIDATEACTIVATION_MACHINE_MISMATCH = -5001L;
  public static final long MAC_E_VALIDATEACTIVATION_OLD_ACTIVATION_KEY = -5002L;
  public static final long MAC_E_ACTIVATION_MANUAL_CANCEL = -5005L;
  public static final long MAC_E_ACTIVATESN_UNKNOWN_ACTIVATION_KEY = -25000L;
  public static final long MAC_E_ACTIVATESN_UNKNOWN_SN = -25001L;
  public static final long MAC_E_ACTIVATESN_IMPROPER_USAGE = -25002L;
  public static final long MAC_E_ACTIVATESN_BLACKLISTED_SN = -25003L;
  public static final long MAC_E_ACTIVATESN_INVALID_ORDER = -25004L;
  public static final long MAC_E_ACTIVATESN_LIMIT_MET = -25005L;
  public static final long MAC_E_ACTIVATESN_NOT_UNIQUE = -25009L;
  public static final long MAC_E_ACTIVATESN_UNKNOWN_SERVER_ERROR = -25010L;
  public static final long MAC_E_ACTIVATESN_FINALIZATION_ERROR = -25011L;
  public static final long MAC_E_ACTIVATION_REQUEST_DENIED = -25012L;
  public static final long MAC_E_ACTIVATESN_NO_SN_FROM_SERVER = -25013L;
  public static final long MAC_E_CONFIRMATION_NO_SUCH_SERIAL_NUMBER = -25001L;
  public static final long MAC_E_CONFIRMATION_PUBLISHER_SN_MISMATCH = -25002L;
  public static final long MAC_E_CONFIRMATION_BLACKLISTED_SERIAL_NUMBER = -25003L;
  public static final long MAC_E_CONFIRMATION_INVALID_ORDER = -25004L;
  public static final long MAC_E_CONFIRMATION_UNEXPECTED_FAILURE = -25010L;
  public static final long MAC_E_DEACTIVATION_NO_SUCH_SERIAL_NUMBER = -25001L;
  public static final long MAC_E_DEACTIVATION_BLACKLISTED_SERIAL_NUMBER = -25003L;
  public static final long MAC_E_DEACTIVATION_INVALID_ORDER = -25004L;
  public static final long MAC_E_DEACTIVATION_MISSING_ACTIVATION_KEY = -25006L;
  public static final long MAC_E_DEACTIVATION_MACHINE_MISMATCH = -25007L;
  public static final long MAC_E_DEACTIVATION_INVALID_ACTIVATION_KEY = -25008L;
  public static final long MAC_E_DEACTIVATION_NONUNIQUE_SERIAL_NUMBER = -25009L;
  public static final long MAC_E_DEACTIVATION_NO_SUCH_ACTIVATION_KEY = -25010L;
  public static final long MAC_E_DEACTIVATION_DEACTIVATION_LIMIT_MET = -25011L;
  public static final long MAC_E_ENGINE_SKU_UPDATE_AVAILABLE = 6000L;
  public static final long MAC_E_ENGINE_SKU_NO_UPDATE_AVAILABLE = -6000L;
  public static final long MAC_E_ENGINE_INTERNAL_ERROR = -6001L;
  public static final long MAC_E_ENGINE_PURCHASE_NOTSUCCESSFUL = -6002L;
  public static final long MAC_E_OS_FUNCTIONALITY_UNSUPPORTED = -7000L;
  public static final Map Messages = new a();
  public static final int MaxDaysToExpire = 8192;
  private static final Logger a = LoggerFactory.getLogger(ESellerate.class);
  private boolean b = true;
  private int c = 8192;
  
  public ESellerate(boolean paramBoolean)
  {
    this.b = paramBoolean;
  }
  
  public final boolean validate(String paramString)
  {
    String str1 = paramString;
    paramString = this;
    if ((str1 == null) || (str1.isEmpty())) {
      str1 = "0000";
    }
    String str4 = str1;
    String str2 = paramString;
    long l1;
    if ((l1 = a(new h(str2, str4))) != 0L)
    {
      str4 = str1;
      str2 = paramString;
      long l2;
      if (!b(l2 = a(new d(str2, str4))))
      {
        long l4 = l2;
        if (((l4 == 3758424065L) || (l4 == 3758424066L) || (l4 == 3758424067L) || (l4 == 3758424068L) || (l4 == 3758424069L) || (l4 == 3758424070L) || (l4 == 3758424071L) || (l4 == 3758424072L) || (l4 == 3758424073L) || (l4 == 3758424074L) || (l4 == 3758424075L) || (l4 == 3758424076L) ? 1 : Utils.isMac() ? 0 : (l4 <= -25000L) && (l4 >= -25013L) ? 1 : 0) != 0) {
          throw new ESellerateException(4, String.format("Registration Error. %s", new Object[] { a(l2) }));
        }
        throw new ESellerateException(2, String.format("Registration Error. %s", new Object[] { a(l2) }));
      }
      if (!paramString.b)
      {
        String str3 = paramString;
        long l3 = a(new g(str3));
        int i;
        if ((i = l1 < l3 ? 1 : 0) != 0) {
          throw new ESellerateException(3, "Registration Error. Activation has expired.");
        }
        paramString.c = ((int)(l1 - l3) + 1);
      }
    }
    else
    {
      throw new ESellerateException(1, "Registration Error. The serial number associated with LIWC does not appear to be valid.");
    }
    return true;
  }
  
  public final boolean activate(String paramString)
  {
    String str = paramString;
    paramString = this;
    if ((str == null) || (str.isEmpty())) {
      str = "0000";
    }
    str = str;
    paramString = paramString;
    long l;
    if (b(l = a(new e(paramString, str)))) {
      return true;
    }
    throw new ESellerateException(5, String.format("Activation Error. %s", new Object[] { a(l) }));
  }
  
  public final boolean deactivate(String paramString)
  {
    String str = paramString;
    paramString = this;
    if ((str == null) || (str.isEmpty())) {
      str = "0000";
    }
    str = str;
    paramString = paramString;
    long l;
    if (b(l = a(new f(paramString, str)))) {
      return true;
    }
    throw new ESellerateException(6, String.format("Deactivation Error. %s", new Object[] { a(l) }));
  }
  
  public final int getDaysToExpire()
  {
    return this.c;
  }
  
  private static String a(long paramLong)
  {
    return String.format("%s (%d)", new Object[] { Messages.get(Long.valueOf(paramLong)), Long.valueOf(paramLong) });
  }
  
  private static long a(i parami)
  {
    Object localObject1 = null;
    try
    {
      long l = -1L;
      Object localObject2 = File.createTempFile("liwc2015", ".tmp");
      (localObject3 = new File(((File)localObject2).getParent() + File.separator + UUID.randomUUID().toString())).mkdirs();
      ((File)localObject2).delete();
      localObject1 = localObject3;
      if (Utils.isMac())
      {
        localObject2 = a(new b(), (File)localObject1);
        new UnzipUtility().unzip(((File)((List)localObject2).get(0)).getAbsolutePath(), ((File)localObject1).getAbsolutePath());
        ((List)localObject2).add(0, new File(localObject1 + File.separator + "esell.app"));
        if (!a((File)((List)localObject2).get(1)).equals("E4BDAEE47D728D9B44B48810BEF79232")) {
          throw new ESellerateException(0, "Unexpected esell app checksum.");
        }
      }
      else if (!a((File)(localObject2 = a(new c(), (File)localObject1)).get(0)).equals("9794C2545A230A9ACFE1870EE3A70DDF"))
      {
        throw new ESellerateException(0, "Unexpected esell app checksum.");
      }
      if (Utils.isMac())
      {
        Runtime.getRuntime().exec("chmod 777 " + ((File)((List)localObject2).get(0)).getAbsolutePath() + "/Contents/MacOS/esell").waitFor();
        parami = parami.a(new File(((File)((List)localObject2).get(0)).getAbsolutePath() + "/Contents/MacOS/esell"));
      }
      else
      {
        parami = parami.a((File)((List)localObject2).get(0));
      }
      localObject2 = new BufferedReader(new InputStreamReader(parami.getInputStream()));
      Object localObject3 = new BufferedReader(new InputStreamReader(parami.getErrorStream()));
      String str;
      while ((str = ((BufferedReader)localObject2).readLine()) != null) {
        l = Long.parseLong(str);
      }
      ((BufferedReader)localObject2).close();
      while (((BufferedReader)localObject3).readLine() != null) {}
      ((BufferedReader)localObject3).close();
      parami = parami.waitFor();
      b((File)localObject1);
      if (parami == -1) {
        return -1L;
      }
      return l;
    }
    catch (Exception localException)
    {
      try
      {
        b((File)localObject1);
      }
      catch (IOException localIOException)
      {
        a.error(localIOException.getLocalizedMessage(), localIOException);
      }
      if ((localException instanceof ESellerateException)) {
        throw ((ESellerateException)localException);
      }
      throw new ESellerateException(localException.getLocalizedMessage(), localException);
    }
  }
  
  private static String a(File paramFile)
  {
    MessageDigest localMessageDigest;
    (localMessageDigest = MessageDigest.getInstance("MD5")).update(Files.readAllBytes(Paths.get(paramFile.getAbsolutePath(), new String[0])));
    return DatatypeConverter.printHexBinary(paramFile = localMessageDigest.digest()).toUpperCase();
  }
  
  private static List a(List paramList, File paramFile)
  {
    ArrayList localArrayList = new ArrayList();
    paramList = paramList.iterator();
    while (paramList.hasNext())
    {
      Object localObject = (String)paramList.next();
      File localFile = new File(paramFile.getAbsolutePath() + File.separator + (String)localObject);
      localObject = ESellerate.class.getResourceAsStream((Utils.isMac() ? "/com/liwc/jsell/mac/" : "/com/liwc/jsell/win/") + (String)localObject);
      FileOutputStream localFileOutputStream = new FileOutputStream(localFile);
      byte[] arrayOfByte = new byte[65536];
      int i;
      while ((i = ((InputStream)localObject).read(arrayOfByte, 0, 65536)) > 0) {
        localFileOutputStream.write(arrayOfByte, 0, i);
      }
      localFileOutputStream.close();
      ((InputStream)localObject).close();
      localArrayList.add(localFile);
    }
    return localArrayList;
  }
  
  private static final boolean b(long paramLong)
  {
    if (Utils.isMac()) {
      return paramLong >= 0L;
    }
    return (paramLong == 0L) || (paramLong == 537198593L);
  }
  
  private static final void b(File paramFile)
  {
    if ((paramFile.exists()) && (paramFile.isDirectory())) {
      FileUtils.deleteDirectory(paramFile);
    }
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/jsell/ESellerate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */