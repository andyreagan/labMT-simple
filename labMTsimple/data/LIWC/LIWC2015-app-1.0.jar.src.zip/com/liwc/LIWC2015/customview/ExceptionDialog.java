/*    */ package com.liwc.LIWC2015.customview;
/*    */ 
/*    */ import com.liwc.LIWC2015.App;
/*    */ import java.io.PrintWriter;
/*    */ import java.io.StringWriter;
/*    */ import javafx.scene.control.DialogPane;
/*    */ import javafx.scene.control.Label;
/*    */ import javafx.scene.control.TextArea;
/*    */ import javafx.scene.layout.GridPane;
/*    */ import javafx.scene.layout.Priority;
/*    */ 
/*    */ public class ExceptionDialog extends LIWCAlert
/*    */ {
/*    */   private Exception exception;
/*    */   
/*    */   public ExceptionDialog(App app, Exception exception)
/*    */   {
/* 18 */     super(app, javafx.scene.control.Alert.AlertType.ERROR, "Exception", null, exception.getLocalizedMessage());
/* 19 */     this.exception = exception;
/*    */     
/* 21 */     StringWriter sw = new StringWriter();
/* 22 */     PrintWriter pw = new PrintWriter(sw);
/* 23 */     exception.printStackTrace(pw);
/* 24 */     String exceptionText = sw.toString();
/* 25 */     Label label = new Label("Exception stacktrace:");
/* 26 */     TextArea textArea = new TextArea(exceptionText);
/* 27 */     textArea.setEditable(false);
/* 28 */     textArea.setWrapText(true);
/* 29 */     textArea.setMaxWidth(Double.MAX_VALUE);
/* 30 */     textArea.setMaxHeight(Double.MAX_VALUE);
/* 31 */     GridPane.setVgrow(textArea, Priority.ALWAYS);
/* 32 */     GridPane.setHgrow(textArea, Priority.ALWAYS);
/* 33 */     GridPane expContent = new GridPane();
/* 34 */     expContent.setMaxWidth(Double.MAX_VALUE);
/* 35 */     expContent.add(label, 0, 0);
/* 36 */     expContent.add(textArea, 0, 1);
/* 37 */     getDialogPane().setExpandableContent(expContent);
/*    */   }
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/customview/ExceptionDialog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */