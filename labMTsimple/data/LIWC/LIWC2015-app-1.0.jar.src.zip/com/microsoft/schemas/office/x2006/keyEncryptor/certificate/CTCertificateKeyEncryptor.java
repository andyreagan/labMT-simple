package com.microsoft.schemas.office.x2006.keyEncryptor.certificate;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.SchemaTypeSystem;
import org.apache.xmlbeans.XmlBase64Binary;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public abstract interface CTCertificateKeyEncryptor
  extends XmlObject
{
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CTCertificateKeyEncryptor.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0B482D0B338CC9641C1543C3510577FE").resolveHandle("ctcertificatekeyencryptor1a80type");
  
  public abstract byte[] getEncryptedKeyValue();
  
  public abstract XmlBase64Binary xgetEncryptedKeyValue();
  
  public abstract void setEncryptedKeyValue(byte[] paramArrayOfByte);
  
  public abstract void xsetEncryptedKeyValue(XmlBase64Binary paramXmlBase64Binary);
  
  public abstract byte[] getX509Certificate();
  
  public abstract XmlBase64Binary xgetX509Certificate();
  
  public abstract void setX509Certificate(byte[] paramArrayOfByte);
  
  public abstract void xsetX509Certificate(XmlBase64Binary paramXmlBase64Binary);
  
  public abstract byte[] getCertVerifier();
  
  public abstract XmlBase64Binary xgetCertVerifier();
  
  public abstract void setCertVerifier(byte[] paramArrayOfByte);
  
  public abstract void xsetCertVerifier(XmlBase64Binary paramXmlBase64Binary);
  
  public static final class Factory
  {
    public static CTCertificateKeyEncryptor newInstance()
    {
      return (CTCertificateKeyEncryptor)XmlBeans.getContextTypeLoader().newInstance(CTCertificateKeyEncryptor.type, null);
    }
    
    public static CTCertificateKeyEncryptor newInstance(XmlOptions paramXmlOptions)
    {
      return (CTCertificateKeyEncryptor)XmlBeans.getContextTypeLoader().newInstance(CTCertificateKeyEncryptor.type, paramXmlOptions);
    }
    
    public static CTCertificateKeyEncryptor parse(String paramString)
      throws XmlException
    {
      return (CTCertificateKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramString, CTCertificateKeyEncryptor.type, null);
    }
    
    public static CTCertificateKeyEncryptor parse(String paramString, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (CTCertificateKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramString, CTCertificateKeyEncryptor.type, paramXmlOptions);
    }
    
    public static CTCertificateKeyEncryptor parse(File paramFile)
      throws XmlException, IOException
    {
      return (CTCertificateKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramFile, CTCertificateKeyEncryptor.type, null);
    }
    
    public static CTCertificateKeyEncryptor parse(File paramFile, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTCertificateKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramFile, CTCertificateKeyEncryptor.type, paramXmlOptions);
    }
    
    public static CTCertificateKeyEncryptor parse(URL paramURL)
      throws XmlException, IOException
    {
      return (CTCertificateKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramURL, CTCertificateKeyEncryptor.type, null);
    }
    
    public static CTCertificateKeyEncryptor parse(URL paramURL, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTCertificateKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramURL, CTCertificateKeyEncryptor.type, paramXmlOptions);
    }
    
    public static CTCertificateKeyEncryptor parse(InputStream paramInputStream)
      throws XmlException, IOException
    {
      return (CTCertificateKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramInputStream, CTCertificateKeyEncryptor.type, null);
    }
    
    public static CTCertificateKeyEncryptor parse(InputStream paramInputStream, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTCertificateKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramInputStream, CTCertificateKeyEncryptor.type, paramXmlOptions);
    }
    
    public static CTCertificateKeyEncryptor parse(Reader paramReader)
      throws XmlException, IOException
    {
      return (CTCertificateKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramReader, CTCertificateKeyEncryptor.type, null);
    }
    
    public static CTCertificateKeyEncryptor parse(Reader paramReader, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTCertificateKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramReader, CTCertificateKeyEncryptor.type, paramXmlOptions);
    }
    
    public static CTCertificateKeyEncryptor parse(XMLStreamReader paramXMLStreamReader)
      throws XmlException
    {
      return (CTCertificateKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, CTCertificateKeyEncryptor.type, null);
    }
    
    public static CTCertificateKeyEncryptor parse(XMLStreamReader paramXMLStreamReader, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (CTCertificateKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, CTCertificateKeyEncryptor.type, paramXmlOptions);
    }
    
    public static CTCertificateKeyEncryptor parse(Node paramNode)
      throws XmlException
    {
      return (CTCertificateKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramNode, CTCertificateKeyEncryptor.type, null);
    }
    
    public static CTCertificateKeyEncryptor parse(Node paramNode, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (CTCertificateKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramNode, CTCertificateKeyEncryptor.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static CTCertificateKeyEncryptor parse(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return (CTCertificateKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, CTCertificateKeyEncryptor.type, null);
    }
    
    /**
     * @deprecated
     */
    public static CTCertificateKeyEncryptor parse(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return (CTCertificateKeyEncryptor)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, CTCertificateKeyEncryptor.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, CTCertificateKeyEncryptor.type, null);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, CTCertificateKeyEncryptor.type, paramXmlOptions);
    }
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/keyEncryptor/certificate/CTCertificateKeyEncryptor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */