package com.microsoft.schemas.office.x2006.encryption;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.SchemaTypeSystem;
import org.apache.xmlbeans.StringEnumAbstractBase;
import org.apache.xmlbeans.StringEnumAbstractBase.Table;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.XmlToken;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public abstract interface STCipherChaining
  extends XmlToken
{
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(STCipherChaining.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0B482D0B338CC9641C1543C3510577FE").resolveHandle("stcipherchaining1e98type");
  public static final Enum CHAINING_MODE_CBC = Enum.forString("ChainingModeCBC");
  public static final Enum CHAINING_MODE_CFB = Enum.forString("ChainingModeCFB");
  public static final int INT_CHAINING_MODE_CBC = 1;
  public static final int INT_CHAINING_MODE_CFB = 2;
  
  public abstract StringEnumAbstractBase enumValue();
  
  public abstract void set(StringEnumAbstractBase paramStringEnumAbstractBase);
  
  public static final class Factory
  {
    public static STCipherChaining newValue(Object paramObject)
    {
      return (STCipherChaining)STCipherChaining.type.newValue(paramObject);
    }
    
    public static STCipherChaining newInstance()
    {
      return (STCipherChaining)XmlBeans.getContextTypeLoader().newInstance(STCipherChaining.type, null);
    }
    
    public static STCipherChaining newInstance(XmlOptions paramXmlOptions)
    {
      return (STCipherChaining)XmlBeans.getContextTypeLoader().newInstance(STCipherChaining.type, paramXmlOptions);
    }
    
    public static STCipherChaining parse(String paramString)
      throws XmlException
    {
      return (STCipherChaining)XmlBeans.getContextTypeLoader().parse(paramString, STCipherChaining.type, null);
    }
    
    public static STCipherChaining parse(String paramString, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (STCipherChaining)XmlBeans.getContextTypeLoader().parse(paramString, STCipherChaining.type, paramXmlOptions);
    }
    
    public static STCipherChaining parse(File paramFile)
      throws XmlException, IOException
    {
      return (STCipherChaining)XmlBeans.getContextTypeLoader().parse(paramFile, STCipherChaining.type, null);
    }
    
    public static STCipherChaining parse(File paramFile, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (STCipherChaining)XmlBeans.getContextTypeLoader().parse(paramFile, STCipherChaining.type, paramXmlOptions);
    }
    
    public static STCipherChaining parse(URL paramURL)
      throws XmlException, IOException
    {
      return (STCipherChaining)XmlBeans.getContextTypeLoader().parse(paramURL, STCipherChaining.type, null);
    }
    
    public static STCipherChaining parse(URL paramURL, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (STCipherChaining)XmlBeans.getContextTypeLoader().parse(paramURL, STCipherChaining.type, paramXmlOptions);
    }
    
    public static STCipherChaining parse(InputStream paramInputStream)
      throws XmlException, IOException
    {
      return (STCipherChaining)XmlBeans.getContextTypeLoader().parse(paramInputStream, STCipherChaining.type, null);
    }
    
    public static STCipherChaining parse(InputStream paramInputStream, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (STCipherChaining)XmlBeans.getContextTypeLoader().parse(paramInputStream, STCipherChaining.type, paramXmlOptions);
    }
    
    public static STCipherChaining parse(Reader paramReader)
      throws XmlException, IOException
    {
      return (STCipherChaining)XmlBeans.getContextTypeLoader().parse(paramReader, STCipherChaining.type, null);
    }
    
    public static STCipherChaining parse(Reader paramReader, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (STCipherChaining)XmlBeans.getContextTypeLoader().parse(paramReader, STCipherChaining.type, paramXmlOptions);
    }
    
    public static STCipherChaining parse(XMLStreamReader paramXMLStreamReader)
      throws XmlException
    {
      return (STCipherChaining)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, STCipherChaining.type, null);
    }
    
    public static STCipherChaining parse(XMLStreamReader paramXMLStreamReader, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (STCipherChaining)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, STCipherChaining.type, paramXmlOptions);
    }
    
    public static STCipherChaining parse(Node paramNode)
      throws XmlException
    {
      return (STCipherChaining)XmlBeans.getContextTypeLoader().parse(paramNode, STCipherChaining.type, null);
    }
    
    public static STCipherChaining parse(Node paramNode, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (STCipherChaining)XmlBeans.getContextTypeLoader().parse(paramNode, STCipherChaining.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static STCipherChaining parse(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return (STCipherChaining)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, STCipherChaining.type, null);
    }
    
    /**
     * @deprecated
     */
    public static STCipherChaining parse(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return (STCipherChaining)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, STCipherChaining.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, STCipherChaining.type, null);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, STCipherChaining.type, paramXmlOptions);
    }
  }
  
  public static final class Enum
    extends StringEnumAbstractBase
  {
    static final int INT_CHAINING_MODE_CBC = 1;
    static final int INT_CHAINING_MODE_CFB = 2;
    public static final StringEnumAbstractBase.Table table = new StringEnumAbstractBase.Table(new Enum[] { new Enum("ChainingModeCBC", 1), new Enum("ChainingModeCFB", 2) });
    private static final long serialVersionUID = 1L;
    
    public static Enum forString(String paramString)
    {
      return (Enum)table.forString(paramString);
    }
    
    public static Enum forInt(int paramInt)
    {
      return (Enum)table.forInt(paramInt);
    }
    
    private Enum(String paramString, int paramInt)
    {
      super(paramInt);
    }
    
    private Object readResolve()
    {
      return forInt(intValue());
    }
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/encryption/STCipherChaining.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */