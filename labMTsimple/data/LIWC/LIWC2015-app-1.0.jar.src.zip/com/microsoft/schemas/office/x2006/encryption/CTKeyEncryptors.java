package com.microsoft.schemas.office.x2006.encryption;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import java.util.List;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.SchemaTypeSystem;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlObject;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public abstract interface CTKeyEncryptors
  extends XmlObject
{
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(CTKeyEncryptors.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0B482D0B338CC9641C1543C3510577FE").resolveHandle("ctkeyencryptorsa09ctype");
  
  public abstract List<CTKeyEncryptor> getKeyEncryptorList();
  
  /**
   * @deprecated
   */
  public abstract CTKeyEncryptor[] getKeyEncryptorArray();
  
  public abstract CTKeyEncryptor getKeyEncryptorArray(int paramInt);
  
  public abstract int sizeOfKeyEncryptorArray();
  
  public abstract void setKeyEncryptorArray(CTKeyEncryptor[] paramArrayOfCTKeyEncryptor);
  
  public abstract void setKeyEncryptorArray(int paramInt, CTKeyEncryptor paramCTKeyEncryptor);
  
  public abstract CTKeyEncryptor insertNewKeyEncryptor(int paramInt);
  
  public abstract CTKeyEncryptor addNewKeyEncryptor();
  
  public abstract void removeKeyEncryptor(int paramInt);
  
  public static final class Factory
  {
    public static CTKeyEncryptors newInstance()
    {
      return (CTKeyEncryptors)XmlBeans.getContextTypeLoader().newInstance(CTKeyEncryptors.type, null);
    }
    
    public static CTKeyEncryptors newInstance(XmlOptions paramXmlOptions)
    {
      return (CTKeyEncryptors)XmlBeans.getContextTypeLoader().newInstance(CTKeyEncryptors.type, paramXmlOptions);
    }
    
    public static CTKeyEncryptors parse(String paramString)
      throws XmlException
    {
      return (CTKeyEncryptors)XmlBeans.getContextTypeLoader().parse(paramString, CTKeyEncryptors.type, null);
    }
    
    public static CTKeyEncryptors parse(String paramString, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (CTKeyEncryptors)XmlBeans.getContextTypeLoader().parse(paramString, CTKeyEncryptors.type, paramXmlOptions);
    }
    
    public static CTKeyEncryptors parse(File paramFile)
      throws XmlException, IOException
    {
      return (CTKeyEncryptors)XmlBeans.getContextTypeLoader().parse(paramFile, CTKeyEncryptors.type, null);
    }
    
    public static CTKeyEncryptors parse(File paramFile, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTKeyEncryptors)XmlBeans.getContextTypeLoader().parse(paramFile, CTKeyEncryptors.type, paramXmlOptions);
    }
    
    public static CTKeyEncryptors parse(URL paramURL)
      throws XmlException, IOException
    {
      return (CTKeyEncryptors)XmlBeans.getContextTypeLoader().parse(paramURL, CTKeyEncryptors.type, null);
    }
    
    public static CTKeyEncryptors parse(URL paramURL, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTKeyEncryptors)XmlBeans.getContextTypeLoader().parse(paramURL, CTKeyEncryptors.type, paramXmlOptions);
    }
    
    public static CTKeyEncryptors parse(InputStream paramInputStream)
      throws XmlException, IOException
    {
      return (CTKeyEncryptors)XmlBeans.getContextTypeLoader().parse(paramInputStream, CTKeyEncryptors.type, null);
    }
    
    public static CTKeyEncryptors parse(InputStream paramInputStream, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTKeyEncryptors)XmlBeans.getContextTypeLoader().parse(paramInputStream, CTKeyEncryptors.type, paramXmlOptions);
    }
    
    public static CTKeyEncryptors parse(Reader paramReader)
      throws XmlException, IOException
    {
      return (CTKeyEncryptors)XmlBeans.getContextTypeLoader().parse(paramReader, CTKeyEncryptors.type, null);
    }
    
    public static CTKeyEncryptors parse(Reader paramReader, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (CTKeyEncryptors)XmlBeans.getContextTypeLoader().parse(paramReader, CTKeyEncryptors.type, paramXmlOptions);
    }
    
    public static CTKeyEncryptors parse(XMLStreamReader paramXMLStreamReader)
      throws XmlException
    {
      return (CTKeyEncryptors)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, CTKeyEncryptors.type, null);
    }
    
    public static CTKeyEncryptors parse(XMLStreamReader paramXMLStreamReader, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (CTKeyEncryptors)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, CTKeyEncryptors.type, paramXmlOptions);
    }
    
    public static CTKeyEncryptors parse(Node paramNode)
      throws XmlException
    {
      return (CTKeyEncryptors)XmlBeans.getContextTypeLoader().parse(paramNode, CTKeyEncryptors.type, null);
    }
    
    public static CTKeyEncryptors parse(Node paramNode, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (CTKeyEncryptors)XmlBeans.getContextTypeLoader().parse(paramNode, CTKeyEncryptors.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static CTKeyEncryptors parse(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return (CTKeyEncryptors)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, CTKeyEncryptors.type, null);
    }
    
    /**
     * @deprecated
     */
    public static CTKeyEncryptors parse(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return (CTKeyEncryptors)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, CTKeyEncryptors.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, CTKeyEncryptors.type, null);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, CTKeyEncryptors.type, paramXmlOptions);
    }
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/encryption/CTKeyEncryptors.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */