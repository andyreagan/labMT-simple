/*     */ package com.liwc.LIWC2015.controller;
/*     */ 
/*     */ import com.liwc.LIWC2015.LiwcPreferences;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.math.BigDecimal;
/*     */ import java.text.DecimalFormat;
/*     */ import org.apache.commons.csv.CSVFormat;
/*     */ import org.apache.commons.csv.CSVPrinter;
/*     */ import org.apache.poi.ss.usermodel.Cell;
/*     */ import org.apache.poi.ss.usermodel.CellStyle;
/*     */ import org.apache.poi.ss.usermodel.DataFormat;
/*     */ import org.apache.poi.ss.usermodel.Row;
/*     */ import org.apache.poi.ss.usermodel.Sheet;
/*     */ import org.apache.poi.xssf.streaming.SXSSFWorkbook;
/*     */ 
/*     */ public abstract class FileSaver
/*     */ {
/*     */   public static FileSaver getFileSaver(File file, LiwcPreferences prefs) throws Exception
/*     */   {
/*  23 */     if (file.getName().endsWith(".txt"))
/*  24 */       return new TxtSaver(file);
/*  25 */     if (file.getName().endsWith(".xlsx"))
/*  26 */       return new ExcelSaver(file, null);
/*  27 */     if (file.getName().endsWith(".csv")) {
/*  28 */       return new CsvSaver(file, prefs);
/*     */     }
/*  30 */     return null;
/*     */   }
/*     */   
/*     */   public void saveValue(Object value, boolean lastItemInRow, boolean lastRowInTable) throws IOException {
/*  34 */     if (value == null) {
/*  35 */       saveNullValue(lastItemInRow, lastRowInTable);
/*  36 */     } else if ((value instanceof String)) {
/*  37 */       saveStringValue((String)value, lastItemInRow, lastRowInTable);
/*  38 */     } else if ((value instanceof Integer)) {
/*  39 */       saveIntValue((Integer)value, lastItemInRow, lastRowInTable);
/*  40 */     } else if ((value instanceof Float)) {
/*  41 */       saveFloatValue((Float)value, lastItemInRow, lastRowInTable);
/*     */     }
/*     */   }
/*     */   
/*     */   protected abstract void saveStringValue(String paramString, boolean paramBoolean1, boolean paramBoolean2) throws IOException;
/*     */   
/*     */   protected abstract void saveIntValue(Integer paramInteger, boolean paramBoolean1, boolean paramBoolean2) throws IOException;
/*     */   
/*     */   protected abstract void saveFloatValue(Float paramFloat, boolean paramBoolean1, boolean paramBoolean2) throws IOException;
/*     */   
/*     */   protected abstract void saveNullValue(boolean paramBoolean1, boolean paramBoolean2) throws IOException;
/*     */   
/*     */   public abstract void close() throws IOException;
/*     */   
/*     */   private static class TxtSaver extends FileSaver
/*     */   {
/*  57 */     protected DecimalFormat decimalFormat = new DecimalFormat("0.00");
/*     */     protected PrintWriter writer;
/*     */     
/*     */     public TxtSaver(File file) throws IOException {
/*  61 */       this.writer = new PrintWriter(file);
/*     */     }
/*     */     
/*     */     protected void saveStringValue(String value, boolean lastItemInRow, boolean lastRowInTable) throws IOException
/*     */     {
/*  66 */       this.writer.write(value);
/*  67 */       if (!lastItemInRow) {
/*  68 */         this.writer.write("\t");
/*  69 */       } else if (!lastRowInTable) {
/*  70 */         this.writer.write("\n");
/*     */       }
/*     */     }
/*     */     
/*     */     protected void saveIntValue(Integer value, boolean lastItemInRow, boolean lastRowInTable) throws IOException {
/*  75 */       saveStringValue(value.toString(), lastItemInRow, lastRowInTable);
/*     */     }
/*     */     
/*     */     protected void saveFloatValue(Float value, boolean lastItemInRow, boolean lastRowInTable) throws IOException
/*     */     {
/*  80 */       saveStringValue(this.decimalFormat.format(value), lastItemInRow, lastRowInTable);
/*     */     }
/*     */     
/*     */     protected void saveNullValue(boolean lastItemInRow, boolean lastRowInTable) throws IOException
/*     */     {
/*  85 */       saveStringValue("", lastItemInRow, lastRowInTable);
/*     */     }
/*     */     
/*     */     public void close() throws IOException
/*     */     {
/*  90 */       this.writer.close();
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ExcelSaver extends FileSaver
/*     */   {
/*     */     private SXSSFWorkbook workbook;
/*     */     private File file;
/*     */     private Sheet sheet;
/*     */     private Row row;
/* 100 */     private int rowCount = 0;
/* 101 */     private int cellCount = 0;
/*     */     private CellStyle floatCellStyle;
/*     */     
/*     */     private ExcelSaver(File file) throws IOException {
/* 105 */       this.file = file;
/* 106 */       this.workbook = new SXSSFWorkbook(1000);
/* 107 */       this.sheet = this.workbook.createSheet();
/* 108 */       this.floatCellStyle = this.workbook.createCellStyle();
/* 109 */       this.floatCellStyle.setDataFormat(this.workbook.createDataFormat().getFormat("0.00"));
/*     */     }
/*     */     
/*     */     protected void saveStringValue(String value, boolean lastItemInRow, boolean lastRowInTable) throws IOException
/*     */     {
/* 114 */       createRowIfNeeded();
/* 115 */       this.row.createCell(this.cellCount++).setCellValue(value);
/* 116 */       resetRowIfNeeded(lastItemInRow);
/*     */     }
/*     */     
/*     */     protected void saveIntValue(Integer value, boolean lastItemInRow, boolean lastRowInTable) throws IOException
/*     */     {
/* 121 */       createRowIfNeeded();
/* 122 */       this.row.createCell(this.cellCount++).setCellValue(value.intValue());
/* 123 */       resetRowIfNeeded(lastItemInRow);
/*     */     }
/*     */     
/*     */     protected void saveFloatValue(Float value, boolean lastItemInRow, boolean lastRowInTable) throws IOException
/*     */     {
/* 128 */       createRowIfNeeded();
/* 129 */       Cell cell = this.row.createCell(this.cellCount++);
/* 130 */       cell.setCellValue(BigDecimal.valueOf(value.floatValue()).setScale(2, 6).doubleValue());
/* 131 */       cell.setCellStyle(this.floatCellStyle);
/* 132 */       resetRowIfNeeded(lastItemInRow);
/*     */     }
/*     */     
/*     */     protected void saveNullValue(boolean lastItemInRow, boolean lastRowInTable) throws IOException
/*     */     {
/* 137 */       createRowIfNeeded();
/* 138 */       this.row.createCell(this.cellCount++);
/* 139 */       resetRowIfNeeded(lastItemInRow);
/*     */     }
/*     */     
/*     */     private void createRowIfNeeded() {
/* 143 */       if (this.row == null) {
/* 144 */         this.cellCount = 0;
/* 145 */         this.row = this.sheet.createRow(this.rowCount++);
/*     */       }
/*     */     }
/*     */     
/*     */     private void resetRowIfNeeded(boolean lastItemInRow) {
/* 150 */       if (lastItemInRow) {
/* 151 */         this.row = null;
/*     */       }
/*     */     }
/*     */     
/*     */     public void close() throws IOException {
/* 156 */       FileOutputStream fileOut = new FileOutputStream(this.file);
/* 157 */       this.workbook.write(fileOut);
/* 158 */       fileOut.close();
/* 159 */       this.workbook.dispose();
/*     */     }
/*     */   }
/*     */   
/*     */   private static class CsvSaver extends FileSaver.TxtSaver
/*     */   {
/*     */     private CSVPrinter printer;
/*     */     
/*     */     public CsvSaver(File file, LiwcPreferences prefs) throws IOException {
/* 168 */       super();
/*     */       
/*     */ 
/* 171 */       this.printer = new CSVPrinter(this.writer, CSVFormat.DEFAULT.withDelimiter(com.liwc.LIWC2015.Utils.getCsvDelimiter(prefs)).withEscape(prefs.getCsvEscapeCharacter() == 0 ? null : Character.valueOf(prefs.getCsvEscapeCharacter())).withQuote(prefs.getCsvQuoteCharacter() == 0 ? null : Character.valueOf(prefs.getCsvQuoteCharacter())));
/*     */     }
/*     */     
/*     */     protected void saveStringValue(String value, boolean lastItemInRow, boolean lastRowInTable) throws IOException
/*     */     {
/* 176 */       this.printer.print(value);
/* 177 */       if ((lastItemInRow) && (!lastRowInTable)) {
/* 178 */         this.printer.println();
/*     */       }
/*     */     }
/*     */     
/*     */     public void close() throws IOException {
/* 183 */       this.printer.flush();
/* 184 */       this.printer.close();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/FileSaver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */