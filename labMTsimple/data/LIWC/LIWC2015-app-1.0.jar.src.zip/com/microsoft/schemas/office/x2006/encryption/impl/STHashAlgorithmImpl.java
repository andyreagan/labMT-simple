package com.microsoft.schemas.office.x2006.encryption.impl;

import com.microsoft.schemas.office.x2006.encryption.STHashAlgorithm;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx;

public class STHashAlgorithmImpl
  extends JavaStringEnumerationHolderEx
  implements STHashAlgorithm
{
  public STHashAlgorithmImpl(SchemaType paramSchemaType)
  {
    super(paramSchemaType, false);
  }
  
  protected STHashAlgorithmImpl(SchemaType paramSchemaType, boolean paramBoolean)
  {
    super(paramSchemaType, paramBoolean);
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/encryption/impl/STHashAlgorithmImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */