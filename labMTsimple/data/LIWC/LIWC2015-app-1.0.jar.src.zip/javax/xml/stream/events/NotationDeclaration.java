package javax.xml.stream.events;

public abstract interface NotationDeclaration
  extends XMLEvent
{
  public abstract String getName();
  
  public abstract String getPublicId();
  
  public abstract String getSystemId();
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/javax/xml/stream/events/NotationDeclaration.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */