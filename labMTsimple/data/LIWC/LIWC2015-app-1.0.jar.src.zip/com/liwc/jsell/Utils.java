package com.liwc.jsell;

import java.io.File;
import org.slf4j.LoggerFactory;

public class Utils
{
  public static boolean isMac()
  {
    String str;
    return ((str = System.getProperty("os.name")) != null) && (str.toLowerCase().startsWith("mac"));
  }
  
  public static String getPreferencesPath()
  {
    return getAppSettingsFolder() + File.separator + "LIWC2015.prf";
  }
  
  public static String getAppSettingsFolder()
  {
    return System.getProperty("user.home") + File.separator + "LIWC2015";
  }
  
  static
  {
    LoggerFactory.getLogger(Utils.class);
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/jsell/Utils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */