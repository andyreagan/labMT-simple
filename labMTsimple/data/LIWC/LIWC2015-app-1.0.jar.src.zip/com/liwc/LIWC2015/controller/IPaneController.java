package com.liwc.LIWC2015.controller;

public abstract interface IPaneController
{
  public abstract void close();
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/IPaneController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */