package com.liwc.core;

import java.util.ArrayList;

final class a
  extends ArrayList
{
  a(TextProcessor paramTextProcessor, Integer paramInteger)
  {
    add(this.a);
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/core/a.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */