/*    */ package com.liwc.LIWC2015.model;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public class WordCategories
/*    */ {
/*    */   private String word;
/*    */   private List<Integer> categories;
/*    */   
/*    */   public WordCategories(String word, List<Integer> categories) {
/* 11 */     this.word = word;
/* 12 */     this.categories = categories;
/*    */   }
/*    */   
/*    */   public String getWord() {
/* 16 */     return this.word;
/*    */   }
/*    */   
/*    */   public void setWord(String word) {
/* 20 */     this.word = word;
/*    */   }
/*    */   
/*    */   public List<Integer> getCategories() {
/* 24 */     return this.categories;
/*    */   }
/*    */   
/*    */   public void setCategories(List<Integer> categories) {
/* 28 */     this.categories = categories;
/*    */   }
/*    */   
/*    */   public boolean hasCategory(int category) {
/* 32 */     return (this.categories != null) && (this.categories.contains(Integer.valueOf(category)));
/*    */   }
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/model/WordCategories.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */