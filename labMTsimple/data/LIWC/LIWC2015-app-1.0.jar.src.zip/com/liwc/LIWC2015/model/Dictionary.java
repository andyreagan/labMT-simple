/*    */ package com.liwc.LIWC2015.model;
/*    */ 
/*    */ import com.liwc.core.LanguageSettings;
/*    */ import com.liwc.core.dictionary.DicFile;
/*    */ import com.liwc.core.dictionary.IDictionary;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.Locale;
/*    */ import javax.xml.bind.annotation.XmlAttribute;
/*    */ 
/*    */ public class Dictionary
/*    */ {
/*    */   private String id;
/*    */   private String name;
/*    */   private String ref;
/*    */   private String refExport;
/*    */   
/*    */   public static IDictionary load(String ref, Locale locale) throws IOException
/*    */   {
/* 20 */     InputStream is = Dictionary.class.getResourceAsStream(Dictionaries.DictionariesPackage + ref);
/* 21 */     IDictionary dicFile = new DicFile(is, new LanguageSettings(locale));
/* 22 */     is.close();
/* 23 */     return dicFile;
/*    */   }
/*    */   
/*    */   @XmlAttribute
/*    */   public String getId()
/*    */   {
/* 29 */     return this.id;
/*    */   }
/*    */   
/*    */   public void setId(String id) {
/* 33 */     this.id = id;
/*    */   }
/*    */   
/*    */   @XmlAttribute
/*    */   public String getName() {
/* 38 */     return this.name;
/*    */   }
/*    */   
/*    */   public void setName(String name) {
/* 42 */     this.name = name;
/*    */   }
/*    */   
/*    */   @XmlAttribute
/*    */   public String getRef() {
/* 47 */     return this.ref;
/*    */   }
/*    */   
/*    */   public void setRef(String ref) {
/* 51 */     this.ref = ref;
/*    */   }
/*    */   
/*    */   @XmlAttribute
/*    */   public String getRefExport() {
/* 56 */     return this.refExport;
/*    */   }
/*    */   
/*    */   public void setRefExport(String refExport) {
/* 60 */     this.refExport = refExport;
/*    */   }
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/model/Dictionary.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */