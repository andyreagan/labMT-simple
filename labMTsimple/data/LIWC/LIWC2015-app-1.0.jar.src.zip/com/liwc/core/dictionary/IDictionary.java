package com.liwc.core.dictionary;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public abstract interface IDictionary
{
  public static final LinkedHashMap PunctuationMarksCategories = new b();
  public static final LinkedHashMap PunctuationMarks = new c();
  
  public abstract List findWord(String paramString);
  
  public abstract Map getCategoriesPlain();
  
  public abstract List getCategoriesTree();
  
  public abstract Map getPatterns();
  
  public abstract Integer getNumbersCategory();
  
  public abstract List getSpecialWords();
  
  public static LinkedHashMap getPunctuationMarksMap(String paramString, int paramInt)
  {
    LinkedHashMap localLinkedHashMap = new LinkedHashMap();
    for (int i = 0; i < paramString.length(); i++) {
      localLinkedHashMap.put(paramString.substring(i, i + 1), new d(paramInt));
    }
    return localLinkedHashMap;
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/core/dictionary/IDictionary.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */