/*    */ package com.liwc.LIWC2015.controller;
/*    */ 
/*    */ import com.liwc.LIWC2015.App;
/*    */ import com.liwc.LIWC2015.LiwcPreferences;
/*    */ import com.liwc.LIWC2015.Utils;
/*    */ import java.net.URL;
/*    */ import java.text.DateFormat;
/*    */ import java.text.ParseException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import java.util.Properties;
/*    */ import java.util.ResourceBundle;
/*    */ import javafx.application.HostServices;
/*    */ import javafx.fxml.FXML;
/*    */ import javafx.fxml.Initializable;
/*    */ import javafx.scene.Scene;
/*    */ import javafx.scene.control.Label;
/*    */ import javafx.scene.layout.VBox;
/*    */ import javafx.stage.Modality;
/*    */ import javafx.stage.Stage;
/*    */ import javafx.stage.StageStyle;
/*    */ 
/*    */ 
/*    */ public class AboutDialogController
/*    */   extends ModalDialogController
/*    */   implements Initializable
/*    */ {
/*    */   @FXML
/*    */   private VBox vBox;
/*    */   @FXML
/*    */   private Label serialNumber;
/*    */   @FXML
/*    */   private Label versionLabel;
/*    */   @FXML
/*    */   private Label licenseType;
/*    */   
/*    */   public void initialize(URL location, ResourceBundle resources) {}
/*    */   
/*    */   public Stage initStage(App app, Object... args)
/*    */     throws Exception
/*    */   {
/* 42 */     Scene newScene = new Scene(this.vBox);
/* 43 */     Stage stage = new Stage();
/* 44 */     stage.setScene(newScene);
/* 45 */     stage.setResizable(false);
/* 46 */     stage.initModality(Modality.APPLICATION_MODAL);
/* 47 */     if (!Utils.isMac())
/* 48 */       stage.initStyle(StageStyle.UTILITY);
/* 49 */     stage.initOwner(null);
/* 50 */     stage.setTitle(null);
/* 51 */     this.serialNumber.setText(app.getLiwcPreferences().getSerialNumber());
/* 52 */     this.versionLabel.setText(String.format("Version %s (%s)", new Object[] { getVersion(), new SimpleDateFormat("MMMM d, yyyy").format(Long.valueOf(getDate().getTime())) }));
/* 53 */     this.licenseType.setText(app.isLicensePermanent() ? "Full" : "30-days subscription");
/* 54 */     return stage;
/*    */   }
/*    */   
/*    */   public void onLink() {
/* 58 */     this.app.getHostServices().showDocument("http://www.liwc.net");
/*    */   }
/*    */   
/*    */   private Date getDate() throws ParseException {
/* 62 */     DateFormat formatter = new SimpleDateFormat(this.app.getMvnProperties().getProperty("maven.build.timestamp.format"));
/* 63 */     Date date = formatter.parse(this.app.getMvnProperties().getProperty("timestamp"));
/* 64 */     return date;
/*    */   }
/*    */   
/*    */   private String getVersion() {
/* 68 */     return this.app.getMvnProperties().getProperty("version");
/*    */   }
/*    */ }


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/liwc/LIWC2015/controller/AboutDialogController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */