package com.microsoft.schemas.office.x2006.encryption;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.SchemaTypeSystem;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.XmlUnsignedInt;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public abstract interface STSaltSize
  extends XmlUnsignedInt
{
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(STSaltSize.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0B482D0B338CC9641C1543C3510577FE").resolveHandle("stsaltsizee7a3type");
  
  public abstract int getIntValue();
  
  public abstract void setIntValue(int paramInt);
  
  /**
   * @deprecated
   */
  public abstract int intValue();
  
  /**
   * @deprecated
   */
  public abstract void set(int paramInt);
  
  public static final class Factory
  {
    public static STSaltSize newValue(Object paramObject)
    {
      return (STSaltSize)STSaltSize.type.newValue(paramObject);
    }
    
    public static STSaltSize newInstance()
    {
      return (STSaltSize)XmlBeans.getContextTypeLoader().newInstance(STSaltSize.type, null);
    }
    
    public static STSaltSize newInstance(XmlOptions paramXmlOptions)
    {
      return (STSaltSize)XmlBeans.getContextTypeLoader().newInstance(STSaltSize.type, paramXmlOptions);
    }
    
    public static STSaltSize parse(String paramString)
      throws XmlException
    {
      return (STSaltSize)XmlBeans.getContextTypeLoader().parse(paramString, STSaltSize.type, null);
    }
    
    public static STSaltSize parse(String paramString, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (STSaltSize)XmlBeans.getContextTypeLoader().parse(paramString, STSaltSize.type, paramXmlOptions);
    }
    
    public static STSaltSize parse(File paramFile)
      throws XmlException, IOException
    {
      return (STSaltSize)XmlBeans.getContextTypeLoader().parse(paramFile, STSaltSize.type, null);
    }
    
    public static STSaltSize parse(File paramFile, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (STSaltSize)XmlBeans.getContextTypeLoader().parse(paramFile, STSaltSize.type, paramXmlOptions);
    }
    
    public static STSaltSize parse(URL paramURL)
      throws XmlException, IOException
    {
      return (STSaltSize)XmlBeans.getContextTypeLoader().parse(paramURL, STSaltSize.type, null);
    }
    
    public static STSaltSize parse(URL paramURL, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (STSaltSize)XmlBeans.getContextTypeLoader().parse(paramURL, STSaltSize.type, paramXmlOptions);
    }
    
    public static STSaltSize parse(InputStream paramInputStream)
      throws XmlException, IOException
    {
      return (STSaltSize)XmlBeans.getContextTypeLoader().parse(paramInputStream, STSaltSize.type, null);
    }
    
    public static STSaltSize parse(InputStream paramInputStream, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (STSaltSize)XmlBeans.getContextTypeLoader().parse(paramInputStream, STSaltSize.type, paramXmlOptions);
    }
    
    public static STSaltSize parse(Reader paramReader)
      throws XmlException, IOException
    {
      return (STSaltSize)XmlBeans.getContextTypeLoader().parse(paramReader, STSaltSize.type, null);
    }
    
    public static STSaltSize parse(Reader paramReader, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (STSaltSize)XmlBeans.getContextTypeLoader().parse(paramReader, STSaltSize.type, paramXmlOptions);
    }
    
    public static STSaltSize parse(XMLStreamReader paramXMLStreamReader)
      throws XmlException
    {
      return (STSaltSize)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, STSaltSize.type, null);
    }
    
    public static STSaltSize parse(XMLStreamReader paramXMLStreamReader, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (STSaltSize)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, STSaltSize.type, paramXmlOptions);
    }
    
    public static STSaltSize parse(Node paramNode)
      throws XmlException
    {
      return (STSaltSize)XmlBeans.getContextTypeLoader().parse(paramNode, STSaltSize.type, null);
    }
    
    public static STSaltSize parse(Node paramNode, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (STSaltSize)XmlBeans.getContextTypeLoader().parse(paramNode, STSaltSize.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static STSaltSize parse(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return (STSaltSize)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, STSaltSize.type, null);
    }
    
    /**
     * @deprecated
     */
    public static STSaltSize parse(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return (STSaltSize)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, STSaltSize.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, STSaltSize.type, null);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, STSaltSize.type, paramXmlOptions);
    }
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/encryption/STSaltSize.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */