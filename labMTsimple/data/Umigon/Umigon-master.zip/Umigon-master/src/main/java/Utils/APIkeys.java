/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Utils;

/**
 *
 * @author C. Levallois
 */
public class APIkeys {

    public static String getMendeleyAPIkey() {
        return "ee5bde90a001b24da7984de6e58ef8b405022317e";
    }
    public static String getScopusRingAPIkey() {
        return "e0bf3f89dbe4c27aea89acdcfd85d5c3";
    }
    
    public static String getMongoHQAPIkey() {
        return "0FwGVJmwy8ouyeZ1z6p7xQ";
    }
    
    public static String getMongoHQPass() {
        return "testpass";
    }
    
    public static String getTwitterConsumerSecret() {
        return "VVsf4qT0DCBeLODRDnBlhwxrRG6KLm0TT2wiK2Q";
    }
    
    public static String getTwitterAccessTokenSecret() {
        return "P7l7SmHiZyE11tNfsQ17fdSzJ7sUpMJAliundncpaA";
    }
    
    
}
