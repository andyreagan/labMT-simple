package org.apache.commons.collections.functors;

import org.apache.commons.collections.Predicate;

public abstract interface PredicateDecorator
  extends Predicate
{
  public abstract Predicate[] getPredicates();
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/org/apache/commons/collections/functors/PredicateDecorator.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       0.7.1
 */