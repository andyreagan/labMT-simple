package com.microsoft.schemas.office.x2006.encryption.impl;

import com.microsoft.schemas.office.x2006.encryption.CTKeyEncryptor;
import com.microsoft.schemas.office.x2006.encryption.CTKeyEncryptors;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.impl.values.TypeStore;
import org.apache.xmlbeans.impl.values.XmlComplexContentImpl;

public class CTKeyEncryptorsImpl
  extends XmlComplexContentImpl
  implements CTKeyEncryptors
{
  private static final QName KEYENCRYPTOR$0 = new QName("http://schemas.microsoft.com/office/2006/encryption", "keyEncryptor");
  
  public CTKeyEncryptorsImpl(SchemaType paramSchemaType)
  {
    super(paramSchemaType);
  }
  
  public List<CTKeyEncryptor> getKeyEncryptorList()
  {
    synchronized (monitor())
    {
      check_orphaned();
      new AbstractList()
      {
        public CTKeyEncryptor get(int paramAnonymousInt)
        {
          return CTKeyEncryptorsImpl.this.getKeyEncryptorArray(paramAnonymousInt);
        }
        
        public CTKeyEncryptor set(int paramAnonymousInt, CTKeyEncryptor paramAnonymousCTKeyEncryptor)
        {
          CTKeyEncryptor localCTKeyEncryptor = CTKeyEncryptorsImpl.this.getKeyEncryptorArray(paramAnonymousInt);
          CTKeyEncryptorsImpl.this.setKeyEncryptorArray(paramAnonymousInt, paramAnonymousCTKeyEncryptor);
          return localCTKeyEncryptor;
        }
        
        public void add(int paramAnonymousInt, CTKeyEncryptor paramAnonymousCTKeyEncryptor)
        {
          CTKeyEncryptorsImpl.this.insertNewKeyEncryptor(paramAnonymousInt).set(paramAnonymousCTKeyEncryptor);
        }
        
        public CTKeyEncryptor remove(int paramAnonymousInt)
        {
          CTKeyEncryptor localCTKeyEncryptor = CTKeyEncryptorsImpl.this.getKeyEncryptorArray(paramAnonymousInt);
          CTKeyEncryptorsImpl.this.removeKeyEncryptor(paramAnonymousInt);
          return localCTKeyEncryptor;
        }
        
        public int size()
        {
          return CTKeyEncryptorsImpl.this.sizeOfKeyEncryptorArray();
        }
      };
    }
  }
  
  public CTKeyEncryptor[] getKeyEncryptorArray()
  {
    synchronized (monitor())
    {
      check_orphaned();
      ArrayList localArrayList = new ArrayList();
      get_store().find_all_element_users(KEYENCRYPTOR$0, localArrayList);
      CTKeyEncryptor[] arrayOfCTKeyEncryptor = new CTKeyEncryptor[localArrayList.size()];
      localArrayList.toArray(arrayOfCTKeyEncryptor);
      return arrayOfCTKeyEncryptor;
    }
  }
  
  public CTKeyEncryptor getKeyEncryptorArray(int paramInt)
  {
    synchronized (monitor())
    {
      check_orphaned();
      CTKeyEncryptor localCTKeyEncryptor = null;
      localCTKeyEncryptor = (CTKeyEncryptor)get_store().find_element_user(KEYENCRYPTOR$0, paramInt);
      if (localCTKeyEncryptor == null) {
        throw new IndexOutOfBoundsException();
      }
      return localCTKeyEncryptor;
    }
  }
  
  public int sizeOfKeyEncryptorArray()
  {
    synchronized (monitor())
    {
      check_orphaned();
      return get_store().count_elements(KEYENCRYPTOR$0);
    }
  }
  
  public void setKeyEncryptorArray(CTKeyEncryptor[] paramArrayOfCTKeyEncryptor)
  {
    synchronized (monitor())
    {
      check_orphaned();
      arraySetterHelper(paramArrayOfCTKeyEncryptor, KEYENCRYPTOR$0);
    }
  }
  
  public void setKeyEncryptorArray(int paramInt, CTKeyEncryptor paramCTKeyEncryptor)
  {
    synchronized (monitor())
    {
      check_orphaned();
      CTKeyEncryptor localCTKeyEncryptor = null;
      localCTKeyEncryptor = (CTKeyEncryptor)get_store().find_element_user(KEYENCRYPTOR$0, paramInt);
      if (localCTKeyEncryptor == null) {
        throw new IndexOutOfBoundsException();
      }
      localCTKeyEncryptor.set(paramCTKeyEncryptor);
    }
  }
  
  public CTKeyEncryptor insertNewKeyEncryptor(int paramInt)
  {
    synchronized (monitor())
    {
      check_orphaned();
      CTKeyEncryptor localCTKeyEncryptor = null;
      localCTKeyEncryptor = (CTKeyEncryptor)get_store().insert_element_user(KEYENCRYPTOR$0, paramInt);
      return localCTKeyEncryptor;
    }
  }
  
  public CTKeyEncryptor addNewKeyEncryptor()
  {
    synchronized (monitor())
    {
      check_orphaned();
      CTKeyEncryptor localCTKeyEncryptor = null;
      localCTKeyEncryptor = (CTKeyEncryptor)get_store().add_element_user(KEYENCRYPTOR$0);
      return localCTKeyEncryptor;
    }
  }
  
  public void removeKeyEncryptor(int paramInt)
  {
    synchronized (monitor())
    {
      check_orphaned();
      get_store().remove_element(KEYENCRYPTOR$0, paramInt);
    }
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/encryption/impl/CTKeyEncryptorsImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */