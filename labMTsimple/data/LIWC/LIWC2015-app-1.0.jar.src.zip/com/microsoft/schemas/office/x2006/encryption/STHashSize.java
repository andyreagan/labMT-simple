package com.microsoft.schemas.office.x2006.encryption;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.net.URL;
import javax.xml.stream.XMLStreamReader;
import org.apache.xmlbeans.SchemaType;
import org.apache.xmlbeans.SchemaTypeLoader;
import org.apache.xmlbeans.SchemaTypeSystem;
import org.apache.xmlbeans.XmlBeans;
import org.apache.xmlbeans.XmlException;
import org.apache.xmlbeans.XmlOptions;
import org.apache.xmlbeans.XmlUnsignedInt;
import org.apache.xmlbeans.xml.stream.XMLInputStream;
import org.apache.xmlbeans.xml.stream.XMLStreamException;
import org.w3c.dom.Node;

public abstract interface STHashSize
  extends XmlUnsignedInt
{
  public static final SchemaType type = (SchemaType)XmlBeans.typeSystemForClassLoader(STHashSize.class.getClassLoader(), "schemaorg_apache_xmlbeans.system.s0B482D0B338CC9641C1543C3510577FE").resolveHandle("sthashsize605btype");
  
  public abstract int getIntValue();
  
  public abstract void setIntValue(int paramInt);
  
  /**
   * @deprecated
   */
  public abstract int intValue();
  
  /**
   * @deprecated
   */
  public abstract void set(int paramInt);
  
  public static final class Factory
  {
    public static STHashSize newValue(Object paramObject)
    {
      return (STHashSize)STHashSize.type.newValue(paramObject);
    }
    
    public static STHashSize newInstance()
    {
      return (STHashSize)XmlBeans.getContextTypeLoader().newInstance(STHashSize.type, null);
    }
    
    public static STHashSize newInstance(XmlOptions paramXmlOptions)
    {
      return (STHashSize)XmlBeans.getContextTypeLoader().newInstance(STHashSize.type, paramXmlOptions);
    }
    
    public static STHashSize parse(String paramString)
      throws XmlException
    {
      return (STHashSize)XmlBeans.getContextTypeLoader().parse(paramString, STHashSize.type, null);
    }
    
    public static STHashSize parse(String paramString, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (STHashSize)XmlBeans.getContextTypeLoader().parse(paramString, STHashSize.type, paramXmlOptions);
    }
    
    public static STHashSize parse(File paramFile)
      throws XmlException, IOException
    {
      return (STHashSize)XmlBeans.getContextTypeLoader().parse(paramFile, STHashSize.type, null);
    }
    
    public static STHashSize parse(File paramFile, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (STHashSize)XmlBeans.getContextTypeLoader().parse(paramFile, STHashSize.type, paramXmlOptions);
    }
    
    public static STHashSize parse(URL paramURL)
      throws XmlException, IOException
    {
      return (STHashSize)XmlBeans.getContextTypeLoader().parse(paramURL, STHashSize.type, null);
    }
    
    public static STHashSize parse(URL paramURL, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (STHashSize)XmlBeans.getContextTypeLoader().parse(paramURL, STHashSize.type, paramXmlOptions);
    }
    
    public static STHashSize parse(InputStream paramInputStream)
      throws XmlException, IOException
    {
      return (STHashSize)XmlBeans.getContextTypeLoader().parse(paramInputStream, STHashSize.type, null);
    }
    
    public static STHashSize parse(InputStream paramInputStream, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (STHashSize)XmlBeans.getContextTypeLoader().parse(paramInputStream, STHashSize.type, paramXmlOptions);
    }
    
    public static STHashSize parse(Reader paramReader)
      throws XmlException, IOException
    {
      return (STHashSize)XmlBeans.getContextTypeLoader().parse(paramReader, STHashSize.type, null);
    }
    
    public static STHashSize parse(Reader paramReader, XmlOptions paramXmlOptions)
      throws XmlException, IOException
    {
      return (STHashSize)XmlBeans.getContextTypeLoader().parse(paramReader, STHashSize.type, paramXmlOptions);
    }
    
    public static STHashSize parse(XMLStreamReader paramXMLStreamReader)
      throws XmlException
    {
      return (STHashSize)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, STHashSize.type, null);
    }
    
    public static STHashSize parse(XMLStreamReader paramXMLStreamReader, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (STHashSize)XmlBeans.getContextTypeLoader().parse(paramXMLStreamReader, STHashSize.type, paramXmlOptions);
    }
    
    public static STHashSize parse(Node paramNode)
      throws XmlException
    {
      return (STHashSize)XmlBeans.getContextTypeLoader().parse(paramNode, STHashSize.type, null);
    }
    
    public static STHashSize parse(Node paramNode, XmlOptions paramXmlOptions)
      throws XmlException
    {
      return (STHashSize)XmlBeans.getContextTypeLoader().parse(paramNode, STHashSize.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static STHashSize parse(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return (STHashSize)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, STHashSize.type, null);
    }
    
    /**
     * @deprecated
     */
    public static STHashSize parse(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return (STHashSize)XmlBeans.getContextTypeLoader().parse(paramXMLInputStream, STHashSize.type, paramXmlOptions);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, STHashSize.type, null);
    }
    
    /**
     * @deprecated
     */
    public static XMLInputStream newValidatingXMLInputStream(XMLInputStream paramXMLInputStream, XmlOptions paramXmlOptions)
      throws XmlException, XMLStreamException
    {
      return XmlBeans.getContextTypeLoader().newValidatingXMLInputStream(paramXMLInputStream, STHashSize.type, paramXmlOptions);
    }
  }
}


/* Location:              /Users/andyreagan/Desktop/LIWC2015-app-1.0.jar!/com/microsoft/schemas/office/x2006/encryption/STHashSize.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */